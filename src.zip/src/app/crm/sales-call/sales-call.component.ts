import { Component, OnInit, OnDestroy } from '@angular/core';
import { SalesCallService } from '../../services/sales-call.service';
import { Subscription } from 'rxjs';
import { CallLogService } from '../../services/call-log.service';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import { take } from 'rxjs/operators';
import 'jspdf-autotable';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-sales-call',
  templateUrl: './sales-call.component.html',
  styleUrls: ['./sales-call.component.scss']
})
export class SalesCallComponent implements OnInit, OnDestroy {
  salesCalls: any[] = [];
  filteredCalls: any[] = [];
  selectedStatus = '';
    availableUsers: any[] = [];

  searchTerm = '';
  allColumns = [
    { key: 'select', label: 'Select' },
    { key: 'customerName', label: 'Customer Name' },
    { key: 'mobile', label: 'Mobile' },
      { key: 'actions', label: 'Actions' },

    { key: 'lastTransactionDate', label: 'Last Transaction' },
    { key: 'assignedTo', label: 'Assigned To' },
    { key: 'callStatus', label: 'Call Status' },
    
    { key: 'callDate', label: 'Call Date' },
    { key: 'notes', label: 'Notes' },
    { key: 'lastCallInfo', label: 'Last Call Info' },
      { key: 'department', label: 'Department' }, // Add this line

  ];
  
visibleColumns = [
  'select', 'customerName', 'mobile', 'lastTransactionDate', 'department',
  'assignedTo', 'callStatus', 'callDate', 'notes', 'lastCallInfo','actions'
]; // Default visible columns

showColumnDropdown = false;
  private callsSubscription!: Subscription;
  sortColumn: string = 'callDate'; // Default sort column
sortDirection: 'asc' | 'desc' = 'desc'; // Default sort direction
  private callLogsSubscription!: Subscription;
// Add these properties to your component class
showFilterSidebar = false;
salesAgents: string[] = ['Agent 1', 'Agent 2', 'Agent 3']; // Replace with actual agents

filters = {
  status: '',
  assignedTo: '',
  startDate: '',
  endDate: '',
  transactionType: '',
  callOutcome: ''
};

// Add these methods to your component class
toggleFilterSidebar(): void {
  this.showFilterSidebar = !this.showFilterSidebar;
}
  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalItems = 0;
  totalPages = 0;

  // Bulk actions
  selectedCalls: string[] = [];
  selectAll = false;

  customerCallLogs: { [customerId: string]: any[] } = {};

  Math = Math;

  constructor(
    private salesCallService: SalesCallService,
    private callLogService: CallLogService,
    private userservice:UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadSalesCalls();
        this.loadAvailableUsers(); // Load users when component initializes

  }

  ngOnDestroy(): void {
    if (this.callsSubscription) {
      this.callsSubscription.unsubscribe();
    }
    if (this.callLogsSubscription) {
      this.callLogsSubscription.unsubscribe();
    }
  }
sort(column: string): void {
  if (this.sortColumn === column) {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    this.sortColumn = column;
    this.sortDirection = 'asc';
  }
  
  this.applySorting();
}
applySorting(): void {
  this.filteredCalls.sort((a, b) => {
    // Handle null/undefined values
    const aValue = a[this.sortColumn] ?? '';
    const bValue = b[this.sortColumn] ?? '';
    
    // Special handling for dates
    if (this.sortColumn === 'lastTransactionDate') {
      const dateA = aValue ? new Date(aValue).getTime() : 0;
      const dateB = bValue ? new Date(bValue).getTime() : 0;
      return this.sortDirection === 'asc' ? dateA - dateB : dateB - dateA;
    }
    
    
    // Case-insensitive string comparison
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return this.sortDirection === 'asc' 
        ? aValue.localeCompare(bValue) 
        : bValue.localeCompare(aValue);
    }
    
    // Numeric comparison
    return this.sortDirection === 'asc' 
      ? (aValue > bValue ? 1 : -1) 
      : (bValue > aValue ? 1 : -1);
  });
  
  // Reset to first page after sorting
  this.currentPage = 1;
}
applyAdvancedFilters(): void {
  let filtered = [...this.salesCalls];

  // Apply status filter
  if (this.filters.status) {
    filtered = filtered.filter(call => call.callStatus === this.filters.status);
  }

  // Apply assigned to filter
  if (this.filters.assignedTo) {
    filtered = filtered.filter(call => call.assignedTo === this.filters.assignedTo);
  }

  // Apply date range filter
  if (this.filters.startDate) {
    const startDate = new Date(this.filters.startDate);
    filtered = filtered.filter(call => {
      const callDate = call.callDate ? new Date(call.callDate) : null;
      return callDate && callDate >= startDate;
    });
  }

  if (this.filters.endDate) {
    const endDate = new Date(this.filters.endDate);
    filtered = filtered.filter(call => {
      const callDate = call.callDate ? new Date(call.callDate) : null;
      return callDate && callDate <= endDate;
    });
  }

  // Apply transaction type filter
  if (this.filters.transactionType === 'Recent') {
    filtered = filtered.filter(call => this.isRecentTransaction(call.lastTransactionDate));
  } else if (this.filters.transactionType === 'Older') {
    filtered = filtered.filter(call => !this.isRecentTransaction(call.lastTransactionDate));
  }

  // Apply call outcome filter
  if (this.filters.callOutcome) {
    filtered = filtered.filter(call => {
      const latestLog = this.getLatestCallLog(call.customerId);
      return latestLog && latestLog.callOutcome === this.filters.callOutcome;
    });
  }

  this.filteredCalls = filtered;
  this.totalItems = filtered.length;
  this.currentPage = 1;
  this.calculateTotalPages();
  this.showFilterSidebar = false;
}
  // Add this method to load available users
  loadAvailableUsers(): void {
// In the loadAvailableUsers method
this.userservice.getUsers().pipe(take(1)).subscribe(users => {
        this.availableUsers = users.filter(user => 
        user.role === 'Executive' || user.role === 'Sales'
      );
    });
  }


resetAdvancedFilters(): void {
  this.filters = {
    status: '',
    assignedTo: '',
    startDate: '',
    endDate: '',
    transactionType: '',
    callOutcome: ''
  };
  this.filteredCalls = [...this.salesCalls];
  this.totalItems = this.filteredCalls.length;
  this.currentPage = 1;
  this.calculateTotalPages();
}
  loadSalesCalls(): void {
    this.callsSubscription = this.salesCallService.getSalesCalls().subscribe({
      next: (calls) => {
        this.salesCalls = calls;
        this.filteredCalls = [...calls];
        this.totalItems = calls.length;
        this.calculateTotalPages();
        
        // Load call logs for all customers
        calls.forEach(call => {
          if (call.customerId) {
            this.callLogService.getCallLogsForCustomerRealtime(call.customerId, 
              (callLogs) => {
                this.customerCallLogs[call.customerId] = callLogs;
                this.updateSalesCallWithLatestLog(call.customerId, callLogs);
              });
          }
        });
      },
      error: (err) => console.error('Error loading sales calls:', err)
    });
  }
  
  toggleColumnDropdown(): void {
    this.showColumnDropdown = !this.showColumnDropdown;
  }
  
  isColumnVisible(columnKey: string): boolean {
    return this.visibleColumns.includes(columnKey);
  }
  toggleColumnVisibility(columnKey: string): void {
    if (this.isColumnVisible(columnKey)) {
      this.visibleColumns = this.visibleColumns.filter(col => col !== columnKey);
    } else {
      this.visibleColumns = [...this.visibleColumns, columnKey];
    }
    
    // Ensure at least one column remains visible
    if (this.visibleColumns.length === 0) {
      this.visibleColumns = ['customerName']; // Default column
    }
  }
  resetColumnVisibility(): void {
    this.visibleColumns = [
      'select', 'customerName', 'mobile', 'lastTransactionDate', 
      'assignedTo', 'callStatus', 'callDate', 'notes', 'lastCallInfo'
    ];
  }  
  loadCallLogsForCustomers(calls: any[]): void {
    // Extract unique customer IDs
    const customerIds = [...new Set(calls.map(call => call.customerId))];
    
    // Listen to call logs for each customer
    customerIds.forEach(customerId => {
      if (customerId) {
        this.callLogService.getCallLogsForCustomerRealtime(customerId, 
          (callLogs) => {
            // Update the call logs for this customer
            this.customerCallLogs[customerId] = callLogs;
            
            // Update the related sales call with the latest call log
            this.updateSalesCallWithLatestLog(customerId, callLogs);
          });
      }
    });
  }

  updateSalesCallWithLatestLog(customerId: string, callLogs: any[]): void {
    if (!callLogs || callLogs.length === 0) return;
    
    const sortedLogs = [...callLogs].sort((a, b) => {
      const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt);
      const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });
    
    const latestLog = sortedLogs[0];
    
    
    // Update the sales call
    const callIndex = this.salesCalls.findIndex(call => call.customerId === customerId);
    if (callIndex >= 0) {
      this.salesCalls[callIndex] = {
        ...this.salesCalls[callIndex],
        lastCallDate: latestLog.createdAt,
        lastCallNotes: latestLog.description,
        callStatus: this.mapCallOutcomeToStatus(latestLog.callOutcome)
      };
      
      const filteredIndex = this.filteredCalls.findIndex(call => call.customerId === customerId);
      if (filteredIndex >= 0) {
        this.filteredCalls[filteredIndex] = {
          ...this.filteredCalls[filteredIndex],
          lastCallDate: latestLog.createdAt,
          lastCallNotes: latestLog.description,
          callStatus: this.mapCallOutcomeToStatus(latestLog.callOutcome)
        };
      }
    }
  }
  exportToExcel(): void {
    // Prepare data for export
    const dataForExport = this.filteredCalls.map(call => ({
      'Customer Name': call.customerName,
      'Business Name': call.businessName || '',
      'Mobile': call.mobile,
      'Last Transaction': call.lastTransactionDate ? 
        new Date(call.lastTransactionDate).toLocaleDateString() : 'None',
      'Assigned To': call.assignedTo || 'Not Assigned',
      'Call Status': call.callStatus,
        'Department': call.department || 'Not assigned',

      'Call Date': call.callDate ? 
        new Date(call.callDate).toLocaleDateString() : '',
      'Notes': call.notes || '',
      'Last Call Outcome': this.getLatestCallLog(call.customerId)?.callOutcome || '',
      'Last Call Date': this.getLatestCallLog(call.customerId)?.createdAt ? 
        new Date(this.getLatestCallLog(call.customerId).createdAt).toLocaleString() : ''
    }));

    // Create worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataForExport);
    
    // Create workbook
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'SalesCalls');
    
    // Generate file and download
    const fileName = `SalesCalls_${new Date().toISOString().slice(0,10)}.xlsx`;
    XLSX.writeFile(wb, fileName);
  }
  printPDF(): void {
    // Create new PDF
    const doc = new jsPDF();
    const title = 'Sales Calls Report';
    const currentDate = new Date().toLocaleDateString();
    
    // Add title and date
    doc.setFontSize(18);
    doc.text(title, 14, 15);
    doc.setFontSize(10);
    doc.text(`Generated on: ${currentDate}`, 14, 22);
    
    // Prepare data for PDF
    const dataForPDF = this.filteredCalls.map(call => [
      call.customerName,
      call.businessName || '',
      call.mobile,
      call.lastTransactionDate ? 
        new Date(call.lastTransactionDate).toLocaleDateString() : 'None',
      call.assignedTo || 'Not Assigned',
        call.department || 'Not assigned',

      call.callStatus,
      call.callDate ? new Date(call.callDate).toLocaleDateString() : '',
      call.notes || '',
      this.getLatestCallLog(call.customerId)?.callOutcome || ''
    ]);
    
    // Add table to PDF
    (doc as any).autoTable({
      head: [
        ['Customer Name', 'Business', 'Mobile', 'Last Transaction', 'Assigned To', 
         'Status', 'Call Date', 'Notes', 'Last Outcome']
      ],
      body: dataForPDF,
      startY: 30,
      styles: {
        fontSize: 8,
        cellPadding: 2,
        overflow: 'linebreak'
      },
      columnStyles: {
        0: {cellWidth: 25},
        1: {cellWidth: 20},
        2: {cellWidth: 20},
        3: {cellWidth: 20},
        4: {cellWidth: 20},
        5: {cellWidth: 15},
        6: {cellWidth: 15},
        7: {cellWidth: 30},
        8: {cellWidth: 20}
      }
    });
    
    // Save the PDF
    doc.save(`SalesCalls_${new Date().toISOString().slice(0,10)}.pdf`);
  }

  mapCallOutcomeToStatus(callOutcome: string): string {
    switch(callOutcome) {
      case 'Successful':
        return 'Completed';
      case 'No Answer':
        return 'Pending';
      case 'Left Message':
        return 'Follow-up';
      case 'Wrong Number':
        return 'Not Interested';
      default:
        return callOutcome || 'Pending';
    }
  }

  getCallLogsForCustomer(customerId: string): any[] {
    return this.customerCallLogs[customerId] || [];
  }

  getLatestCallLog(customerId: string): any {
    const logs = this.getCallLogsForCustomer(customerId);
    if (!logs || logs.length === 0) return null;
    
    // Sort logs by date (newest first)
    return [...logs].sort((a, b) => {
      const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt);
      const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    })[0];
  }

  applyFilters(): void {
    let filtered = [...this.salesCalls];

    // Apply status filter
    if (this.selectedStatus) {
      filtered = filtered.filter(call => call.callStatus === this.selectedStatus);
    }

    if (this.searchTerm && this.searchTerm.trim() !== '') {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(call =>
        (call.customerName && call.customerName.toLowerCase().includes(term)) ||
        (call.mobile && call.mobile.toString().includes(term)) ||
        (call.businessName && call.businessName.toLowerCase().includes(term))
      );
    }

    this.filteredCalls = filtered;
    this.totalItems = filtered.length;
    this.currentPage = 1; // Reset to first page when filters change
    this.calculateTotalPages();
  }
  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.filteredCalls.length / this.itemsPerPage);
  }
  printTable(): void {
    // Get the HTML table element
    const printContent = document.querySelector('.sales-call-table')?.outerHTML;
    
    if (!printContent) {
      console.error('Table not found for printing');
      return;
    }
  
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    
    if (!printWindow) {
      alert('Pop-up blocker might be preventing the print window. Please allow pop-ups for this site.');
      return;
    }
  
    // Build the HTML content for printing
    printWindow.document.write(`
      <html>
        <head>
          <title>Sales Calls Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #333; text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .status-pending { color: #ff9800; }
            .status-completed { color: #4caf50; }
            .status-followup { color: #2196f3; }
            .status-not-interested { color: #f44336; }
            .recent-badge { background-color: #4caf50; color: white; padding: 2px 5px; 
                           border-radius: 3px; font-size: 0.8em; }
            .no-print { display: none; }
            @page { size: auto; margin: 5mm; }
            @media print {
              body { margin: 0; padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <h1>Sales Calls Report</h1>
          <p>Generated on: ${new Date().toLocaleString()}</p>
          ${printContent}
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                window.close();
              }, 100);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  }
  // Status change handler - matching template signature
  updateCallStatus(callId: string, newStatus: string): void {
    this.salesCallService.updateSalesCall(callId, { callStatus: newStatus })
      .catch(err => console.error('Error updating call status:', err));
  }

  // Date change handler - matching template signature
  updateCallDate(callId: string, newDate: string | Date): void {
    this.salesCallService.updateSalesCall(callId, { callDate: new Date(newDate) })
      .catch(err => console.error('Error updating call date:', err));
  }

  // Notes change handler - matching template signature
  updateCallNotes(callId: string, notes: string): void {
    this.salesCallService.updateSalesCall(callId, { notes })
      .catch(err => console.error('Error updating call notes:', err));
  }

 // Update the bulkUpdateStatus method
bulkUpdateStatus(newStatus: string): void {
  if (!newStatus || this.selectedCalls.length === 0) return;

  const updates = this.selectedCalls.map(id => ({
    id,
    data: { callStatus: newStatus }
  }));

  this.salesCallService.bulkUpdateCalls(updates)
    .then(() => {
      // Update local data immediately
      this.filteredCalls = this.filteredCalls.map(call => {
        if (this.selectedCalls.includes(call.id)) {
          return { ...call, callStatus: newStatus };
        }
        return call;
      });

      this.salesCalls = this.salesCalls.map(call => {
        if (this.selectedCalls.includes(call.id)) {
          return { ...call, callStatus: newStatus };
        }
        return call;
      });

      this.selectedCalls = [];
      this.selectAll = false;
    })
    .catch(err => console.error('Error bulk updating calls:', err));
}

bulkAssignTo(userId: string): void {
  if (!userId || this.selectedCalls.length === 0) return;

  // Find the user object
  const user = this.availableUsers.find(u => u.id === userId);
  if (!user) return;

  const userName = `${user.firstName} ${user.lastName}`;
  const updates = this.selectedCalls.map(id => ({
    id,
    data: { 
      assignedTo: userName,
      assignedToId: userId,
      source: 'Sales Call',
      department: user.department
    }
  }));

  this.salesCallService.bulkUpdateCalls(updates)
    .then(() => {
      // Update local data immediately
      this.filteredCalls = this.filteredCalls.map(call => {
        if (this.selectedCalls.includes(call.id)) {
          return { 
            ...call, 
            assignedTo: userName,
            assignedToId: userId,
            source: 'Sales Call',
            department: user.department
          };
        }
        return call;
      });

      this.salesCalls = this.salesCalls.map(call => {
        if (this.selectedCalls.includes(call.id)) {
          return { 
            ...call, 
            assignedTo: userName,
            assignedToId: userId,
            source: 'Sales Call',
            department: user.department
          };
        }
        return call;
      });

      this.selectedCalls = [];
      this.selectAll = false;
    })
    .catch(err => console.error('Error bulk assigning calls:', err));
}

  // Toggle selection
  toggleCallSelection(callId: string): void {
    const index = this.selectedCalls.indexOf(callId);
    if (index === -1) {
      this.selectedCalls.push(callId);
    } else {
      this.selectedCalls.splice(index, 1);
    }
  }

  // Toggle select all
  toggleSelectAll(): void {
    if (this.selectAll) {
      this.selectedCalls = this.paginatedCalls.map(call => call.id);
    } else {
      this.selectedCalls = [];
    }
  }

  // Check if call is selected
  isSelected(callId: string): boolean {
    return this.selectedCalls.includes(callId);
  }

  // Pagination getter
  get paginatedCalls(): any[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredCalls.slice(start, start + this.itemsPerPage);
  }

  // Page change handler
  pageChanged(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

isRecentTransaction(date: Date | string | null | undefined): boolean {
  if (!date) return false;
  
  const transactionDate = typeof date === 'string' ? new Date(date) : date;
  const fourteenDaysAgo = new Date();
  fourteenDaysAgo.setDate(fourteenDaysAgo.getDate() - 14);
  
  return transactionDate >= fourteenDaysAgo;
}

  // View customer call details
  viewCustomerCallDetails(customerId: string): void {
    this.router.navigate(['/crm/customers', customerId, 'calls']);
  }
  
  // ADDED METHODS (to fix compilation errors):
  
  // Clear selection for bulk actions
  clearSelection(): void {
    this.selectedCalls = [];
    this.selectAll = false;
  }
  
  // Add new call log
  addNewCallLog(customerId: string): void {
    // Open modal or navigate to call log form
    this.router.navigate(['/crm/calls/new'], {
      queryParams: { customerId }
    });
  }
  
  // Reset filters
  resetFilters(): void {
    this.selectedStatus = '';
    this.searchTerm = '';
    this.filteredCalls = [...this.salesCalls];
    this.totalItems = this.filteredCalls.length;
    this.currentPage = 1;
    this.calculateTotalPages();
  }
  
viewCustomerDetails(customerId: string): void {
  this.router.navigate(['/crm/customers/view', customerId], {
    state: { 
      fromSalesCall: true,
      returnUrl: this.router.url 
    }
  });
}  getPageNumbers(): number[] {
    const pages: number[] = [];
    
    // Logic to show limited page numbers with ellipsis
    const totalVisiblePages = 5;
    
    if (this.totalPages <= totalVisiblePages) {
      // Show all pages if total pages are less than visible pages
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);
      
      let startPage = Math.max(2, this.currentPage - 1);
      let endPage = Math.min(this.totalPages - 1, this.currentPage + 1);
      
      // Adjust if we're at the beginning
      if (this.currentPage <= 3) {
        endPage = Math.min(totalVisiblePages - 1, this.totalPages - 1);
      }
      
      // Adjust if we're at the end
      if (this.currentPage >= this.totalPages - 2) {
        startPage = Math.max(2, this.totalPages - (totalVisiblePages - 2));
      }
      
      // Add ellipsis before middle pages if needed
      if (startPage > 2) {
        pages.push(-1); // -1 represents ellipsis
      }
      
      // Add middle pages
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
      
      // Add ellipsis after middle pages if needed
      if (endPage < this.totalPages - 1) {
        pages.push(-2); // -2 represents ellipsis
      }
      
      // Always show last page
      pages.push(this.totalPages);
    }
    
    return pages;
  }
  
  // Handle items per page change
  onItemsPerPageChange(): void {
    this.currentPage = 1; // Reset to first page
    this.calculateTotalPages();
  }}