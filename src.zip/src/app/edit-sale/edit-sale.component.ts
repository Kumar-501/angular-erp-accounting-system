import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SaleService } from '../services/sale.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CustomerService } from '../services/customer.service';
import { AccountService } from '../services/account.service';
import { ProductsService } from '../services/products.service';

interface Product {
  name: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  subtotal: number;
}

interface SalesOrder {
  customerId: string;
  billingAddress?: string;
  shippingAddress?: string;
  saleDate: string;
  status: string;
  invoiceScheme?: string;
  paymentStatus: string;
  
  invoiceNo?: string;
  document?: string;
  discountType?: string;
  transactionId?: string;
  discountAmount?: number;
  orderTax?: number; 
  sellNote?: string;
  shippingCharges?: number;
    paymentAccount: string; // required

  shippingStatus?: string;
  deliveryPerson?: string;
  shippingDocuments?: string;
  totalPayable?: number;
  paymentAmount?: number;
  paidOn?: string;
  paymentMethod?: string;
  paymentNote?: string;
  changeReturn?: number;
  balance?: number;
  products?: Product[];
  itemsTotal?: number;
  customerAge?: number | null;
  customerDob?: string | null;
  customerGender?: string;
}

interface Customer {
  id: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  businessName?: string;
  age?: number;
  gender?: string;
  email?: string;
}

@Component({
  selector: 'app-edit-sale',
  templateUrl: './edit-sale.component.html',
  styleUrls: ['./edit-sale.component.scss'],
  providers: [DatePipe]
})
export class EditSaleComponent implements OnInit {
  saleForm!: FormGroup;
  todayDate: string;
  products: Product[] = [];
  allProducts: any[] = [];
  filteredProducts: any[] = [];
  customers: any[] = [];
  accounts: any[] = [];

  productSearchTerm: string = '';
  saleId: string = '';
  isEditing: boolean = false;
  isLoading: boolean = false;
  
  itemsTotal: number = 0;

  constructor(
    private fb: FormBuilder,
    private saleService: SaleService,
    private router: Router,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private accountService: AccountService
,
    private customerService: CustomerService,
    private productService: ProductsService
  ) {
    this.todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd') || '';
  }

  ngOnInit(): void {
    this.initializeForm();
    this.setupValueChanges();
    this.loadCustomers();
    this.loadAccounts();

    this.loadProducts();
    
    this.route.params.subscribe(params => {
      this.saleId = params['id'];
      if (this.saleId) {
        this.isEditing = true;
        this.loadSaleData(this.saleId);
      }
    });
  }
loadAccounts(): void {
  this.isLoading = true;
  this.accountService.getAccounts((accounts: any[]) => {
    this.accounts = accounts;
    this.isLoading = false;
  });
}
  loadSaleData(saleId: string): void {
    this.isLoading = true;
    this.saleService.getSaleById(saleId).subscribe({
      next: (sale) => {
        // Prefill the form with sale data
        this.saleForm.patchValue({
          customer: sale.customerId,
          paymentStatus: sale.paymentStatus || 'Due',
          billingAddress: sale.billingAddress,
          shippingAddress: sale.shippingAddress,
                  paymentAccount: sale.paymentAccount || '' ,// Add this line

          saleDate: sale.saleDate,
          status: sale.status,
          invoiceScheme: sale.invoiceScheme,
          invoiceNo: sale.invoiceNo,
          document: sale.document,
          discountType: sale.discountType || 'Percentage',
          discountAmount: sale.discountAmount || 0,
          orderTax: sale.orderTax || 0,
          sellNote: sale.sellNote,
          shippingCharges: sale.shippingCharges || 0,
          totalPayable: sale.totalPayable || 0,
          shippingStatus: sale.shippingStatus,
          deliveryPerson: sale.deliveryPerson,
          transactionId: sale.transactionId || '',
          shippingDocuments: sale.shippingDocuments,
          paymentAmount: sale.paymentAmount || 0,
          paidOn: sale.paidOn || this.todayDate,
          paymentMethod: sale.paymentMethod,
          paymentNote: sale.paymentNote,
          changeReturn: sale.changeReturn || 0,
          balance: sale.balance || 0,
          customerAge: sale.customerAge || null,
          customerDob: sale.customerDob || null,
          customerGender: sale.customerGender || '',
        });

        // Load products properly
        if (sale.products && sale.products.length > 0) {
          this.products = sale.products.map((p: any) => ({
            name: p.name,
            quantity: p.quantity,
            unitPrice: p.unitPrice,
            discount: p.discount || 0,
            subtotal: p.subtotal || (p.quantity * p.unitPrice) - (p.discount || 0)
          }));
        } else {
          // If no products, initialize with empty array
          this.products = [];
        }

        this.calculateItemsTotal();
        this.calculateTotalPayable();

        // Set items total if available
        if (sale.itemsTotal) {
          this.itemsTotal = sale.itemsTotal;
        }
        
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading sale data:', error);
        alert('Error loading sale data. Please try again.');
        this.isLoading = false;
      }
    });
  }

  loadCustomers(): void {
    this.isLoading = true;
    this.customerService.getCustomers().subscribe({
      next: (customers: any[]) => {
        this.customers = customers.map(customer => ({
          ...customer,
          displayName: customer.businessName || 
                     `${customer.firstName} ${customer.middleName ? customer.middleName + ' ' : ''}${customer.lastName}`
        }));
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading customers:', error);
        this.isLoading = false;
      }
    });
  }
  
  loadProducts(): void {
    this.isLoading = true;
    this.productService.getProductsRealTime().subscribe({
      next: (products: any[]) => {
        this.allProducts = products;
        this.filteredProducts = [...products];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading products:', error);
        this.isLoading = false;
      }
    });
  }

  filterProducts(): void {
    if (!this.productSearchTerm) {
      this.filteredProducts = [...this.allProducts];
      return;
    }
    
    const searchTerm = this.productSearchTerm.toLowerCase();
    this.filteredProducts = this.allProducts.filter(product => 
      product.productName.toLowerCase().includes(searchTerm)
    );
  }
  
  initializeForm(): void {
    this.saleForm = this.fb.group({
      customer: ['', Validators.required],
      paymentStatus: ['Due', Validators.required],
      billingAddress: [''],
      shippingAddress: [''],
          paymentAccount: ['', Validators.required], // Add this line

      saleDate: [this.todayDate, Validators.required],
      transactionId: [''],
      status: ['', Validators.required],
      invoiceScheme: [''],
      invoiceNo: [{value: '', disabled: true}],
      document: [null],
      discountType: ['Percentage'],
      totalPayable: [0, Validators.required],
      discountAmount: [0, [Validators.min(0)]],
      orderTax: [0, [Validators.min(0), Validators.max(100)]],
      sellNote: [''],
      shippingCharges: [0, [Validators.min(0)]],
      shippingStatus: [''],
      deliveryPerson: [''],
      shippingDocuments: [null],
      paymentAmount: [0, [Validators.required, Validators.min(0)]],
      paidOn: [this.todayDate],
      paymentMethod: ['', Validators.required],
      paymentNote: [''],
      changeReturn: [0],
      customerAge: [null],
      customerDob: [null],
      customerGender: [''],
      balance: [0]
    });
  }

  onDynamicProductSelect(productName: string, index: number): void {
    if (!productName) {
      this.products[index].unitPrice = 0;
      this.products[index].quantity = 0;
      this.updateProduct(index);
      return;
    }

    const selectedProduct = this.allProducts.find(p => p.productName === productName);
    if (selectedProduct) {
      this.products[index].name = selectedProduct.productName;
      this.products[index].unitPrice = selectedProduct.defaultSellingPriceExcTax || 0;
      this.products[index].quantity = 1;
      this.updateProduct(index);
    }
  }

  setupValueChanges(): void {
    this.saleForm.get('discountAmount')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });
    this.saleForm.get('shippingCharges')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });
    this.saleForm.get('discountType')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });
  }

  addProduct(): void {
    // Add empty product to the array
    this.products.push({
      name: '',
      quantity: 1,
      unitPrice: 0,
      discount: 0,
      subtotal: 0
    });
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  updateProduct(index: number): void {
    const product = this.products[index];
    product.subtotal = (product.quantity * product.unitPrice) - product.discount;
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  removeProduct(index: number): void {
    this.products.splice(index, 1);
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  calculateItemsTotal(): void {
    // Only calculate from products array - no default product
    this.itemsTotal = this.products.reduce((sum, product) => sum + product.subtotal, 0);
  }

  calculateTotalPayable(): void {
    const discount = this.saleForm.get('discountAmount')?.value || 0;
    const shipping = this.saleForm.get('shippingCharges')?.value || 0;
    const tax = this.saleForm.get('orderTax')?.value || 0;

    let total = this.itemsTotal;
    
    if (this.saleForm.get('discountType')?.value === 'Percentage') {
      total -= (total * discount / 100);
    } else {
      total -= discount;
    }
    
    // Add tax calculation
    total += (total * tax / 100);
    
    total += shipping;

    this.saleForm.patchValue({ totalPayable: total.toFixed(2) });
    this.calculateBalance();
  }

  calculateBalance(): void {
    const totalPayable = this.saleForm.get('totalPayable')?.value || 0;
    const paymentAmount = this.saleForm.get('paymentAmount')?.value || 0;

    if (paymentAmount > totalPayable) {
      this.saleForm.patchValue({
        changeReturn: (paymentAmount - totalPayable).toFixed(2),
        balance: 0,
        paymentStatus: 'Paid'
      });
    } else if (paymentAmount === totalPayable) {
      this.saleForm.patchValue({
        changeReturn: 0,
        balance: 0,
        paymentStatus: 'Paid'
      });
    } else if (paymentAmount > 0) {
      this.saleForm.patchValue({
        changeReturn: 0,
        balance: (totalPayable - paymentAmount).toFixed(2),
        paymentStatus: 'Partial'
      });
    } else {
      this.saleForm.patchValue({
        changeReturn: 0,
        balance: totalPayable.toFixed(2),
        paymentStatus: 'Due'
      });
    }
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.saleForm.patchValue({ document: file.name });
    }
  }

  onShippingDocumentSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.saleForm.patchValue({ shippingDocuments: file.name });
    }
  }

  updateSale(): void {
    if (this.saleForm.invalid) {
      this.markFormGroupTouched(this.saleForm);
      const errors = this.getFormErrors();
      console.error('Form validation errors:', errors);
      alert('Please fill all required fields correctly.');
      return;
    }

    if (this.products.length === 0) {
      alert('Please add at least one product');
      return;
    }

    // Validate products
    const invalidProducts = this.products.filter(p => 
      !p.name || p.quantity <= 0 || p.unitPrice <= 0
    );

    if (invalidProducts.length > 0) {
      alert('Some products are invalid. Please check product name, quantity, and price.');
      return;
    }

    this.isLoading = true;

    // Get selected customer details
    const selectedCustomerId = this.saleForm.get('customer')?.value;
    const selectedCustomer = this.customers.find(c => c.id === selectedCustomerId);
    const customerName = selectedCustomer?.displayName || 'Unknown Customer';

    const saleData = { 
      ...this.saleForm.value,
      invoiceNo: this.saleForm.get('invoiceNo')?.value,
      customerId: selectedCustomerId,
      paymentStatus: this.saleForm.get('paymentStatus')?.value,
      customer: customerName,
      products: this.products,
          paymentAccount: this.saleForm.get('paymentAccount')?.value, // Add this line

      itemsTotal: this.itemsTotal,
      customerAge: this.saleForm.get('customerAge')?.value,
      transactionId: this.saleForm.get('transactionId')?.value,
      customerDob: this.saleForm.get('customerDob')?.value,
      customerGender: this.saleForm.get('customerGender')?.value,
      updatedAt: new Date()
    };

    console.log('Submitting sale data:', saleData);

    this.saleService.updateSale(this.saleId, saleData)
      .then(() => {
        this.isLoading = false;
        alert('Sale updated successfully!');
        this.router.navigate(['/sales-order']);
      })
      .catch(error => {
        this.isLoading = false;
        console.error('Error updating sale:', error);
        
        let errorMessage = 'Error updating sale. Please try again.';
        if (error.error) {
          if (typeof error.error === 'string') {
            errorMessage = error.error;
          } else if (error.error.message) {
            errorMessage = error.error.message;
          } else {
            errorMessage = JSON.stringify(error.error);
          }
        } else if (error.message) {
          errorMessage = error.message;
        }

        alert(errorMessage);
      });
  }

  resetForm(): void {
    if (confirm('Are you sure you want to reset the form?')) {
      this.isLoading = true;
      this.loadSaleData(this.saleId);
    }
  }

  cancelEdit(): void {
    if (confirm('Are you sure you want to cancel? All unsaved changes will be lost.')) {
      this.router.navigate(['/sales-order']);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  private getFormErrors(): any {
    const errors: any = {};
    Object.keys(this.saleForm.controls).forEach(key => {
      const control = this.saleForm.get(key);
      if (control?.errors) {
        errors[key] = control.errors;
      }
    });
    return errors;
  }
}