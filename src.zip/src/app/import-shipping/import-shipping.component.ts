import { Component } from '@angular/core';
import { SaleService } from '../services/sale.service';

@Component({
  selector: 'app-import-shipping',
  templateUrl: './import-shipping.component.html',
  styleUrls: ['./import-shipping.component.scss']
})
export class ImportShippingComponent {
  selectedFile: File | null = null;
  isLoading = false;
  importResult: { success: number; errors: number } | null = null;

  constructor(private saleService: SaleService) {}

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
    this.importResult = null;
  }

  onSubmit(): void {
    if (this.selectedFile) {
      this.isLoading = true;
      
      this.saleService.importShippingData(this.selectedFile).subscribe(
        (result) => {
          this.importResult = result;
          this.isLoading = false;
          this.selectedFile = null;
        },
        (error) => {
          console.error('Import error:', error);
          this.importResult = { success: 0, errors: 1 };
          this.isLoading = false;
        }
      );
    }
  }

  downloadTemplate(): void {
    // CSV template content with all required fields
    const csvContent = `Date,Invoice No.,Contact,Alternate Contact,Customer,Type of Service,Current Location,Billing Location,Shipping Details,Shipping Status,Shipping Charge,Added By,Payment Status
2025-05-01,INV-1001,555-1234,555-1235,John Doe,Standard Delivery,123 Main St,456 Billing Ave,Express shipping required,Delivered,10.00,Admin User,Paid
2025-05-02,INV-1002,555-5678,555-5679,Jane Smith,Premium Delivery,789 Oak St,321 Billing Rd,Handle with care,Pending,15.00,Sales Rep,Unpaid
2025-05-03,INV-1003,555-9012,555-9013,Robert Johnson,Economy Delivery,456 Pine Ave,654 Billing Blvd,Fragile items,Shipped,12.50,Manager,Partial`;
    
    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'shipping_template.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}