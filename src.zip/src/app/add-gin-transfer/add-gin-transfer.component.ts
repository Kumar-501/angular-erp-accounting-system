import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductsService } from '../services/products.service';
import { LocationService } from '../services/location.service';
import { formatDate } from '@angular/common';
import { GinTransferService, GinTransfer, GinTransferItem } from '../services/gin-transfer.service';

interface Product {
  id: string;  // This is crucial for unique identification
  productName: string;
  sku: string;  // Stock Keeping Unit - should be unique
  unit: string;
   barcode?: string;
  defaultSellingPriceExcTax: number | null;
  currentStock: number;
    location?: string; // Single location ID
  locationName?: string;
}
@Component({
  selector: 'app-add-gin-transfer',
  templateUrl: './add-gin-transfer.component.html',
  styleUrls: ['./add-gin-transfer.component.scss']
})
export class AddGinTransferComponent implements OnInit {
  ginTransferForm: FormGroup;
  locations: any[] = [];
  products: Product[] = [];
  filteredProducts: Product[] = [];
  selectedProducts: GinTransferItem[] = [];
  searchTerm: string = '';
  currentDate: string;
  showSearchResults: boolean = false;
  
  constructor(
    private fb: FormBuilder,
    private productsService: ProductsService,
    private locationService: LocationService,
    private ginTransferService: GinTransferService
  ) {
    // Initialize current date
    this.currentDate = formatDate(new Date(), 'dd-MM-yyyy HH:mm', 'en');
    
    // Initialize form with auto-generated reference number
    this.ginTransferForm = this.fb.group({
      date: [this.currentDate, Validators.required],
      referenceNo: [this.generateReferenceNumber()],
      locationFrom: ['', Validators.required],
      locationTo: ['', Validators.required],
      locationTo2: [''], // Secondary location - optional
      status: ['', Validators.required],
      shippingCharges: [0],
      additionalNotes: ['']
    });
  }

  ngOnInit(): void {
    this.loadLocations();
    this.loadProducts();
  }

  generateReferenceNumber(): string {
    const today = new Date();
    const dateString = today.getFullYear().toString() +
                      (today.getMonth() + 1).toString().padStart(2, '0') +
                      today.getDate().toString().padStart(2, '0');
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    return `GIN-${dateString}-${randomNum}`;
  }

  loadLocations() {
    this.locationService.getLocations().subscribe(locations => {
      this.locations = locations;
    });
  }

  loadProducts() {
    this.productsService.getProductsRealTime().subscribe(products => {
      this.products = products;
    });
  }

searchProducts() {
  this.showSearchResults = true;
  
  if (this.searchTerm.trim() === '') {
    this.filteredProducts = this.products.slice(0, 10);
  } else {
    const searchTermLower = this.searchTerm.toLowerCase();
    this.filteredProducts = this.products.filter(product => 
      product.productName.toLowerCase().includes(searchTermLower) ||
      (product.sku && product.sku.toLowerCase().includes(searchTermLower)) ||
      (product.barcode && product.barcode.toLowerCase().includes(searchTermLower))
    );
  }
}
 addProduct(product: Product) {
  // Check if product already exists in transfer by ID
  const existingIndex = this.selectedProducts.findIndex(p => p.productId === product.id);
  
  if (existingIndex >= 0) {
    // Product exists - increment quantity
    this.selectedProducts[existingIndex].quantity += 1;
    this.selectedProducts[existingIndex].subtotal = 
      this.selectedProducts[existingIndex].quantity * this.selectedProducts[existingIndex].unitPrice;
  } else {
    // Add new product with all identifying information
    this.selectedProducts.push({
      productId: product.id,
      productName: product.productName,
      sku: product.sku,  // Include SKU in transfer items
      barcode: product.barcode,  // Include barcode if available
      quantity: 1,
      secondaryQuantity: 0,
      unitPrice: product.defaultSellingPriceExcTax || 0,
      subtotal: product.defaultSellingPriceExcTax || 0,
      unit: product.unit,
      locationFrom: '', // Will be set from the form's locationFrom field
      currentStock: product.currentStock || 0  // Track original stock
    });
  }
  
  this.searchTerm = '';
  this.showSearchResults = false;
  this.calculateTotal();
}
  
  updateQuantity(index: number, value: any) {
    const quantity = parseInt(value);
    
    if (quantity > 0) {
      this.selectedProducts[index].quantity = quantity;
      this.selectedProducts[index].subtotal = quantity * this.selectedProducts[index].unitPrice;
      this.calculateTotal();
    }
  }

  updateSecondaryQuantity(index: number, value: any) {
    const quantity = parseInt(value);
    
    if (quantity >= 0) {
      this.selectedProducts[index].secondaryQuantity = quantity;
    }
  }
  
  removeProduct(index: number) {
    this.selectedProducts.splice(index, 1);
    this.calculateTotal();
  }

  calculateTotal(): number {
    const subtotal = this.selectedProducts.reduce((sum, product) => sum + product.subtotal, 0);
    const shippingCharges = parseFloat(this.ginTransferForm.get('shippingCharges')?.value || 0);
    return subtotal + shippingCharges;
  }

  resetForm() {
    this.ginTransferForm.reset({
      date: this.currentDate,
      referenceNo: this.generateReferenceNumber(),
      locationFrom: '',
      locationTo: '',
      locationTo2: '',
      status: '',
      shippingCharges: 0,
      additionalNotes: ''
    });
    this.selectedProducts = [];
    this.searchTerm = '';
    this.showSearchResults = false;
  }

async saveGinTransfer() {
  if (this.ginTransferForm.valid && this.ginTransferForm.value.locationFrom && this.selectedProducts.length > 0) {
    // First check for duplicate products in the transfer
    const productIds = this.selectedProducts.map(p => p.productId);
    const hasDuplicates = new Set(productIds).size !== productIds.length;
    
    if (hasDuplicates) {
      alert('Error: The same product appears multiple times in this transfer. Please combine quantities for each product.');
      return;
    }

    // Validate stock availability before proceeding
    const stockValid = await this.validateStockAvailability();
    if (!stockValid) {
      return;
    }

    const formData = this.ginTransferForm.value;
    const hasSecondaryLocation = !!formData.locationTo2;

    // Validate all items have required fields
    const invalidItems = this.selectedProducts.filter(item => 
      !item.productId || !item.productName || !item.sku || !item.unit
    );

    if (invalidItems.length > 0) {
      alert('Error: Some products are missing required information. Please check all products have SKU and unit.');
      return;
    }

    // Prepare transfer items with all required fields
    const transferItems = this.selectedProducts.map(item => ({
      productId: item.productId,
      productName: item.productName,
      sku: item.sku,
      unit: item.unit,
      locationFrom: formData.locationFrom, // Use the form's locationFrom instead of item.locationFrom
      quantity: item.quantity,
      secondaryQuantity: item.secondaryQuantity || 0,
      unitPrice: item.unitPrice || 0,
      subtotal: item.subtotal || 0,
      barcode: item.barcode || '',
      currentStock: item.currentStock || 0
    }));
    
    const ginTransfer: GinTransfer = {
      date: formData.date,
      referenceNo: formData.referenceNo,
      locationFrom: formData.locationFrom,
      locationTo: formData.locationTo,
      locationTo2: formData.locationTo2 || null,
      status: formData.status,
      items: transferItems,
      shippingCharges: formData.shippingCharges || 0,
      additionalNotes: formData.additionalNotes || '',
      totalAmount: this.calculateTotal(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    try {
      const docId = await this.ginTransferService.addGinTransfer(ginTransfer);
      console.log('GIN Transfer saved with ID:', docId);

      // Process stock movements
      for (const item of transferItems) {
        const totalQuantityFromSource = item.quantity + (hasSecondaryLocation && item.secondaryQuantity ? item.secondaryQuantity : 0);
        
        // Deduct from source location using the proper method
        try {
          await this.productsService.decreaseStock(
            item.productId, 
            formData.locationFrom, 
            totalQuantityFromSource
          );
        } catch (error) {
          console.error(`Error decreasing stock for product ${item.productName}:`, error);
          alert(`Error: ${error instanceof Error ? error.message : 'Failed to decrease stock'} for product ${item.productName}`);
          return;
        }
        
        // Add to primary destination
        try {
          await this.productsService.increaseStock(
            item.productId, 
            formData.locationTo, 
            item.quantity
          );
        } catch (error) {
          console.error(`Error increasing stock at destination for product ${item.productName}:`, error);
          // Try to restore the stock at source location
          await this.productsService.increaseStock(item.productId, formData.locationFrom, totalQuantityFromSource);
          alert(`Error: Failed to increase stock at destination for product ${item.productName}`);
          return;
        }
        
        // Add to secondary destination if specified
        if (hasSecondaryLocation && item.secondaryQuantity && item.secondaryQuantity > 0) {
          try {
            await this.productsService.increaseStock(
              item.productId, 
              formData.locationTo2, 
              item.secondaryQuantity
            );
          } catch (error) {
            console.error(`Error increasing stock at secondary destination for product ${item.productName}:`, error);
            // Try to restore the stock by reversing previous operations
            await this.productsService.decreaseStock(item.productId, formData.locationTo, item.quantity);
            await this.productsService.increaseStock(item.productId, formData.locationFrom, totalQuantityFromSource);
            alert(`Error: Failed to increase stock at secondary destination for product ${item.productName}`);
            return;
          }
        }
      }
      
      this.resetForm();
      alert('GIN Transfer saved successfully!');
      
    } catch (error) {
      console.error('Error saving GIN transfer:', error);
      alert('Error saving GIN transfer. Please try again.');
    }
  } else {
    Object.keys(this.ginTransferForm.controls).forEach(key => {
      this.ginTransferForm.get(key)?.markAsTouched();
    });
    
    if (this.selectedProducts.length === 0) {
      alert('Please add at least one product to the transfer.');
    }
    
    if (!this.ginTransferForm.value.locationFrom) {
      alert('Please select a source location (Location From).');
    }
  }
}

async validateStockAvailability(): Promise<boolean> {
    const formData = this.ginTransferForm.value;
    const hasSecondaryLocation = !!formData.locationTo2;
    
    for (const item of this.selectedProducts) {
      const requiredQuantity = item.quantity + (hasSecondaryLocation && item.secondaryQuantity ? item.secondaryQuantity : 0);
        try {
        // First try to get the correct product ID for this location
        const correctProductId = await this.getCorrectProductForLocation(item.productName, formData.locationFrom);
        const productIdToCheck = correctProductId || item.productId;
        
        const availableStock = await this.productsService.getProductStockAtLocation(
          productIdToCheck, 
          formData.locationFrom
        );
        
        
        if (availableStock < requiredQuantity) {
          alert(`Insufficient stock for product "${item.productName}". Available: ${availableStock}, Required: ${requiredQuantity}`);
          return false;
        }
        
        // Update the item with the correct product ID if it was different
        if (correctProductId && correctProductId !== item.productId) {
          item.productId = correctProductId;
        }
      } catch (error) {
        console.error(`Error checking stock for product ${item.productName}:`, error);
        alert(`Error checking stock availability for product "${item.productName}"`);
        return false;      }
    }
    
    return true;
  }

// Add method to get correct product ID for a location
  async getCorrectProductForLocation(productName: string, locationId: string): Promise<string | null> {
    try {
      const correctProduct = await this.productsService.getProductByNameAndLocation(productName, locationId);
      return correctProduct ? correctProduct.id : null;
    } catch (error) {
      console.error('Error getting correct product for location:', error);
      return null;
    }
  }
}