import { Component } from '@angular/core';

@Component({
  selector: 'app-package-subscription',
  templateUrl: './package-subscription.component.html',
  styleUrl: './package-subscription.component.scss'
})
export class PackageSubscriptionComponent {

}
