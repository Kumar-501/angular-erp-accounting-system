import { Component } from '@angular/core';

@Component({
  selector: 'app-prescription-formprescription-form',
  templateUrl: './prescription-formprescription-form.component.html',
  styleUrl: './prescription-formprescription-form.component.scss'
})
export class PrescriptionFormprescriptionFormComponent {

}
