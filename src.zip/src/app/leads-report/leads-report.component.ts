import { Component } from '@angular/core';

@Component({
  selector: 'app-leads-report',
  templateUrl: './leads-report.component.html',
  styleUrl: './leads-report.component.scss'
})
export class LeadsReportComponent {

}
