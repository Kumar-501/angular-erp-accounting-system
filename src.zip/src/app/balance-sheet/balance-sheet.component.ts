import { Component, OnInit } from '@angular/core';
import { AccountService } from '../services/account.service';
import { Firestore, collection, query, where, getDocs } from '@angular/fire/firestore';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

@Component({
  selector: 'app-balance-sheet',
  templateUrl: './balance-sheet.component.html',
  styleUrls: ['./balance-sheet.component.scss']
})
export class BalanceSheetComponent implements OnInit {
  balanceSheetDate: string = new Date().toISOString().split('T')[0];
  balanceSheetData: any = {
    equity: [],
    liabilities: [],
    assets: [],
    totals: {
      equity: 0,
      liabilities: 0,
      assets: 0
    }
  };
  isLoading = false;

  constructor(
    private accountService: AccountService,
    private firestore: Firestore
  ) {}

  ngOnInit(): void {
    this.generateBalanceSheet();
  }

  async generateBalanceSheet(): Promise<void> {
    this.isLoading = true;
    this.balanceSheetData = {
      equity: [],
      liabilities: [],
      assets: [],
      totals: {
        equity: 0,
        liabilities: 0,
        assets: 0
      }
    };

    try {
      // Get all accounts and categorize them
      const accounts = await this.getAllAccounts();
      
      // Categorize accounts into balance sheet sections
      accounts.forEach(account => {
        if (account.accountHead?.group) {
          const group = account.accountHead.group.toLowerCase();
          const value = account.openingBalance || 0;
          
          if (group === 'equity') {
            this.balanceSheetData.equity.push({
              name: account.name,
              accountNumber: account.accountNumber,
              value: value,
              accountHead: account.accountHead.value
            });
            this.balanceSheetData.totals.equity += value;
          } 
          else if (group === 'liabilities') {
            this.balanceSheetData.liabilities.push({
              name: account.name,
              accountNumber: account.accountNumber,
              value: value,
              accountHead: account.accountHead.value
            });
            this.balanceSheetData.totals.liabilities += value;
          } 
          else if (group === 'asset') {
            this.balanceSheetData.assets.push({
              name: account.name,
              accountNumber: account.accountNumber,
              value: value,
              accountHead: account.accountHead.value
            });
            this.balanceSheetData.totals.assets += value;
          }
        }
      });

      // Add profit/loss (difference between assets and liabilities+equity)
      const profitLoss = this.balanceSheetData.totals.assets - 
                        (this.balanceSheetData.totals.liabilities + this.balanceSheetData.totals.equity);
      
      if (profitLoss !== 0) {
        this.balanceSheetData.equity.push({
          name: 'Profit & Loss',
          accountNumber: '',
          value: profitLoss,
          accountHead: 'profit_loss'
        });
        this.balanceSheetData.totals.equity += profitLoss;
      }

      console.log('Balance sheet generated:', this.balanceSheetData);
    } catch (error) {
      console.error('Error generating balance sheet:', error);
    } finally {
      this.isLoading = false;
    }
  }

  async getAllAccounts(): Promise<any[]> {
    const accountsRef = collection(this.firestore, 'accounts');
    const snapshot = await getDocs(accountsRef);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(value);
  }

  exportToExcel(): void {
    try {
      // Prepare data for Excel
      const excelData = [
        ['HERBALY TOUCH AYURVEDA PRODUCTS PRIVATE LIMITED', '', '', ''],
        ['Balance Sheet', '', '', ''],
        [`As on ${new Date(this.balanceSheetDate).toLocaleDateString()}`, '', '', ''],
        ['', '', '', ''],
        ['Equity', '', '', ''],
        ...this.balanceSheetData.equity.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => [
          item.name, 
          item.accountNumber, 
          item.accountHead, 
          this.formatCurrency(item.value)
        ]),
        ['Total Equity', '', '', this.formatCurrency(this.balanceSheetData.totals.equity)],
        ['', '', '', ''],
        ['Liabilities', '', '', ''],
        ...this.balanceSheetData.liabilities.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => [
          item.name, 
          item.accountNumber, 
          item.accountHead, 
          this.formatCurrency(item.value)
        ]),
        ['Total Liabilities', '', '', this.formatCurrency(this.balanceSheetData.totals.liabilities)],
        ['', '', '', ''],
        ['Assets', '', '', ''],
        ...this.balanceSheetData.assets.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => [
          item.name, 
          item.accountNumber, 
          item.accountHead, 
          this.formatCurrency(item.value)
        ]),
        ['Total Assets', '', '', this.formatCurrency(this.balanceSheetData.totals.assets)]
      ];

      // Create worksheet
      const worksheet = XLSX.utils.aoa_to_sheet(excelData);
      
      // Create workbook
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Balance Sheet');
      
      // Generate file name
      const fileName = `Herbaly_Touch_Balance_Sheet_${this.balanceSheetDate}.xlsx`;
      
      // Export to Excel
      XLSX.writeFile(workbook, fileName);
    } catch (error) {
      console.error('Error exporting to Excel:', error);
      alert('Error exporting to Excel. Please try again.');
    }
  }

  exportToPDF(): void {
    try {
      // Create new PDF document in portrait mode
      const doc = new jsPDF('p', 'pt');
      
      // Add title
      doc.setFontSize(16);
      doc.setTextColor(40, 40, 40);
      doc.text('HERBALY TOUCH AYURVEDA PRODUCTS PRIVATE LIMITED', 40, 40);
      doc.setFontSize(14);
      doc.text('Balance Sheet', 40, 60);
      doc.setFontSize(12);
      doc.text(`As on ${new Date(this.balanceSheetDate).toLocaleDateString()}`, 40, 80);
      
      // Add Equity section
      doc.setFontSize(14);
      doc.text('Equity', 40, 120);
      doc.setFontSize(10);
      
      const equityData = this.balanceSheetData.equity.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => [
        item.name,
        item.accountNumber,
        item.accountHead,
        this.formatCurrency(item.value)
      ]);
      
      equityData.push([
        'Total Equity', '', '', this.formatCurrency(this.balanceSheetData.totals.equity)
      ]);
      
      (doc as any).autoTable({
        startY: 130,
        head: [['Account Name', 'Account Number', 'Account Head', 'Amount']],
        body: equityData,
        styles: {
          fontSize: 8,
          cellPadding: 5
        },
        headStyles: {
          fillColor: [41, 128, 185],
          textColor: 255,
          fontStyle: 'bold'
        }
      });
      
      // Add Liabilities section
      doc.setFontSize(14);
      (doc as any).lastAutoTable.finalY || 130;
      doc.text('Liabilities', 40, (doc as any).lastAutoTable.finalY + 30);
      doc.setFontSize(10);
      
      const liabilitiesData = this.balanceSheetData.liabilities.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => [
        item.name,
        item.accountNumber,
        item.accountHead,
        this.formatCurrency(item.value)
      ]);
      
      liabilitiesData.push([
        'Total Liabilities', '', '', this.formatCurrency(this.balanceSheetData.totals.liabilities)
      ]);
      
      (doc as any).autoTable({
        startY: (doc as any).lastAutoTable.finalY + 40,
        head: [['Account Name', 'Account Number', 'Account Head', 'Amount']],
        body: liabilitiesData,
        styles: {
          fontSize: 8,
          cellPadding: 5
        },
        headStyles: {
          fillColor: [41, 128, 185],
          textColor: 255,
          fontStyle: 'bold'
        }
      });
      
      // Add Assets section
      doc.setFontSize(14);
      doc.text('Assets', 40, (doc as any).lastAutoTable.finalY + 30);
      doc.setFontSize(10);
      
      const assetsData = this.balanceSheetData.assets.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => [
        item.name,
        item.accountNumber,
        item.accountHead,
        this.formatCurrency(item.value)
      ]);
      
      assetsData.push([
        'Total Assets', '', '', this.formatCurrency(this.balanceSheetData.totals.assets)
      ]);
      
      (doc as any).autoTable({
        startY: (doc as any).lastAutoTable.finalY + 40,
        head: [['Account Name', 'Account Number', 'Account Head', 'Amount']],
        body: assetsData,
        styles: {
          fontSize: 8,
          cellPadding: 5
        },
        headStyles: {
          fillColor: [41, 128, 185],
          textColor: 255,
          fontStyle: 'bold'
        }
      });
      
      // Add summary
      doc.setFontSize(12);
      doc.text('Summary', 40, (doc as any).lastAutoTable.finalY + 30);
      
      const summaryData = [
        ['Total Equity', this.formatCurrency(this.balanceSheetData.totals.equity)],
        ['Total Liabilities', this.formatCurrency(this.balanceSheetData.totals.liabilities)],
        ['Total Equity + Liabilities', this.formatCurrency(this.balanceSheetData.totals.equity + this.balanceSheetData.totals.liabilities)],
        ['Total Assets', this.formatCurrency(this.balanceSheetData.totals.assets)]
      ];
      
      (doc as any).autoTable({
        startY: (doc as any).lastAutoTable.finalY + 40,
        body: summaryData,
        styles: {
          fontSize: 10,
          cellPadding: 5
        },
        columnStyles: {
          1: { fontStyle: 'bold' }
        }
      });
      
      // Save the PDF
      doc.save(`Herbaly_Touch_Balance_Sheet_${this.balanceSheetDate}.pdf`);
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      alert('Error exporting to PDF. Please try again.');
    }
  }

  printBalanceSheet(): void {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Popup was blocked. Please allow popups for this site to print.');
      return;
    }

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Balance Sheet - HERBALY TOUCH AYURVEDA PRODUCTS PRIVATE LIMITED</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          h1, h2 { color: #333; }
          .header { text-align: center; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f2f2f2; }
          .total-row { font-weight: bold; }
          .section-title { margin-top: 20px; font-weight: bold; }
          .text-right { text-align: right; }
          @media print {
            @page { size: portrait; margin: 10mm; }
            body { margin: 0; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>HERBALY TOUCH AYURVEDA PRODUCTS PRIVATE LIMITED</h1>
          <h2>Balance Sheet</h2>
          <p>As on ${new Date(this.balanceSheetDate).toLocaleDateString()}</p>
        </div>
        
        <div class="section-title">Equity</div>
        <table>
          <thead>
            <tr>
              <th>Account Name</th>
              <th>Account Number</th>
              <th>Account Head</th>
              <th class="text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${this.balanceSheetData.equity.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => `
              <tr>
                <td>${item.name}</td>
                <td>${item.accountNumber}</td>
                <td>${item.accountHead}</td>
                <td class="text-right">${this.formatCurrency(item.value)}</td>
              </tr>
            `).join('')}
            <tr class="total-row">
              <td colspan="3">Total Equity</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.equity)}</td>
            </tr>
          </tbody>
        </table>
        
        <div class="section-title">Liabilities</div>
        <table>
          <thead>
            <tr>
              <th>Account Name</th>
              <th>Account Number</th>
              <th>Account Head</th>
              <th class="text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${this.balanceSheetData.liabilities.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => `
              <tr>
                <td>${item.name}</td>
                <td>${item.accountNumber}</td>
                <td>${item.accountHead}</td>
                <td class="text-right">${this.formatCurrency(item.value)}</td>
              </tr>
            `).join('')}
            <tr class="total-row">
              <td colspan="3">Total Liabilities</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.liabilities)}</td>
            </tr>
          </tbody>
        </table>
        
        <div class="section-title">Assets</div>
        <table>
          <thead>
            <tr>
              <th>Account Name</th>
              <th>Account Number</th>
              <th>Account Head</th>
              <th class="text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${this.balanceSheetData.assets.map((item: { name: any; accountNumber: any; accountHead: any; value: number; }) => `
              <tr>
                <td>${item.name}</td>
                <td>${item.accountNumber}</td>
                <td>${item.accountHead}</td>
                <td class="text-right">${this.formatCurrency(item.value)}</td>
              </tr>
            `).join('')}
            <tr class="total-row">
              <td colspan="3">Total Assets</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.assets)}</td>
            </tr>
          </tbody>
        </table>
        
        <div class="section-title">Summary</div>
        <table>
          <tbody>
            <tr>
              <td>Total Equity</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.equity)}</td>
            </tr>
            <tr>
              <td>Total Liabilities</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.liabilities)}</td>
            </tr>
            <tr class="total-row">
              <td>Total Equity + Liabilities</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.equity + this.balanceSheetData.totals.liabilities)}</td>
            </tr>
            <tr class="total-row">
              <td>Total Assets</td>
              <td class="text-right">${this.formatCurrency(this.balanceSheetData.totals.assets)}</td>
            </tr>
          </tbody>
        </table>
        
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
              window.close();
            }, 200);
          }
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(printContent);
    printWindow.document.close();
  }
}