import { Component } from '@angular/core';

@Component({
  selector: 'app-print-labels',
  templateUrl: './print-labels.component.html',
  styleUrl: './print-labels.component.scss'
})
export class PrintLabelsComponent {

}
