
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SaleService } from '../services/sale.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CustomerService } from '../services/customer.service';
import { ProductsService } from '../services/products.service';
import { LocationService } from '../services/location.service';
import { TypeOfServiceService, Service } from '../services/type-of-service.service';
import { UserService } from '../services/user.service';
import { CommissionService } from '../services/commission.service';
import { LeadService } from '../services/leads.service';
import { TaxService } from '../services/tax.service';
import { TaxRate, TaxGroup } from '../tax/tax.model';
import { AccountService } from '../services/account.service';
import { AuthService } from '../auth.service';
import * as bootstrap from 'bootstrap';



interface Product {
  id?: string;
  name: string;
  productName?: string; // Add this
  sku?: string; // Add this
  barcode?: string; // Add this
  currentStock?: number; // Add this
  defaultSellingPriceExcTax?: number; // Add this
  quantity: number;
  unitPrice: number;
  discount: number;
  commissionPercent?: number;
  commissionAmount?: number;
  subtotal: number;
}
interface Medicine {
  name: string;
  type: string;
  dosage?: string;
  instructions?: string;
  ingredients?: string;
  pills?: string;
  powder?: string;
  time: string;
  quantity?: string;
}
// Define the PrescriptionData interface
interface PrescriptionData {
  patientName: any;
  date: string;
  medicines: Medicine[];
    additionalNotes?: string;

  // other properties if needed
}

@Component({
  selector: 'app-add-sale',
  templateUrl: './add-sale.component.html',
  styleUrls: ['./add-sale.component.scss'],
  providers: [DatePipe]
})
export class AddSaleComponent implements OnInit {
  saleForm!: FormGroup;
  todayDate: string;
  products: Product[] = [];
  lastInteractionTime = 0;
  showProductsInterestedDropdown = false;
  productInterestedSearch = '';
  filteredProductsForInterested: any[] = [];
  prescriptions: PrescriptionData[] = [];
editingPrescriptionIndex: number | null = null;
currentPrescriptionModal: any;
  selectedProductsForInterested: any[] = [];
  selectedPaymentAccount: any = null;
  isFromLead: boolean = false;
  taxAmount: number = 0;
  shippingDocuments: File[] = [];
  showTransactionIdField = false;
  selected?: boolean; // Add this property
  leadIdToDelete: string | null = null;

  dropdownFilterFocused = false;
  availableTaxRates: TaxRate[] = [];
  availableTaxGroups: (TaxGroup & { calculatedRate: number })[] = [];
  allProducts: any[] = [];
  filteredProducts: any[] = [];
  customers: any[] = [];
  currentDate = new Date();
  Date = Date; 
  showCustomerEditPopup = false;
// In your component class

prescriptionData: PrescriptionData = {
  medicines: [{
    name: '',
    dosage: '',
    instructions: '',
    ingredients: '',
    pills: '',
    powder: '',
    time: '',
    type: ''
  }],
  patientName: undefined,
  date: ''
};



selectedCustomerForEdit: any = null;
  users: any[] = [];
  dropdownClosing = false;
  totalCommission: number = 0;
  businessLocations: any[] = [];
  showCodPopup = false;
codData: any = null;
  serviceTypes: Service[] = [];
  latestInvoiceNumber: number = 0;
  productSearchTerm: string = '';
  isFromQuotation: boolean = false;
  currentUser: string = '';
  selectedMedicineType: string = '';

  customerSearchInput: string = '';
  showCustomerDropdown: boolean = false;
  paymentAccounts: any[] = [];
  showPpServicePopup = false;
ppServiceData: any = null;
  searchTerm: string = '';

searchResults: Product[] = [];
showSearchResults: boolean = false;
// Add these to your component class
filterOptions = {
  inStockOnly: false,
  priceRange: {
    min: 0,
    max: 10000
  }
};

private searchTimeout: any;

private closeDropdownTimeout: any;



  defaultProduct: Product = {
    name: '',
    quantity: 1,
    unitPrice: 0,
    discount: 0,
    subtotal: 0,
    commissionPercent: 0,
    commissionAmount: 0
  };
  
  itemsTotal: number = 0;
  filteredCustomers: any[] = [];

  constructor(
    private fb: FormBuilder,
    private saleService: SaleService,
    private router: Router,
      private leadService: LeadService, // Add this line

    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private customerService: CustomerService,
    private productService: ProductsService,
    private accountService: AccountService,

    private locationService: LocationService,
    private userService: UserService,
    private typeOfServiceService: TypeOfServiceService,
    private commissionService: CommissionService,
    private taxService: TaxService,
    private authService: AuthService


  ) {
    this.todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd') || '';
    this.currentUser = this.getCurrentUser();
    this.checkForLeadData();

  }
  
  debugCustomerPhones() {
    console.group('Customer Phone Data');
    this.customers.forEach(customer => {
      console.log({
        name: customer.displayName,
        id: customer.id,
        mobile: customer.mobile,
        phone: customer.phone,
        altContact: customer.alternateContact
      });
    });
    console.groupEnd();
  }
  private checkForLeadData(): void {
    // Check navigation state first
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras?.state as {fromLead: boolean, leadData: any};
    
    if (state?.fromLead) {
      this.prefillFromLead(state.leadData);
      this.isFromLead = true;
      return;
    }




    
  
    // Then check local storage
    const leadData = localStorage.getItem('leadForSalesOrder');
    if (leadData) {
      try {
        const parsedData = JSON.parse(leadData);
        this.prefillFromLead(parsedData);
        this.isFromLead = true;
        localStorage.removeItem('leadForSalesOrder');
      } catch (error) {
        console.error('Error parsing lead data:', error);
      }
    }
  }


  // Add this to your component class
medicineTypes = [
  { value: 'kasayam', label: 'Kasayam (കഷായം)' },
  { value: 'buligha', label: 'Buligha (ഗുളിക)' },
  { value: 'bhasmam', label: 'Bhasmam (ഭസ്മം)' },
  { value: 'krudham', label: 'Krudham (ഘൃതം)' },
  { value: 'suranam', label: 'Suranam (ചൂർണ്ണം)' },
  { value: 'rasayanam', label: 'Rasayanam (രസായനം)' },
  { value: 'lagium', label: 'Lagium (ലേഹ്യം)' }
];

selectMedicineType(type: string): void {
  this.selectedMedicineType = type;
}

// Keep your existing addMedicineByType() and addSameMedicineType() methods
  getMedicineTypeName(type: string): string {
  const typeNames: {[key: string]: string} = {
    'kasayam': 'Kasayam (കഷായം)',
    'buligha': 'Buligha (ഗുളിക)',
    'bhasmam': 'Bhasmam (ഭസ്മം)',
    'krudham': 'Krudham (ഘൃതം)',
    'suranam': 'Suranam (ചൂർണ്ണം)',
    'rasayanam': 'Rasayanam (രസായനം)',
    'lagium': 'Lagium (ലേഹ്യം)'
  };
  return typeNames[type] || 'Medicine';

}
addSameMedicineType(): void {
  if (!this.selectedMedicineType) return;

  // Find all medicines of the same type
  const sameTypeMedicines = this.prescriptionData.medicines.filter(med => med.type === this.selectedMedicineType);
  
  if (sameTypeMedicines.length === 0) {
    // If no medicines of this type exist, add a new one
    this.addMedicineByType();
    return;
  }

  // Get the last medicine of this type
  const lastMedicine = sameTypeMedicines[sameTypeMedicines.length - 1];
  
  // Create a deep copy of the medicine
  const newMedicine: Medicine = JSON.parse(JSON.stringify(lastMedicine));
  
  // Add the new medicine to the list
  this.prescriptionData.medicines.push(newMedicine);
  
  // Focus on the first field of the new medicine
  setTimeout(() => {
    const lastIndex = this.prescriptionData.medicines.length - 1;
    const firstField = document.getElementById(`medicineName_${lastIndex}`);
    if (firstField) {
      firstField.focus();
    }
  });
}

addMedicineByType(): void {
  if (!this.selectedMedicineType) return;

  const newMedicine: Medicine = {
    name: '',
    type: this.selectedMedicineType,
    time: 'രാവിലെ / ഉച്ചയ്ക്ക് / രാത്രി'
  };

  // Set default values based on type
  switch(this.selectedMedicineType) {
    case 'kasayam':
      newMedicine.dosage = '15 ml';
      newMedicine.instructions = '';
      newMedicine.pills = '';
      newMedicine.powder = '';
      break;
    case 'buligha':
      newMedicine.pills = '';
      newMedicine.dosage = '';
      break;
    case 'bhasmam':
      newMedicine.dosage = '';
      newMedicine.quantity = '';
      break;
    // Other types don't need additional defaults
  }

  this.prescriptionData.medicines.push(newMedicine);
  this.selectedMedicineType = '';
  
  setTimeout(() => {
    const lastIndex = this.prescriptionData.medicines.length - 1;
    const firstField = document.getElementById(`medicineName_${lastIndex}`);
    if (firstField) {
      firstField.focus();
    }
  });
}



  addMedicine(): void {
  this.prescriptionData.medicines.push({
    name: '',
    dosage: '',
    instructions: '',
    ingredients: '',
    pills: '',
    powder: '',
    time: '',
    type: ''
  });




    setTimeout(() => {
    const lastIndex = this.prescriptionData.medicines.length - 1;
    const firstField = document.getElementById(`medicineName_${lastIndex}`);
    if (firstField) {
      firstField.focus();
    }
  });
}
removeMedicine(index: number): void {
  this.prescriptionData.medicines.splice(index, 1);
}

  
  private prefillFromLead(leadData: any): void {
    // Build address string
    const addressParts = [
      leadData.address,
      leadData.city,
      leadData.state,
      leadData.country,
      leadData.zipCode
    ].filter(part => part);
    
    const fullAddress = addressParts.join(', ');
  
    // Prefill customer details
    this.saleForm.patchValue({
      customerName: leadData.name,
      customerPhone: leadData.mobile,
      customerEmail: leadData.email || '',
      billingAddress: fullAddress,
      shippingAddress: fullAddress,
      sellNote: leadData.notes || '',

    });
  
    // Prefill interested products if any
    if (leadData.productsInterested && leadData.productsInterested.length > 0) {
      this.selectedProductsForInterested = [...leadData.productsInterested];
    }
  
    // Update the customer search input
    this.customerSearchInput = leadData.name;
    
    // Show message
    setTimeout(() => {
      alert('Lead details have been pre-filled. Please verify the information before proceeding.');
    }, 500);
  }
openPrescriptionModal(): void {
  this.editingPrescriptionIndex = null;
  this.prescriptionData = {
    medicines: [],
    patientName: this.saleForm.get('customerName')?.value || '',
    date: this.todayDate
  };
  
  const modalElement = document.getElementById('prescriptionModal');
  if (modalElement) {
    this.currentPrescriptionModal = new bootstrap.Modal(modalElement);
    this.currentPrescriptionModal.show();
  }
}
viewPrescription(prescription: PrescriptionData): void {
  // Open in a new window for better viewing
  const printContent = this.generatePrintContent(prescription);
  const viewWindow = window.open('', '_blank');
  if (viewWindow) {
    viewWindow.document.write(printContent);
    viewWindow.document.close();
  }
}

editPrescription(index: number): void {
  this.editingPrescriptionIndex = index;
  this.prescriptionData = JSON.parse(JSON.stringify(this.prescriptions[index]));
  
  const modalElement = document.getElementById('prescriptionModal');
  if (modalElement) {
    this.currentPrescriptionModal = new bootstrap.Modal(modalElement);
    this.currentPrescriptionModal.show();
  }
}

deletePrescription(index: number): void {
  if (confirm('Are you sure you want to delete this prescription?')) {
    this.prescriptions.splice(index, 1);
  }
}

printPrescription(): void {
  // Ensure we have the latest data from the form
  this.savePrescriptionData();
  
  // Get the current prescription data
  const prescriptionToPrint = this.editingPrescriptionIndex !== null 
    ? this.prescriptions[this.editingPrescriptionIndex]
    : this.prescriptionData;
  
  // Generate print content
  const printContent = this.generatePrintContent(prescriptionToPrint);
  
  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Wait for content to load before printing
    printWindow.onload = () => {
      printWindow.focus();
      printWindow.print();
    };
  } else {
    alert('Pop-up blocker might be preventing the print window. Please allow pop-ups for this site.');
  }
}

private generatePrintContent(prescription: PrescriptionData): string {
  // Get current date in a nice format
  const formattedDate = this.datePipe.transform(prescription.date || this.todayDate, 'MMMM d, yyyy') || this.todayDate;
  
  // Generate medicines HTML
  let medicinesHtml = '';
  prescription.medicines.forEach((medicine, index) => {
    medicinesHtml += `
      <div class="medicine-item" style="margin-bottom: 20px; page-break-inside: avoid;">
        <h4 style="font-size: 16px; margin-bottom: 8px;">${index + 1}. ${this.getMedicineTypeName(medicine.type)}</h4>
        ${this.generateMedicineDetails(medicine)}
      </div>
    `;
  });

  // Full HTML template
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Prescription - ${prescription.patientName || 'Patient'}</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; max-width: 800px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 20px; }
        .patient-info { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .footer { margin-top: 40px; text-align: right; }
        .print-button { 
          padding: 10px 20px; 
          background: #007bff; 
          color: white; 
          border: none; 
          border-radius: 4px; 
          cursor: pointer;
          margin: 20px auto;
          display: block;
        }
        @media print {
          body { padding: 0; }
          .no-print { display: none !important; }
          .page-break { page-break-after: always; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>ഹെർബലി ടച്ച് ആയുര്‍വേദ ഉല്‍പ്പന്നങ്ങള്‍ പ്രൈവറ്റ് ലിമിറ്റഡ്</h2>
        <p>First Floor, Chirackal Tower, Ayroor P.O., Ernakulam Dt., Kerala - 683 579</p>
        <p>E-mail: contact@herballytouch.com | Ph: 7034110999</p>
        <p>ഡോ. രാജന പി.ആർ., BAMS</p>
      </div>
      
      <div class="patient-info">
        <p><strong>പേര്:</strong> ${prescription.patientName || '_________________'}</p>
        <p><strong>തീയതി:</strong> ${formattedDate}</p>
      </div>
      
      <div class="prescription-items">
        ${medicinesHtml}
      </div>
      
      ${prescription.additionalNotes ? `
        <div class="additional-notes" style="margin-top: 30px;">
          <h4 style="font-size: 16px; margin-bottom: 8px;">Additional Notes:</h4>
          <p>${prescription.additionalNotes}</p>
        </div>
      ` : ''}
      
      <div class="footer">
        <p>Doctor's Signature: _________________</p>
        <p>${this.currentUser}</p>
      </div>
      
      <button class="print-button no-print" onclick="window.print()">
        Print Prescription
      </button>
      <button class="print-button no-print" onclick="window.close()" style="background: #6c757d;">
        Close Window
      </button>
      
      <script>
        // Focus the print button for better UX
        window.onload = function() {
          const printBtn = document.querySelector('.print-button');
          if (printBtn) printBtn.focus();
        };
      </script>
    </body>
    </html>
  `;
}
private getEditableFieldContent(id: string): string {
  const element = document.getElementById(id);
  return element?.textContent?.trim() || '';
}

private generateMedicineDetails(medicine: Medicine): string {
  switch(medicine.type) {
    case 'kasayam':
      return `
        <p>${medicine.name || '______'} കഷായം എടുത്ത് തിളപ്പിച്ചാറ്റിയവെള്ളം ചേർത്ത് ${medicine.instructions || '______'}</p>
        <p>ഗുളിക ${medicine.pills || '______'} പൊടി ചേർത്ത് ${medicine.powder || '______'}</p>
        <p>നേരം: ${medicine.time || 'രാവിലെ / ഉച്ചയ്ക്ക് / രാത്രി'} ഭക്ഷണത്തിനുമുൻപ് / ശേഷം സേവിക്കുക.</p>
      `;
    case 'buligha':
      return `
        <p>${medicine.name || '______'} ഗുളിക ${medicine.pills || '______'} എണ്ണം എടുത്ത് ${medicine.dosage || '______'} ml. തിളപ്പിച്ചാറ്റിയവെള്ളം ചേർത്ത്</p>
        <p>നേരം ${medicine.time || 'രാവിലെ / ഉച്ചയ്ക്ക് / രാത്രി'} ഭക്ഷണത്തിനുമുൻപ് / ശേഷം സേവിക്കുക.</p>
      `;
    case 'bhasmam':
      return `
        <p>${medicine.name || '______'} ഭസ്മം ${medicine.dosage || '______'} നുള്ള് എടുത്ത് ${medicine.quantity || '______'} ml. തേൻ / ചെറുനാരങ്ങാനീർ ചേർത്ത്</p>
        <p>നേരം ${medicine.time || 'രാവിലെ / ഉച്ചയ്ക്ക് / രാത്രി'} ഭക്ഷണത്തിനുമുൻപ് / ശേഷം സേവിക്കുക.</p>
      `;
    default:
      return `
        <p>${medicine.name || '______'} (${medicine.type || '______'})</p>
        <p>Dosage: ${medicine.dosage || '______'}</p>
        <p>Instructions: ${medicine.instructions || '______'}</p>
        <p>Time: ${medicine.time || '______'}</p>
      `;
  }
}

// Print prescription
private savePrescriptionData(): void {
  // Update patient name and date
  this.prescriptionData.patientName = this.saleForm.get('customerName')?.value || 'Unknown Patient';
  this.prescriptionData.date = this.todayDate;

  // Update each medicine with current values
  this.prescriptionData.medicines.forEach((medicine, index) => {
    // Get the editable elements
    const nameElement = document.getElementById(`medicineName_${index}`);
    const timeElement = document.getElementById(`medicineTime_${index}`);
    
    // Update basic fields
    medicine.name = nameElement?.textContent?.trim() || '';
    medicine.time = timeElement?.textContent?.trim() || 'രാവിലെ / ഉച്ചയ്ക്ക് / രാത്രി';

    // Update type-specific fields
    switch(medicine.type) {
      case 'kasayam':
        medicine.instructions = this.getEditableFieldContent(`kasayamInstructions_${index}`);
        medicine.pills = this.getEditableFieldContent(`kasayamPills_${index}`);
        medicine.powder = this.getEditableFieldContent(`kasayamPowder_${index}`);
        break;
      case 'buligha':
        medicine.pills = this.getEditableFieldContent(`bulighaPills_${index}`);
        medicine.dosage = this.getEditableFieldContent(`bulighaDosage_${index}`);
        break;
      case 'bhasmam':
        medicine.dosage = this.getEditableFieldContent(`bhasmamDosage_${index}`);
        medicine.quantity = this.getEditableFieldContent(`bhasmamQuantity_${index}`);
        break;
    }
  });
}



  
  convertToSalesOrder(lead: any): void {
    // First check if this is an existing customer
    this.customerService.checkMobileNumberExists(lead.mobile).then(exists => {
      if (exists) {
        // For existing customer - get customer data and navigate
        this.customerService.getCustomerByMobile(lead.mobile).then(customer => {
          const saleData = {
            customerData: customer,
            isExistingCustomer: true,
    prescriptions: this.prescriptions.length > 0 ? this.prescriptions : null,

            leadData: lead // Include lead data but mark as existing customer
          };
          
          localStorage.setItem('convertedLeadForSale', JSON.stringify(saleData));
          this.router.navigate(['/add-sale'], { 
            state: { 
              fromLead: true,
              leadData: saleData
            }
          });
        });
      } else {
        // For new customer - use lead data directly
        const saleData = {
          customerData: {
            name: lead.businessName || `${lead.firstName} ${lead.lastName || ''}`,
            mobile: lead.mobile,
            email: lead.email || '',
            address: lead.addressLine1 || '',
            city: lead.city || '',
            state: lead.state || '',
            country: lead.country || 'India',
            zipCode: lead.zipCode || '',
            productsInterested: lead.products || [],
            notes: lead.notes || ''
          },
          isExistingCustomer: false,
          leadData: lead
        };
  
        localStorage.setItem('convertedLeadForSale', JSON.stringify(saleData));
        this.router.navigate(['/add-sale'], { 
          state: { 
            fromLead: true,
            leadData: saleData
          }
        });
      }
    });
  }
// Add these methods to your component class
openProductDropdown(): void {
  this.showProductsInterestedDropdown = true;
  this.filterProductsForInterested();
  
}
// In add-sale.component.ts

// Update the searchCustomerByPhone method
searchCustomerByPhone(): void {
  const inputPhone = this.saleForm.get('customerPhone')?.value?.trim();
  console.log('Searching for phone:', inputPhone);

  if (!inputPhone || inputPhone.length < 5) {
    this.clearNonPhoneFields();
    return;
  }

  // Clean the phone number by removing all non-digit characters
  const cleanPhone = inputPhone.replace(/\D/g, '');

  // Try to find customer by exact match or cleaned phone number in mobile, phone, or alternateContact
  const foundCustomer = this.customers.find(customer => {
    // Check all phone fields (mobile, phone, alternateContact, landline)
    const customerPhones = [
      customer.mobile,
      customer.phone,
      customer.alternateContact,  // Now includes alternate contact in search
      customer.landline
    ].filter(phone => phone); // Remove empty values

    // Check if any phone matches exactly or after cleaning
    return customerPhones.some(phone => {
      const cleanCustomerPhone = phone?.replace(/\D/g, '') || '';
      return phone === inputPhone || cleanCustomerPhone === cleanPhone;
    });
  });

  if (foundCustomer) {
    console.log('Customer found:', foundCustomer);
    this.selectCustomer(foundCustomer);
  } else {
    console.log('No customer found with phone:', inputPhone);
    this.clearNonPhoneFields();
  }
}

selectCustomer(customer: any): void {
  // Build the full address string
  const addressParts = [
    customer.addressLine1,
    customer.addressLine2,
    customer.city,
    customer.state,
    customer.country,
    customer.zipCode
  ].filter(part => part);
  
  const fullAddress = addressParts.join(', ');
  
  // Prioritize mobile over phone number, then alternate contact, then landline
  const phoneNumber = customer.mobile || customer.phone || customer.alternateContact || customer.landline || '';

  this.saleForm.patchValue({
    customer: customer.id,
    customerName: customer.displayName,
    customerPhone: phoneNumber,  // Use the prioritized phone number here
    customerEmail: customer.email || '',
    billingAddress: fullAddress,
    shippingAddress: fullAddress,
    customerAge: customer.age || null,
    customerGender: customer.gender || '',
    customerOccupation: customer.occupation || '',
    creditLimit: customer.creditLimit || 0,
    otherData: customer.otherData || customer.notes || '',
  });
  
  this.customerSearchInput = customer.displayName;
  this.showCustomerDropdown = false;
}
findCustomerByPhone(phone: string): any {
  // Try exact match first
  let customer = this.customers.find(c => 
    c.mobile === phone || 
    c.phone === phone ||
    c.alternateContact === phone ||  // Include alternate contact
    c.landline === phone
  );
  if (customer) return customer;

  // Try removing all non-digits
  const cleanPhone = phone.replace(/\D/g, '');
  customer = this.customers.find(c => {
    const custMobile = c.mobile?.replace(/\D/g, '') || '';
    const custPhone = c.phone?.replace(/\D/g, '') || '';
    const custAlt = c.alternateContact?.replace(/\D/g, '') || '';
    const custLandline = c.landline?.replace(/\D/g, '') || '';
    return custMobile === cleanPhone || 
           custPhone === cleanPhone || 
           custAlt === cleanPhone ||  // Include alternate contact
           custLandline === cleanPhone;
  });
  
  return customer;
}





// Add these methods to your component class
onSearchInput(event: any): void {
  if (this.searchTimeout) {
    clearTimeout(this.searchTimeout);
  }
  
  this.searchTimeout = setTimeout(() => {
    this.searchProducts(event);
  }, 300);
}
// Update the searchProducts method to handle multiple selection
searchProducts(event: any) {
  const searchTerm = event.target.value.toLowerCase().trim();
  this.searchTerm = searchTerm;
  
  if (!searchTerm || searchTerm.length < 2) {
    this.searchResults = [];
    this.showSearchResults = false;
    return;
  }
  
  this.searchResults = this.allProducts
    .filter(product => {
      // Apply filters first
      if (this.filterOptions.inStockOnly && product.currentStock <= 0) {
        return false;
      }
      if (product.defaultSellingPriceExcTax < this.filterOptions.priceRange.min || 
          product.defaultSellingPriceExcTax > this.filterOptions.priceRange.max) {
        return false;
      }
      
      // Then apply search
      const searchString = [
        product.productName || product.name,
        product.sku,
        product.barcode
      ]
      .filter(field => field)
      .join(' ')
      .toLowerCase();
      
      return searchString.includes(searchTerm);
    })
    .map(product => ({
      ...product,
      productName: product.productName || product.name,
      currentStock: product.currentStock || 0,
      defaultSellingPriceExcTax: product.defaultSellingPriceExcTax || 0,
      selected: product.selected || false // Preserve selection state
    }));
  
  this.showSearchResults = this.searchResults.length > 0;
}


onProductInterestedSearch(): void {
  if (!this.productInterestedSearch) {
    this.filteredProductsForInterested = [...this.allProducts].slice(0, 10);
    return;
  }
  
  const searchTerm = this.productInterestedSearch.toLowerCase();
  this.filteredProductsForInterested = this.allProducts
    .filter(product => 
      (product.productName?.toLowerCase().includes(searchTerm) ||
      (product.sku?.toLowerCase().includes(searchTerm))
    .slice(0, 10)));
}





onSearchFocus() {
  this.showSearchResults = true;
  if (this.searchTerm) {
    this.searchProducts({ target: { value: this.searchTerm } });
  }
}
editCustomerDetails(): void {
  const customerId = this.saleForm.get('customer')?.value;
  if (!customerId) {
    alert('Please select a customer first');
    return;
  }

  // Find the customer in the customers list
  const customer = this.customers.find(c => c.id === customerId);
  if (customer) {
    // Store the customer data in local storage
    localStorage.setItem('customerToEdit', JSON.stringify(customer));
    
    // Open customers page in a new tab
    const url = this.router.createUrlTree(['/customers'], {
      queryParams: { edit: customerId }
    }).toString();
    
    window.open(url, '_blank');
  } else {
    alert('Customer not found');
  }
}
openCustomerEditForm(customer: any): void {
  // Store the customer data in local storage
  localStorage.setItem('customerToEdit', JSON.stringify(customer));
  
  // Open customers page in a new tab
  const url = this.router.createUrlTree(['/customers'], {
    queryParams: { edit: customer.id }
  }).toString();
  
  window.open(url, '_blank');
}
// add-sale.component.ts

openCustomerEditPopup(): void {
  const customerId = this.saleForm.get('customer')?.value;
  if (!customerId) {
    alert('Please select a customer first');
    return;
  }

  const customer = this.customers.find(c => c.id === customerId);
  if (customer) {
    // Get current form values for addresses (they might have been modified)
    const formBillingAddress = this.saleForm.get('billingAddress')?.value;
    const formShippingAddress = this.saleForm.get('shippingAddress')?.value;

    this.selectedCustomerForEdit = { 
      ...customer,
      isIndividual: !customer.businessName,
      firstName: customer.firstName || '',
      lastName: customer.lastName || '',
      // Use form values if they exist, otherwise fall back to customer data
      billingAddress: formBillingAddress || customer.billingAddress || customer.addressLine1 || '',
      shippingAddress: formShippingAddress || customer.shippingAddress || customer.addressLine1 || ''
    };
    this.showCustomerEditPopup = true;
  } else {
    alert('Customer not found in local list');
  }
}

onCustomerSave(updatedCustomer: any): void {
  try {
    // Update the customer in Firestore
    this.customerService.updateCustomer(updatedCustomer.id, updatedCustomer)
      .then(() => {
        // Update the form values with the edited addresses
        this.saleForm.patchValue({
          customer: updatedCustomer.id,
          customerPhone: updatedCustomer.mobile || updatedCustomer.phone || '',
          customerEmail: updatedCustomer.email || '',
          billingAddress: updatedCustomer.billingAddress,
          shippingAddress: updatedCustomer.shippingAddress
        });
        
        // Update the customer in the local list
        const index = this.customers.findIndex(c => c.id === updatedCustomer.id);
        if (index >= 0) {
          this.customers[index] = updatedCustomer;
        } else {
          this.customers.push(updatedCustomer);
        }
        
        // Update the customer search input
        this.customerSearchInput = updatedCustomer.displayName;
        
        this.showCustomerEditPopup = false;
      })
      .catch(error => {
        console.error('Error updating customer:', error);
        alert('Failed to save customer changes. Please try again.');
      });
  } catch (error) {
    console.error('Error handling customer save:', error);
    alert('An unexpected error occurred. Please try again.');
  }
}
copyBillingToShipping(): void {
  const billingAddress = this.saleForm.get('billingAddress')?.value;
  if (billingAddress) {
    this.saleForm.patchValue({
      shippingAddress: billingAddress
    });
  }
}







onCustomerEditClose(): void {
  this.showCustomerEditPopup = false;
}
onAddressChange(type: 'billing' | 'shipping') {
  // This method ensures both fields stay in sync if needed
  const billingValue = this.saleForm.get('billingAddress')?.value;
  const shippingValue = this.saleForm.get('shippingAddress')?.value;
  
  if (type === 'billing') {
    // If billing address changes, update the form control
    this.saleForm.patchValue({ billingAddress: billingValue });
  } else {
    // If shipping address changes, update the form control
    this.saleForm.patchValue({ shippingAddress: shippingValue });
  }
}

onSearchBlur() {
  setTimeout(() => {
    this.showSearchResults = false;
  }, 200);
}
highlightMatch(text: string, searchTerm: string): string {
  if (!text || !searchTerm) return text;
  
  const regex = new RegExp(searchTerm, 'gi');
  return text.replace(regex, match => 
    `<span class="highlight">${match}</span>`
  );
}
handleKeyDown(event: KeyboardEvent) {
  if (!this.showSearchResults) return;
  
  const results = document.querySelectorAll('.search-results-dropdown .list-group-item');
  
  if (event.key === 'ArrowDown') {
    event.preventDefault();
    const currentIndex = Array.from(results).findIndex(el => el === document.activeElement);
    if (currentIndex < results.length - 1) {
      (results[currentIndex + 1] as HTMLElement)?.focus();
    }
  } else if (event.key === 'ArrowUp') {
    event.preventDefault();
    const currentIndex = Array.from(results).findIndex(el => el === document.activeElement);
    if (currentIndex > 0) {
      (results[currentIndex - 1] as HTMLElement)?.focus();
    } else {
      (event.target as HTMLElement)?.focus();
    }
  } else if (event.key === 'Enter') {
    const activeElement = document.activeElement;
    if (activeElement?.classList.contains('list-group-item')) {
      const index = Array.from(results).findIndex(el => el === activeElement);
      if (index >= 0) {
        this.addProductFromSearch(this.searchResults[index]);
      }
    }
  }
}

addProductFromSearch(product: any) {
  if (product.currentStock <= 0) {
    alert(`This product "${product.productName}" is out of stock. Please choose another product.`);
    return;
  }

  // Check if product already exists in the products array
  const existingProductIndex = this.products.findIndex(p => p.name === product.productName || p.productName === product.productName);
  
  if (existingProductIndex >= 0) {
    // Increment quantity if product exists
    this.products[existingProductIndex].quantity += 1;
    this.updateProduct(existingProductIndex);
  } else {
    // Add new product with all properties
    const newProduct: Product = {
      name: product.productName,
      productName: product.productName,
      sku: product.sku,
      barcode: product.barcode,
      currentStock: product.currentStock,
      defaultSellingPriceExcTax: product.defaultSellingPriceExcTax,
      quantity: 1,
      unitPrice: product.defaultSellingPriceExcTax || 0,
      discount: 0,
      commissionPercent: this.defaultProduct.commissionPercent || 0,
      commissionAmount: 0,
      subtotal: product.defaultSellingPriceExcTax || 0
    };
    this.products.push(newProduct);
    this.updateProduct(this.products.length - 1);
  }
  
  this.clearSearch();
}
clearSearch() {
  this.searchTerm = '';
  this.searchResults = [];
  this.showSearchResults = false;
}


onProductInterestedBlur(): void {
  setTimeout(() => {
    if (!this.dropdownFilterFocused) {
      this.showProductsInterestedDropdown = false;
    }
  }, 200);
}


selectProductForInterested(product: any): void {
  if (!this.selectedProductsForInterested.some(p => p.id === product.id)) {
    this.selectedProductsForInterested.push({...product});
  }
  this.productInterestedSearch = '';
  this.showProductsInterestedDropdown = false;
  this.filterProductsForInterested();
}


  ngOnInit(): void {
    this.initializeForm();
  this.setupValueChanges();
   this.loadPaymentAccounts();
   this.prefillCurrentUser();
   this.todayDate = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd') || '';

   this.saleForm.get('totalPayable')?.valueChanges.subscribe(() => {
    this.calculateRoundOff();
  });
   this.debugCustomerPhones();
  const storedData = localStorage.getItem('convertedLeadForSale');
    if (storedData) {
      const { customerData, isExistingCustomer, leadId } = JSON.parse(storedData);
      
      // Prefill the form with customer data
      this.prefillCustomerData(customerData);
      
      // Store the lead ID for later deletion
      this.leadIdToDelete = leadId;
      
      // Clear the stored data
      localStorage.removeItem('convertedLeadForSale');
    }
  
  this.checkPhoneExists(); // Add this line
  this.debugCustomerPhones(); // Add this line

  const debugPhone = '90371744955';
  const customerExists = this.customers.some(c => 
    c.mobile === debugPhone || 
    c.phone === debugPhone ||
    c.alternateContact === debugPhone
  );
  console.log(`Customer with phone ${debugPhone} exists:`, customerExists);

    
  Promise.all([
    this.loadCustomers(),
    this.loadProducts(),
    this.loadBusinessLocations(),
    this.loadServiceTypes(),
    this.loadUsers(),
    this.loadServiceTypes(),
    this.loadUsers(),
    this.loadTaxRates(),
    this.loadTaxGroups()
  ]).then(() => {
    this.generateOrderNumber();
    this.generateInvoiceNumber();
    this.checkForConvertedLead();
    
    // Check for converted lead data
  });
  this.route.params.subscribe(params => {
    if (params['fromQuotation'] === 'true') {
      this.isFromQuotation = true;
      this.loadQuotationData();
    }
  });
}
getCurrentDate(): Date {
  return new Date();
}
onMainSearchInput(): void {
  // Clear any pending close timeout
  clearTimeout(this.closeDropdownTimeout);
  
  // Show dropdown if not already shown
 
  
  // Filter products based on main search
  this.filterProductsForInterested();
}



onDropdownFilterInput(): void {
  this.filterProductsForInterested();
}

// Add this new method
private async prefillCurrentUser(): Promise<void> {
  try {
    const currentUser = this.authService.currentUserValue;
    if (currentUser) {
      this.currentUser = currentUser.displayName || currentUser.email;
      
      // Find the user in the users list and set as default
      this.users = await this.loadUsers();
      const loggedInUser = this.users.find(u => u.id === currentUser.uid);
      
      if (loggedInUser) {
        this.saleForm.patchValue({
          addedBy: loggedInUser.id
        });
        
        // Also update the commission percentage
        const commissionPercent = await this.getAgentCommission(loggedInUser.id);
        this.defaultProduct.commissionPercent = commissionPercent;
        this.updateDefaultProduct();
      }
    }
  } catch (error) {
    console.error('Error prefilling current user:', error);
  }
}


filterProductsForInterested(): void {
  let filtered = [...this.allProducts];
  
  // Apply search filter
  if (this.productInterestedSearch) {
    const searchTerm = this.productInterestedSearch.toLowerCase();
    filtered = filtered.filter(product => 
      (product.productName?.toLowerCase().includes(searchTerm) ||
       product.sku?.toLowerCase().includes(searchTerm))
    );
  }
  
  // Apply in-stock filter
  if (this.filterOptions.inStockOnly) {
    filtered = filtered.filter(product => product.currentStock > 0);
  }
  
  // Apply price range filter
  filtered = filtered.filter(product => 
    product.defaultSellingPriceExcTax >= this.filterOptions.priceRange.min &&
    product.defaultSellingPriceExcTax <= this.filterOptions.priceRange.max
  );
  
  // Reset selection state for all products
  filtered.forEach(p => p.selected = p.selected || false);
  
  this.filteredProductsForInterested = filtered.slice(0, 50);
}


// Add these new methods
onDropdownFilterFocus(): void {
  this.dropdownFilterFocused = true;
  clearTimeout(this.closeDropdownTimeout);
}
onDropdownFilterBlur(): void {
  this.dropdownFilterFocused = false;
  setTimeout(() => {
    if (!this.showProductsInterestedDropdown) {
      this.productInterestedSearch = '';
    }
  }, 200);
}







// Add these methods to the component class
private loadTaxRates(): Promise<void> {
  return new Promise((resolve) => {
    this.taxService.getTaxRates().subscribe(rates => {
      this.availableTaxRates = rates.filter(rate => !rate.forTaxGroupOnly);
      resolve();
    });
  });
}

loadPaymentAccounts(): Promise<void> {
  return new Promise((resolve, reject) => {
    this.accountService.getAccounts((accounts: any[]) => {
      this.paymentAccounts = accounts;
      resolve();
    });
  });
}


private loadTaxGroups(): Promise<void> {
  return new Promise((resolve) => {
    this.taxService.getTaxGroups().subscribe(groups => {
      this.availableTaxGroups = groups.map(group => ({
        ...group,
        calculatedRate: this.calculateGroupRate(group.taxRates)
      }));
      resolve();
    });
  });
}

private calculateGroupRate(taxRates: TaxRate[]): number {
  // This calculates the combined rate for a tax group
  // You might need to adjust this based on your business logic
  return taxRates.reduce((total, rate) => total + rate.rate, 0);
}
calculateTotalPayable(): void {
  // Get form values
  const discount = this.saleForm.get('discountAmount')?.value || 0;
  const taxRate = this.saleForm.get('orderTax')?.value || 0;
  const shippingBeforeTax = this.saleForm.get('shippingCharges')?.value || 0;
  
  // 1. Calculate tax on shipping (separately)
  const shippingTax = shippingBeforeTax * (taxRate / 100);
  const shippingWithTax = shippingBeforeTax + shippingTax;

  // 2. Calculate products amount (with discount applied first)
  let productsTotal = this.itemsTotal;
  
  // Apply discount to products (before tax)
  if (this.saleForm.get('discountType')?.value === 'Percentage') {
    productsTotal -= (this.itemsTotal * discount / 100);
  } else {
    productsTotal -= discount;
  }

  // Calculate tax on products
  const productTax = productsTotal * (taxRate / 100);
  const productsWithTax = productsTotal + productTax;

  // 3. Calculate COD charges (separately with tax)
  const codCharges = this.codData?.packingCharge || 0;
  const codTax = codCharges * (taxRate / 100);
  const codWithTax = codCharges + codTax;

  // 4. Calculate PP service charges (separately with tax)
  const ppCharges = this.ppServiceData?.packingCharge || 0;
  const ppTax = ppCharges * (taxRate / 100);
  const ppWithTax = ppCharges + ppTax;

  // Calculate final total by summing all components
  let total = productsWithTax + shippingWithTax;
  
  if (this.codData) {
    total += codWithTax;
  }
  
  if (this.ppServiceData) {
    total += ppWithTax;
  }

  // Update the form with the calculated total before rounding
  this.saleForm.patchValue({ 
    totalPayable: parseFloat(total.toFixed(2)) 
  });
  
  // Now calculate the round-off
  this.calculateRoundOff();
  
  // Finally calculate the balance
  this.calculateBalance();
}
onTaxChange(selectedRate: string): void {
  this.saleForm.patchValue({ orderTax: parseFloat(selectedRate) || 0 });
  this.calculateTotalPayable();
}

private checkForConvertedLead(): void {
  // Check if there's a converted lead in local storage
  const convertedLead = localStorage.getItem('convertedLeadForSale');
  if (convertedLead) {
    try {
      const { customerData, isExistingCustomer } = JSON.parse(convertedLead);
      this.prefillCustomerData(customerData, isExistingCustomer);
      localStorage.removeItem('convertedLeadForSale');

      // Move this inside the method
      const foundCustomer = this.customers.find(c => c.id === customerData.id);
      if (foundCustomer) {
        this.selectCustomer(foundCustomer);
      }

      // Show message if existing customer
      if (isExistingCustomer) {
        setTimeout(() => {
          alert('Existing customer details have been pre-filled. Please verify the information before proceeding.');
        }, 500);
      }
    } catch (error) {
      console.error('Error parsing converted lead data:', error);
    }
  }
  
  // Also check navigation state
  const navigation = this.router.getCurrentNavigation();
  const state = navigation?.extras?.state;
  if (state) {
    this.prefillCustomerData(state['customerData'], state['isExistingCustomer']);
  }
}



 private prefillCustomerData(customerData: any, isExistingCustomer: boolean = false): void {
  // Build address string
  const addressParts = [
    customerData.addressLine1,
    customerData.addressLine2,
    customerData.city,
    customerData.state,
    customerData.country,
    customerData.zipCode
  ].filter(part => part);
  
  const fullAddress = addressParts.join(', ');

  // Prefill customer details - prioritize mobile over phone
  const customerPhone = customerData.mobile || customerData.phone || '';

  this.saleForm.patchValue({
    customerName: customerData.displayName || 
                `${customerData.firstName || ''} ${customerData.lastName || ''}`.trim() ||
                customerData.businessName,
    customerPhone: customerPhone,  // Use the mobile number here
    customerEmail: customerData.email || '',
    billingAddress: fullAddress,
    shippingAddress: fullAddress,
    sellNote: customerData.notes || '',
  });

  // Also set the customer field if we have an ID
  if (customerData.id) {
    this.saleForm.patchValue({
      customer: customerData.id
    });
  }

  // Prefill interested products if any
  if (customerData.productInterested && customerData.productInterested.length > 0) {
    this.selectedProductsForInterested = [...customerData.productInterested];
  }

  // Update the customer search input
  this.customerSearchInput = customerData.displayName || 
                           `${customerData.firstName || ''} ${customerData.lastName || ''}`.trim() ||
                           customerData.businessName;
}






clearNonPhoneFields() {
  const currentPhone = this.saleForm.get('customerPhone')?.value;
  this.saleForm.patchValue({
    customer: '',
    customerName: '',
    customerEmail: '',
    billingAddress: '',
    shippingAddress: '',
    // ... keep other fields as needed
    customerPhone: currentPhone // retain the entered phone
  });
}
checkPhoneExists() {
  const testPhone = '90371744955'; // The phone from your screenshot
  console.log('--- Checking for phone:', testPhone, '---');
  
  // Check all customers
  this.customers.forEach(customer => {
    console.log('Customer:', customer.displayName, '| Phone:', customer.mobile, '| Match:', 
      customer.mobile === testPhone ? 'YES' : 'NO');
  });
  
  // Check if exists
  const exists = this.customers.some(c => c.mobile === testPhone);
  console.log('Phone exists in system:', exists);
}
  private async getAgentCommission(userId: string): Promise<number> {
    return new Promise((resolve) => {
      const unsubscribe = this.commissionService.listenToSalesAgents((agents) => {
        const agent = agents.find(a => a.userId === userId);
        unsubscribe(); // Unsubscribe after getting the value
        resolve(agent ? agent.commissionPercentage : 0);
      });
    });
  }

  async onUserSelect(userId: string): Promise<void> {
    if (!userId) return;
    
    const commissionPercent = await this.getAgentCommission(userId);
    
    // Update all products with this commission percentage
    this.products.forEach(product => {
      product.commissionPercent = commissionPercent;
      this.updateProduct(this.products.indexOf(product));
    });
    
    // Also update the default product
    this.defaultProduct.commissionPercent = commissionPercent;
    this.updateDefaultProduct();
  }

  filterCustomers(): void {
    if (!this.customerSearchInput) {
      this.filteredCustomers = [...this.customers];
      return;
    }
  
    const filter = this.customerSearchInput.toUpperCase();
    
    this.filteredCustomers = this.customers.filter(customer => {
      const displayText = `${customer.displayName || ''} ${customer.contactId || ''} ${customer.mobile || ''}`.toUpperCase();
      return displayText.includes(filter);
    });
  }

 // Update loadUsers to return Promise
private loadUsers(): Promise<any[]> {
  return new Promise((resolve, reject) => {
    this.userService.getUsers().subscribe({
      next: (users: any[]) => {
        const formattedUsers = users.map(user => ({
          ...user,
          displayName: user.displayName || `${user.firstName} ${user.lastName}`.trim() || user.email
        }));
        this.users = formattedUsers;
        resolve(formattedUsers);
      },
      error: (error: any) => {
        console.error('Error loading users:', error);
        reject(error);
      }
    });
  });
}

  loadServiceTypes(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.typeOfServiceService.getServicesRealtime().subscribe({
        next: (services: Service[]) => {
          this.serviceTypes = services;
          resolve();
        },
        error: (error: any) => {
          console.error('Error loading service types:', error);
          reject(error);
        }
      });
    });
  }

  onServiceTypeChange(event: any): void {
    const serviceId = event.target.value;
    
    // Clear previous selections if switching service types
    if (this.showPpServicePopup && serviceId !== this.saleForm.get('typeOfService')?.value) {
      this.ppServiceData = null;
    }
    if (this.showCodPopup && serviceId !== this.saleForm.get('typeOfService')?.value) {
      this.codData = null;
    }
  
    const selectedService = this.serviceTypes.find(s => s.id === serviceId);
    const serviceName = selectedService?.name?.toLowerCase() || '';
  
    // Reset both popups initially
    this.showPpServicePopup = false;
    this.showCodPopup = false;
  
    // Handle PP service
    if (serviceName.includes('pp')) {
      this.showPpServicePopup = true;
      // Clear COD data if any
      this.codData = null;
      this.saleForm.patchValue({ typeOfService: serviceId });
    } 
    // Handle COD service
    else if (serviceId === 'COD' || serviceName.includes('cod')) {
      this.showCodPopup = true;
      // Clear PP data if any
      this.ppServiceData = null;
      this.saleForm.patchValue({ typeOfService: serviceId });
    } 
    // Handle other services
    else {
      this.saleForm.patchValue({ typeOfService: serviceId });
    }
  
    // Show transaction ID field only for PP services
    this.showTransactionIdField = !!selectedService?.name && 
                              (serviceName.includes('pp') || 
                               serviceName.includes('payment'));
    
    // Add validation if needed
    const transactionIdControl = this.saleForm.get('transactionId');
    if (transactionIdControl) {
      if (this.showTransactionIdField) {
        transactionIdControl.setValidators([Validators.required]);
      } else {
        transactionIdControl.clearValidators();
      }
      transactionIdControl.updateValueAndValidity();
    }
  }
// Add these new methods for COD handling
onCodFormSubmit(formData: any): void {
  this.codData = formData;
  this.showCodPopup = false;
  
  // Update shipping charges or other fields if needed
  if (formData.packingCharge) {
    const currentShipping = this.saleForm.get('shippingCharges')?.value || 0;
    this.saleForm.patchValue({
      shippingCharges: currentShipping + formData.packingCharge
    });
  }
}
onCodClose(): void {
  this.showCodPopup = false;
  
  // If COD form was closed without submission, reset the service type
  if (!this.codData) {
    this.saleForm.patchValue({
      typeOfService: ''
    });
  }
}
onPpServiceFormSubmit(formData: any): void {
  this.ppServiceData = formData;
  this.showPpServicePopup = false;
  
  // Update the transaction ID if it's not already set
  if (formData.transactionId && !this.saleForm.get('transactionId')?.value) {
    this.saleForm.patchValue({
      transactionId: formData.transactionId
    });
  }
}
onPpServiceClose(): void {
  this.showPpServicePopup = false;
  
  // If PP service form was closed without submission, reset the service type
  if (!this.ppServiceData) {
    this.saleForm.patchValue({
      typeOfService: ''
    });
  }
}


  generateOrderNumber(): void {
    this.saleService.getLatestOrderNumber().subscribe({
      next: (number) => {
        const newOrderNumber = `ORD-${new Date().getFullYear()}-${(number + 1).toString().padStart(5, '0')}`;
        this.saleForm.get('orderNo')?.setValue(newOrderNumber);
      },
      error: (error: any) => {
        console.error('Error getting latest order number:', error);
        const defaultOrder = `ORD-${new Date().getFullYear()}-00001`;
        this.saleForm.get('orderNo')?.setValue(defaultOrder);
      }
    });
  }

  getCurrentUser(): string {
    return 'Current User';
  }

  
  loadBusinessLocations(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.locationService.getLocations().subscribe({
        next: (locations: any[]) => {
          this.businessLocations = locations;
          if (locations.length > 0) {
            this.saleForm.patchValue({ businessLocation: locations[0].id });
          }
          resolve();
        },
        error: (error: any) => {
          console.error('Error loading business locations:', error);
          reject(error);
        }
      });
    });
  }

  loadQuotationData(): void {
    const quotationData = localStorage.getItem('quotationToSalesOrder');
    if (quotationData) {
      const quotation = JSON.parse(quotationData);
      localStorage.removeItem('quotationToSalesOrder');
      
      this.saleForm.patchValue({
        customer: quotation.customerId,
        billingAddress: quotation.billingAddress || '',
        shippingAddress: quotation.shippingAddress || '',
        saleDate: this.datePipe.transform(quotation.saleDate, 'yyyy-MM-dd') || this.todayDate,
        status: 'Pending',
        invoiceScheme: quotation.invoiceScheme || '',
        discountType: quotation.discountType || 'Percentage',
        discountAmount: quotation.discountAmount || 0,
        orderTax: quotation.orderTax || 0,
      paymentStatus: quotation.paymentStatus || (quotation.status === 'Pending' ? 'Due' : 'Paid'), // Smart default
        sellNote: quotation.sellNote || '',
        shippingCharges: quotation.shippingCharges || 0,
        shippingStatus: quotation.shippingStatus || '',
        deliveryPerson: quotation.deliveryPerson || '',
        totalPayable: quotation.totalPayable || 0,
        paymentAmount: 0,
        paidOn: this.todayDate,
        paymentMethod: '',
        businessLocation: quotation.businessLocation || '',
        addedBy: this.currentUser,
      });
      
      this.generateInvoiceNumber();
      
      if (quotation.salesOrder && quotation.salesOrder.length > 0) {
        this.products = quotation.salesOrder.map((item: any) => ({
          name: item.productName,
          quantity: item.quantity,
          unitPrice: item.unitPrice || 0,
          discount: item.discount || 0,
          subtotal: item.subtotal || (item.quantity * (item.unitPrice || 0))
        }));
        
        this.calculateItemsTotal();
        this.calculateTotalPayable();
      }
      
      setTimeout(() => {
        alert('Quotation data has been loaded. Please review and complete the sales order.');
      }, 500);
    }
  }

  toggleCustomerDropdown(): void {
    this.showCustomerDropdown = !this.showCustomerDropdown;
    if (this.showCustomerDropdown) {
      this.filterCustomers();
    }
  }
  toggleProductSelection(product: any): void {
    product.selected = !product.selected;
  }
  
  hasSelectedProducts(): boolean {
    return this.filteredProductsForInterested.some(p => p.selected);
  }
  getSelectedCount(): number {
    return this.filteredProductsForInterested.filter(p => p.selected).length;
  }
  addSelectedProducts(): void {
    const selectedProducts = this.filteredProductsForInterested.filter(p => p.selected);
    
    selectedProducts.forEach(product => {
      if (!this.selectedProductsForInterested.some(p => p.id === product.id)) {
        this.selectedProductsForInterested.push({...product});
      }
      // Reset selection
      product.selected = false;
    });
    
    this.productInterestedSearch = '';
    this.showProductsInterestedDropdown = false;
  }    
  generateInvoiceNumber(): void {
    this.saleService.getLatestInvoiceNumber().subscribe({
      next: (number) => {
        this.latestInvoiceNumber = number;
        const newInvoiceNumber = `INV-${new Date().getFullYear()}-${(this.latestInvoiceNumber + 1).toString().padStart(5, '0')}`;
        this.saleForm.patchValue({ invoiceNo: newInvoiceNumber });
      },
      error: (error: any) => {
        console.error('Error getting latest invoice number:', error);
        const defaultInvoice = `INV-${new Date().getFullYear()}-00001`;
        this.saleForm.patchValue({ invoiceNo: defaultInvoice });
      }
    });
  }

  
  removeInterestedProduct(product: any): void {
    this.selectedProductsForInterested = this.selectedProductsForInterested.filter(p => p.id !== product.id);
    
    // Also remove selection from filtered list if present
    const productInList = this.filteredProductsForInterested.find(p => p.id === product.id);
    if (productInList) {
      productInList.selected = false;
    }
  }

// Add this method to your component class
displayMedicineContent(medicine: Medicine): void {
  // This will show the medicine details in the UI
  // You can implement this based on how you want to display it
  console.log('Displaying medicine:', medicine);
  
  // If you want to show it in an alert for testing:
  alert(`Medicine: ${medicine.name}\nType: ${medicine.type}\nDosage: ${medicine.dosage || 'N/A'}`);
}


  // Update the loadCustomers method
loadCustomers(): Promise<void> {
  return new Promise((resolve, reject) => {
    this.customerService.getCustomers().subscribe({
      next: (customers: any[]) => {
        this.customers = customers.map(customer => ({
          ...customer,
          displayName: customer.businessName || 
                     `${customer.firstName || ''} ${customer.middleName ? customer.middleName + ' ' : ''}${customer.lastName || ''}`.trim(),
          contactId: customer.contactId || '',
          // Ensure landline is included in the customer object
          landline: customer.landline || ''
        }));
        
        this.filteredCustomers = [...this.customers];
        resolve();
      },
      error: (error: any) => {
        console.error('Error loading customers:', error);
        reject(error);
      }
    });
  });
}
  loadProducts(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.productService.getProductsRealTime().subscribe({
        next: (products: any[]) => {
          this.allProducts = products.map(p => ({
            ...p,
            productName: p.name || p.productName
          }));
          this.filteredProducts = [...this.allProducts];
          resolve();
        },
        error: (error: any) => {
          console.error('Error loading products:', error);
          reject(error);
        }
      });
    });
  }

  filterProducts(): void {
    if (!this.productSearchTerm) {
      this.filteredProducts = [...this.allProducts];
      return;
    }
    
    const searchTerm = this.productSearchTerm.toLowerCase();
    this.filteredProducts = this.allProducts.filter(product => 
      product.productName.toLowerCase().includes(searchTerm)
    );
  }
 
  initializeForm(): void {
    this.saleForm = this.fb.group({
      customer: ['', Validators.required],
      customerName: [''],
    customerPhone: ['', Validators.required],  // Make sure this exists
      transactionId: [''],
      productInterested: [''], // Add this line
      status: ['Pending', Validators.required], // Set default to 'Pending'
      paymentStatus: ['Due'],
      customerEmail: [''],
      customerAge: [null],
      customerGender: [''],
      roundOff: [0], // Add this line

      customerSearch: [''],
      customerOccupation: [''],
      creditLimit: [0],
      otherData: [''],
      paymentAccount: ['', Validators.required],

      typeOfService: [''],
      billingAddress: [''],
      shippingAddress: [''],
      saleDate: [this.todayDate, Validators.required],
      businessLocation: ['', Validators.required],
      orderNo: [{value: '', disabled: true}],
      invoiceScheme: [''],
      invoiceNo: [{value: '', disabled: true}],
      document: [null],
      discountType: ['Percentage'],
      discountAmount: [0, [Validators.min(0)]],
      orderTax: [0, [Validators.min(0), Validators.max(100)]],
      sellNote: [''],
      shippingCharges: [0, [Validators.min(0)]],
      shippingStatus: [''],
      deliveryPerson: [''],
      shippingDocuments: [null],
      totalPayable: [0],
      paymentAmount: [0, [Validators.required, Validators.min(0)]],
      paidOn: [this.todayDate],
      paymentMethod: ['', Validators.required],
      paymentNote: [''],
      changeReturn: [0],
      balance: [0],
      addedBy: ['', Validators.required]
      
    });

    this.saleForm.get('addedBy')?.valueChanges.subscribe(userId => {
      this.onUserSelect(userId);
    });
    this.saleForm.get('status')?.valueChanges.subscribe(status => {
      if (status === 'Pending') {
        this.saleForm.patchValue({ paymentStatus: 'Due' });
      }
    });
  
  }

 
onProductSelect(productName: string): void {
  if (!productName) {
    this.defaultProduct.unitPrice = 0;
    this.defaultProduct.quantity = 0;
    this.updateDefaultProduct();
    return;
  }

  const selectedProduct = this.allProducts.find(p => p.productName === productName);
  if (selectedProduct) {
    if (selectedProduct.currentStock <= 0) {
      alert(`This product "${selectedProduct.productName}" is out of stock. Please choose another product.`);
      this.defaultProduct.name = '';
      this.defaultProduct.unitPrice = 0;
      this.defaultProduct.quantity = 0;
      return;
    }
    
    this.defaultProduct.name = selectedProduct.productName;
    this.defaultProduct.unitPrice = selectedProduct.defaultSellingPriceExcTax || 0;
    this.defaultProduct.quantity = 1;
    this.updateDefaultProduct();
  }
}
// In your component

  // Load current user and prefill the addedBy field
async loadCurrentUser(): Promise<void> {
  const currentUserValue = this.authService.currentUserValue;
  if (currentUserValue) {
    this.currentUser = currentUserValue.displayName || currentUserValue.email;
    
    // Find the user in the users list and set as default
    this.users = await this.loadUsers();
    const loggedInUser = this.users.find(u => u.id === currentUserValue.uid);
    
    if (loggedInUser) {
      this.saleForm.patchValue({
        addedBy: loggedInUser.id
      });
      
      // Also update the commission percentage
      const commissionPercent = await this.getAgentCommission(loggedInUser.id);
      this.defaultProduct.commissionPercent = commissionPercent;
      this.updateDefaultProduct();
    }
  }
}




onDynamicProductSelect(productName: string, index: number): void {
  if (!productName) {
    this.products[index].unitPrice = 0;
    this.products[index].quantity = 0;
    this.updateProduct(index);
    return;
  }

 
  const selectedProduct = this.allProducts.find(p => p.productName === productName);
  if (selectedProduct) {
    if (selectedProduct.currentStock <= 0) {
      alert(`This product "${selectedProduct.productName}" is out of stock. Please choose another product.`);
      this.products[index].name = '';
      this.products[index].unitPrice = 0;
      this.products[index].quantity = 0;
      return;
    }
    
    this.products[index].name = selectedProduct.productName;
    this.products[index].unitPrice = selectedProduct.defaultSellingPriceExcTax || 0;
    this.products[index].quantity = 1;
    this.updateProduct(index);
  }
}

  setupValueChanges(): void {
    this.saleForm.get('paymentAmount')?.valueChanges.subscribe(() => {
      this.calculateBalance();
    });

    this.saleForm.get('discountAmount')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });

    this.saleForm.get('orderTax')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });

    this.saleForm.get('shippingCharges')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });

    this.saleForm.get('discountType')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });
    this.saleForm.get('addedBy')?.valueChanges.subscribe(userId => {
      this.onUserSelect(userId);
    });
  }


  updateDefaultProduct(): void {
    const product = this.defaultProduct;
    const selectedProduct = this.allProducts.find(p => p.productName === product.name);
    
    if (selectedProduct && product.quantity > selectedProduct.currentStock) {
      alert(`Cannot increase quantity. Only ${selectedProduct.currentStock} items available for "${product.name}".`);
      product.quantity = selectedProduct.currentStock;
    }
  
    const subtotalBeforeDiscount = product.quantity * product.unitPrice;
    const discountedSubtotal = subtotalBeforeDiscount - (product.discount || 0);
    
    product.commissionAmount = (product.commissionPercent || 0) / 100 * discountedSubtotal;
    product.subtotal = discountedSubtotal - product.commissionAmount;
    
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  addProduct(): void {
    if (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) {
      this.products.push({...this.defaultProduct});
      this.defaultProduct = {
        name: '',
        quantity: 0,
        unitPrice: 0,
        discount: 0,
        commissionPercent: 0,
        commissionAmount: 0,
        subtotal: 0
      };
    } else {
      this.products.push({
        name: '',
        quantity: 1,
        unitPrice: 0,
        discount: 0,
        commissionPercent: 0,
        commissionAmount: 0,
        subtotal: 0
      });
    }
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  updateProduct(index: number): void {
    const product = this.products[index];
    const selectedProduct = this.allProducts.find(p => p.productName === product.name);
    
    if (selectedProduct && product.quantity > selectedProduct.currentStock) {
      alert(`Cannot increase quantity. Only ${selectedProduct.currentStock} items available for "${product.name}".`);
      product.quantity = selectedProduct.currentStock;
    }
  
    const subtotalBeforeDiscount = product.quantity * product.unitPrice;
    const discountedSubtotal = subtotalBeforeDiscount - (product.discount || 0);
    
    product.commissionAmount = (product.commissionPercent || 0) / 100 * discountedSubtotal;
    product.subtotal = discountedSubtotal - product.commissionAmount;
    
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }
  

  removeProduct(index: number): void {
    this.products.splice(index, 1);
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  calculateItemsTotal(): void {
    const defaultProductValue = (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) 
      ? this.defaultProduct.subtotal 
      : 0;
    
    this.itemsTotal = this.products.reduce((sum, product) => sum + product.subtotal, defaultProductValue);
    this.totalCommission = this.products.reduce((sum, product) => sum + (product.commissionAmount || 0), 
      (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) 
        ? (this.defaultProduct.commissionAmount || 0) 
        : 0);
  }
  calculateShippingWithTax(): number {
    const shippingBeforeTax = this.saleForm.get('shippingCharges')?.value || 0;
    const taxRate = this.saleForm.get('orderTax')?.value || 0;
    
    // Only calculate tax on shipping charges (exclude COD/PP)
    const shippingTax = shippingBeforeTax * (taxRate / 100);
    
    return shippingBeforeTax + shippingTax;
  }
  calculateBalance(): void {
    const totalPayable = this.saleForm.get('totalPayable')?.value || 0;
    const paymentAmount = this.saleForm.get('paymentAmount')?.value || 0;
    const roundOff = this.saleForm.get('roundOff')?.value || 0;
  
    // Use the rounded total for balance calculation
    const roundedTotal = totalPayable + roundOff;
  
    if (paymentAmount > roundedTotal) {
      this.saleForm.patchValue({
        changeReturn: (paymentAmount - roundedTotal).toFixed(2),
        balance: 0
      });
    } else {
      this.saleForm.patchValue({
        changeReturn: 0,
        balance: (roundedTotal - paymentAmount).toFixed(2)
      });
    }
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.saleForm.patchValue({ document: file.name });
    }
  }
  
  onCustomerChange(event: any): void {
    const customerId = event.target.value;
    const selectedCustomer = this.customers.find(c => c.id === customerId);
    if (selectedCustomer) {
      this.saleForm.patchValue({
        customerPhone: selectedCustomer.mobile || selectedCustomer.phone || '',
        billingAddress: selectedCustomer.address || '',
        shippingAddress: selectedCustomer.address || ''
      });
      this.customerSearchInput = selectedCustomer.displayName;
    }
  }

  onCustomerBlur(): void {
    setTimeout(() => {
      this.showCustomerDropdown = false;
    }, 200);
  }
  
  onCustomerSearchFocus(): void {
    this.showCustomerDropdown = true;
    this.filterCustomers();
  }
  onShippingDocumentSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      // Convert FileList to File[] and add to existing documents
      const newFiles = Array.from(input.files) as File[];
      this.shippingDocuments = [...this.shippingDocuments, ...newFiles];
    }
  }
  removeShippingDocument(doc: File): void {
    this.shippingDocuments = this.shippingDocuments.filter(d => d !== doc);
  }

  async uploadShippingDocuments(saleId: string): Promise<string[]> {
    if (!this.shippingDocuments.length) return [];
    
    const uploadedUrls: string[] = [];
    
    // Your upload implementation here
    for (const doc of this.shippingDocuments) {
      // Simulate upload - replace with actual upload code
      const mockUrl = `https://storage.example.com/sales/${saleId}/shipping-docs/${doc.name}`;
      uploadedUrls.push(mockUrl);
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    return uploadedUrls;
  }

savePrescription(): void {
  this.savePrescriptionData();
  
  if (this.editingPrescriptionIndex !== null) {
    // Update existing prescription
    this.prescriptions[this.editingPrescriptionIndex] = this.prescriptionData;
  } else {
    // Add new prescription
    this.prescriptions.push(this.prescriptionData);
  }
  
  if (this.currentPrescriptionModal) {
    this.currentPrescriptionModal.hide();
  }
  
  // Reset for next use
  this.editingPrescriptionIndex = null;
  this.prescriptionData = {
    medicines: [],
    patientName: this.saleForm.get('customerName')?.value || '',
    date: this.todayDate
  };
}


calculateRoundOff(): void {
  const totalPayable = this.saleForm.get('totalPayable')?.value || 0;
  
  // Calculate the nearest whole number
  const roundedTotal = Math.round(totalPayable);
  
  // Calculate the difference (round off amount)
  const roundOff = roundedTotal - totalPayable;
  
  // Update the form values
  this.saleForm.patchValue({
    roundOff: parseFloat(roundOff.toFixed(2)),  // Show the round-off amount (can be positive or negative)
    totalPayable: parseFloat(totalPayable.toFixed(2))  // Keep original total payable
  });
  
  // Recalculate balance after round-off
  this.calculateBalance();
}

  

async saveSale(): Promise<void> {
  try {
    if (!this.saleForm.valid) {
      console.log('Form validation errors:', this.saleForm.errors);
      this.markFormGroupTouched(this.saleForm);
      if (this.products.length === 0 && 
          !(this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0)) {
        alert('Please add at least one product');
      }
      // List all invalid controls for debugging
      Object.keys(this.saleForm.controls).forEach(key => {
        const control = this.saleForm.get(key);
        if (control?.invalid) {
          console.log(`Invalid field: ${key}, Errors:`, control.errors);
        }
      });
      return;
    }

    // Delete lead if this sale is from a lead
    if (this.leadIdToDelete) {
      await this.leadService.deleteLead(this.leadIdToDelete);
      console.log('Lead deleted after sale creation');
    }
    
    // Get selected payment account
    const paymentAccountId = this.saleForm.get('paymentAccount')?.value;
    if (!paymentAccountId) {
      alert('Please select a payment account');
      return;
    }

    const selectedPaymentAccount = this.paymentAccounts.find(acc => acc.id === paymentAccountId);
    if (!selectedPaymentAccount) {
      alert('Selected payment account not found');
      return;
    }

    // Get customer details
    const selectedCustomerId = this.saleForm.get('customer')?.value;
    if (!selectedCustomerId) {
      alert('Please select a customer');
      return;
    }

    const selectedCustomer = this.customers.find(c => c.id === selectedCustomerId);
    const customerName = selectedCustomer?.displayName || 'Unknown Customer';

    // Get location details
    const selectedLocationId = this.saleForm.get('businessLocation')?.value;
    const selectedLocation = this.businessLocations.find(loc => loc.id === selectedLocationId);
    const locationName = selectedLocation?.name || '';

    // Get service details
    const selectedServiceId = this.saleForm.get('typeOfService')?.value;
    const selectedService = this.serviceTypes.find(s => s.id === selectedServiceId);
    const serviceName = selectedService?.name || '';

    // Get user details
    const selectedUserId = this.saleForm.get('addedBy')?.value;
    const selectedUser = this.users.find(u => u.id === selectedUserId);
    const userName = selectedUser?.displayName || selectedUser?.name || selectedUser?.email || 'System User';
    
    const commissionPercent = await this.getAgentCommission(selectedUserId);

    // Prepare products - ensure no undefined values
    const productsToSave = [...this.products].map(product => ({
      id: product.id || '',
      name: product.name || '',
      productName: product.productName || product.name || '',
      sku: product.sku || '',
      quantity: product.quantity || 0,
      unitPrice: product.unitPrice || 0,
      discount: product.discount || 0,
      commissionPercent: product.commissionPercent || 0,
      commissionAmount: product.commissionAmount || 0,
      subtotal: product.subtotal || 0
    }));

    if (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) {
      productsToSave.push({
        id: '',
        name: this.defaultProduct.name || '',
        productName: this.defaultProduct.name || '',
        sku: '',
        quantity: this.defaultProduct.quantity || 0,
        unitPrice: this.defaultProduct.unitPrice || 0,
        discount: this.defaultProduct.discount || 0,
        commissionPercent: this.defaultProduct.commissionPercent || 0,
        commissionAmount: this.defaultProduct.commissionAmount || 0,
        subtotal: this.defaultProduct.subtotal || 0
      });
    }

    if (productsToSave.length === 0) {
      alert('Please add at least one product');
      return;
    }

    // Check if this sale is coming from a lead
    let leadId: string | null = null;
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras?.state as {fromLead: boolean, leadData: any};
    
    if (state?.fromLead) {
      leadId = state.leadData?.leadId;
    } else {
      // Check local storage as fallback
      const leadData = localStorage.getItem('leadForSalesOrder');
      if (leadData) {
        try {
          const parsedData = JSON.parse(leadData);
          leadId = parsedData.leadId;
          localStorage.removeItem('leadForSalesOrder');
        } catch (error) {
          console.error('Error parsing lead data:', error);
        }
      }
    }

    // Create sale data object - ensure no undefined values
    const saleData: any = { 
      // Important form values
      ...this.saleForm.value,
      orderNo: this.saleForm.get('orderNo')?.value || '',
      invoiceNo: this.saleForm.get('invoiceNo')?.value || '',
            prescriptions: this.prescriptions.length > 0 ? this.prescriptions : null,

      
      // Payment details
      paymentAccountId: selectedPaymentAccount.id,
      paymentAccountName: selectedPaymentAccount.name || '',
      paymentAccountType: selectedPaymentAccount.accountType || '',
      ppServiceData: this.ppServiceData || null,
      hasPpService: !!this.ppServiceData,
      prescription: this.prescriptionData.medicines.length > 0 ? this.prescriptionData : null,

      status: this.saleForm.get('status')?.value || 'Pending',
      paymentStatus: this.saleForm.get('paymentStatus')?.value || 
                   (this.saleForm.get('status')?.value === 'Pending' ? 'Due' : 'Paid'),
      codData: this.codData || null,
      hasCod: !!this.codData,
      shippingDocuments: [], // Will be populated after upload

      // Customer details
      customerId: selectedCustomerId,
      customer: customerName,
      
      // Location details
      businessLocationId: selectedLocationId,
      businessLocation: locationName,
      location: locationName,
      transactionId: this.saleForm.get('transactionId')?.value || '',

      // Service details
      typeOfService: selectedServiceId || '',
      typeOfServiceName: serviceName,
      
      // Products and financial details
      products: productsToSave,
      itemsTotal: this.itemsTotal || 0,
      totalCommission: this.totalCommission || 0,
      commissionPercentage: commissionPercent || 0,
      
      // Metadata
      createdAt: new Date(),
      updatedAt: new Date(),
      convertedFromQuotation: this.isFromQuotation || false,
      convertedFromLead: !!leadId,
      leadId: leadId || '',
      addedBy: selectedUserId || '',
      addedByDisplayName: userName,
      interestedProductIds: this.selectedProductsForInterested.map(p => p.id || '') || [],
    };

    // Clean the saleData object - remove any undefined values
    Object.keys(saleData).forEach(key => {
      if (saleData[key] === undefined) {
        saleData[key] = null; // Or set to appropriate default value
      }
    });

    console.log('Sending sale data:', saleData);

    // Add the sale
    const saleId = await this.saleService.addSale(saleData);
    
    // Save prescription separately if it exists
    if (this.prescriptionData.medicines.length > 0) {
      try {
        await this.saleService.savePrescription({
          patientName: this.saleForm.get('customerName')?.value || 'Unknown Patient',
          date: this.todayDate,
          medicines: this.prescriptionData.medicines,
          doctorName: this.currentUser,
          createdAt: new Date(),
        });
      } catch (prescriptionError) {
        console.error('Error saving prescription:', prescriptionError);
      }
    }

    // If this came from a lead, update the lead status
    if (leadId) {
      try {
        await this.leadService.updateLead(leadId, {
          status: 'Converted to Sales Order',
          convertedAt: new Date(),
          convertedTo: 'sales-order/' + saleId,
          lifeStage: 'Customer',
          dealStatus: 'Won'
        });
      } catch (leadError) {
        console.error('Error updating lead status:', leadError);
      }
    }

    alert('Sale added successfully!');
    this.router.navigate(['/sales-order']);
  } catch (error: any) {
    console.error('Save sale error:', error);
    
    let errorMessage = 'Error adding sale. ';
    if (error.code) {
      errorMessage += `Error code: ${error.code}. `;
    }
    errorMessage += error.message || 'Please try again.';
    
    alert(errorMessage);
  }
}
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  resetForm(): void {
    this.saleForm.reset({
      date: new Date(),
      invoiceNo: '',
      customer: '',
      businessLocation: '',
      paymentStatus: '',
      typeOfService: '',
      addedBy: this.currentUser
    });

    this.defaultProduct = {
      name: '',
      quantity: 0,
      unitPrice: 0,
      discount: 0,
      commissionPercent: 0,
      commissionAmount: 0,
      subtotal: 0
    };
    
    this.itemsTotal = 0;
    this.totalCommission = 0;
    this.customerSearchInput = '';
    this.showCustomerDropdown = false;

    this.saleForm.markAsPristine();
    this.saleForm.markAsUntouched();
  }
}
