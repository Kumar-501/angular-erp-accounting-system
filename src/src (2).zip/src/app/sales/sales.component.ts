import { Component, OnInit, OnDestroy } from '@angular/core';
import { SaleService } from '../services/sale.service';
import { Subscription } from 'rxjs';
import * as bootstrap from 'bootstrap';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { Router } from '@angular/router';

interface SaleItem {
  customer?: string;
  saleDate?: string | Date;
  invoiceNo?: string;
  status?: string;
  currentShipment: any; // Or use a more specific interface/type

  shippingStatus?: string;
  paymentAmount?: number;
  balance?: number;
  products?: Product[];
  commissionPercentage?: number;
}

interface Product {
  id?: string;
  name: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  commissionPercent?: number;
}

interface RowData {
  'S.No': number;
  'Customer': string;
  'Sale Date': string;
  'Invoice No': string;
  'Products': string;
  'Status': string;
  'Commission %': number;
  'Shipping Status': string;
  'Payment Amount': string;
  'Balance': string;
}

interface Column {
  field: string;
  header: string;
  visible: boolean;
}

@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.scss']
})
export class SalesComponent implements OnInit, OnDestroy {
  sales: any[] = [];
  filteredSales: any[] = [];
  selectedSale: any = null;
  private salesSubscription: Subscription | undefined;
  totalEntries: number = 0;
  shipment: any; // Or use a more specific type

  currentPage: number = 1;
  entriesPerPage: number = 25;
  searchTerm: string = '';
  private modal: any;
  startDate: string = '';
  Math = Math;
  endDate: string = '';
  
  private invoiceModal: any; // New property for invoice modal
  showColumnMenu: boolean = false;
  expandedSaleId: string | null = null;
  showFilterSidebar: boolean = false;
statusFilter: string = '';
paymentMethodFilter: string = '';
shippingStatusFilter: string = '';
minCommission: number | null = null;
maxCommission: number | null = null;
  
  totalPaymentAmount: number = 0;
  totalBalance: number = 0;
  
  // Add sorting variables
  sortField: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  
  columns: Column[] = [
    { field: 'customer', header: 'Customer', visible: true },
    { field: 'saleDate', header: 'Sale Date', visible: true },
    { field: 'invoiceNo', header: 'Invoice No', visible: true },
    { field: 'products', header: 'Products', visible: true },
    { field: 'status', header: 'Status', visible: true },
    { field: 'commissionPercentage', header: 'Commission %', visible: true },
    { field: 'shippingStatus', header: 'Shipping Status', visible: true },
    { field: 'paymentAmount', header: 'Payment Amount', visible: true },
    { field: 'balance', header: 'Balance', visible: true },
    { field: 'typeOfService', header: 'Type of Service', visible: true }, 
    { field: 'customerPhone', header: 'Contact', visible: true }, // Add this
    { field: 'billingAddress', header: 'Billing Address', visible: true } // Add this line


    // Add this line

  ];

  constructor(private saleService: SaleService, private router: Router) {}

  ngOnInit(): void {
    this.modal = new bootstrap.Modal(document.getElementById('saleDetailsModal')!);
    this.invoiceModal = new bootstrap.Modal(document.getElementById('invoiceModal')!); // Initialize invoice modal
    
    this.salesSubscription = this.saleService.listenForSales().subscribe((salesData) => {
      this.sales = salesData.filter(sale => sale.status === 'Completed');
      this.sales = this.sales.map(sale => ({
        ...sale,
        products: sale.products || []
      }));
      this.filteredSales = [...this.sales];
      this.totalEntries = this.filteredSales.length;
      this.calculateTotals();
    });
  }

  // Add this method to your SalesComponent class
  resetFilters(): void {
    this.startDate = '';
    this.endDate = '';
    this.searchTerm = '';
    this.applyFilters();
  }
  toggleFilterSidebar(): void {
    this.showFilterSidebar = !this.showFilterSidebar;
  }
  resetSidebarFilters(): void {
    this.statusFilter = '';
    this.paymentMethodFilter = '';
    this.shippingStatusFilter = '';
    this.minCommission = null;
    this.maxCommission = null;
    this.startDate = '';
    this.endDate = '';
    this.applyFilters();
    this.addedByFilter = ''; // Add this line

  }
  
  ngOnDestroy(): void {
    if (this.salesSubscription) {
      this.salesSubscription.unsubscribe();
    }
  }
  
  calculateTotals(): void {
    const currentPageData = this.filteredSales.slice(
      (this.currentPage - 1) * this.entriesPerPage,
      this.currentPage * this.entriesPerPage
    );
    this.totalPaymentAmount = currentPageData.reduce((sum, sale) => 
      sum + (sale.paymentAmount ? Number(sale.paymentAmount) : 0), 0);
    
    this.totalBalance = currentPageData.reduce((sum, sale) => 
      sum + (sale.balance ? Number(sale.balance) : 0), 0);
  }
  
  get visibleColumns(): Column[] {
    return this.columns.filter(column => column.visible);
  }

  toggleColumnVisibility(): void {
    this.showColumnMenu = !this.showColumnMenu;
  }

  updateColumnVisibility(): void {
    console.log('Column visibility updated', this.columns);
  }

  viewSale(sale: any): void {
    this.selectedSale = sale;
    this.modal.show();
  }

  // New method to generate invoice (without commission details)
  generateInvoice(sale: any): void {
    this.selectedSale = sale;
    this.invoiceModal.show();
  }

  // New method to print the generated invoice
  printGeneratedInvoice(): void {
    const printContent = document.getElementById('invoicePrintContent');
    const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
    
    if (WindowPrt) {
      WindowPrt.document.write(`
        <html>
          <head>
            <title>Invoice #${this.selectedSale?.invoiceNo}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .text-center { text-align: center; }
              .mb-4 { margin-bottom: 25px; }
              .mb-0 { margin-bottom: 5px; }
              .row { display: flex; flex-wrap: wrap; margin-bottom: 20px; }
              .col-md-6 { width: 50%; box-sizing: border-box; padding: 0 15px; }
              .col-12 { width: 100%; box-sizing: border-box; padding: 0 15px; }
              table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
              th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
              th { background-color: #f2f2f2; }
              .text-end { text-align: right; }
              .fw-bold { font-weight: bold; }
              .mt-5 { margin-top: 40px; }
            </style>
          </head>
          <body>
            ${printContent?.innerHTML ?? ''}
          </body>
        </html>
      `);
      WindowPrt.document.close();
      WindowPrt.focus();
      
      // Add a small delay to ensure content is fully loaded before printing
      setTimeout(() => {
        WindowPrt.print();
        WindowPrt.close();
      }, 300);
    }
  }

  printInvoice(): void {
    const printContent = document.getElementById('saleDetailsModal');
    const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
    WindowPrt?.document.write(printContent?.innerHTML ?? '');
    WindowPrt?.document.close();
    WindowPrt?.focus();
    WindowPrt?.print();
    WindowPrt?.close();
  }

  async updateSaleStatus(sale: any, newStatus: string): Promise<void> {
    try {
      if (confirm(`Are you sure you want to change the status to ${newStatus}?`)) {
        await this.saleService.updateSale(sale.id, { 
          status: newStatus,
          updatedAt: new Date()
        });
        alert(`Sale status updated to ${newStatus}`);
      }
    } catch (error) {
      console.error('Error updating sale status:', error);
      alert('Error updating sale status');
    }
  }

  async deleteSale(saleId: string): Promise<void> {
    if (confirm('Are you sure you want to delete this sale? This will restore the product quantities to inventory.')) {
      try {
        await this.saleService.deleteSale(saleId);
        alert('Sale deleted successfully!');
      } catch (error) {
        console.error('Error deleting sale:', error);
        alert('Error deleting sale. Please try again.');
      }
    }
  }

  navigateToAddSales() {
    this.router.navigate(['/add-sale']);
  }

  applyFilters(): void {
    let filtered = [...this.sales];
    
    // Apply search term filter
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      
      filtered = filtered.filter(sale =>
        (sale.customer?.toLowerCase()?.includes(term) ||
        sale.invoiceNo?.toLowerCase()?.includes(term) ||
        sale.shippingStatus?.toLowerCase()?.includes(term) ||
        (sale.businessLocation?.toLowerCase()?.includes(term)) || // Also search businessLocation
        this.getProductNames(sale.products).toLowerCase().includes(term)
      ));
    }
    // Add this filter condition with the others
    if (this.addedByFilter) {
      filtered = filtered.filter(sale => 
        (sale.addedByDisplayName || sale.addedBy || 'System') === this.addedByFilter
      );
    }
    if (this.locationFilter) {
      filtered = filtered.filter(sale => 
        (sale.location || sale.businessLocation || '') === this.locationFilter
      );
    }
    // Apply date range filter (now from sidebar)
    if (this.startDate || this.endDate) {
      filtered = filtered.filter(sale => {
        const saleDate = new Date(sale.saleDate);
        const start = this.startDate ? new Date(this.startDate) : null;
        const end = this.endDate ? new Date(this.endDate) : null;
  
        if (start && saleDate < start) return false;
        if (end && saleDate > end) return false;
        return true;
      });
    }
  
    // Apply other sidebar filters...
    if (this.statusFilter) {
      filtered = filtered.filter(sale => sale.status === this.statusFilter);
    }
  
    if (this.paymentMethodFilter) {
      filtered = filtered.filter(sale => sale.paymentMethod === this.paymentMethodFilter);
    }
  
    if (this.shippingStatusFilter) {
      filtered = filtered.filter(sale => sale.shippingStatus === this.shippingStatusFilter);
    }
  
    if (this.minCommission !== null) {
      filtered = filtered.filter(sale => 
        (sale.commissionPercentage || 0) >= this.minCommission!
      );
    }
  
    if (this.maxCommission !== null) {
      filtered = filtered.filter(sale => 
        (sale.commissionPercentage || 0) <= this.maxCommission!
      );
    }
  
    this.filteredSales = filtered;
    
    if (this.sortField) {
      this.sortData();
    }
    
    this.totalEntries = this.filteredSales.length;
    this.currentPage = 1;
    this.calculateTotals();
  }// Add this with your other filter properties
addedByFilter: string = '';
locationFilter: string = '';

  toggleColumnMenu(): void {
    this.showColumnMenu = !this.showColumnMenu;
  }
  
isColumnVisible(columnKey: string): boolean {
  const column = this.columns.find(c => c.field === columnKey);
  return column ? column.visible : true;
}

resetColumnVisibility(): void {
  this.columns.forEach(column => {
    column.visible = true;
  });
  this.showColumnMenu = false;
}
// Add this method to get unique locations
getUniqueLocations(): string[] {
  const locations = new Set<string>();
  this.sales.forEach(sale => {
    if (sale.location || sale.businessLocation) {
      locations.add(sale.location || sale.businessLocation);
    }
  });
  return Array.from(locations).sort();
}

  // New sort method
  sortData(field?: string): void {
    // If a field is provided and it's the same as current sortField, toggle direction
    if (field) {
      if (this.sortField === field) {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
      } else {
        this.sortField = field;
        this.sortDirection = 'asc';
      }
    }

    // Sort the data based on the sortField and sortDirection
    if (this.sortField) {
      this.filteredSales.sort((a, b) => {
        let valueA: any;
        let valueB: any;

        // Handle special cases for different field types
        switch (this.sortField) {
          case 'saleDate':
            valueA = new Date(a.saleDate || 0).getTime();
            valueB = new Date(b.saleDate || 0).getTime();
            break;
          case 'paymentAmount':
          case 'balance':
          case 'commissionPercentage':
            valueA = Number(a[this.sortField] || 0);
            valueB = Number(b[this.sortField] || 0);
            break;
          case 'products':
            valueA = this.getProductsDisplayText(a.products || []);
            valueB = this.getProductsDisplayText(b.products || []);
            break;
          default:
            valueA = a[this.sortField]?.toString().toLowerCase() || '';
            valueB = b[this.sortField]?.toString().toLowerCase() || '';
        }

        // Compare values based on sort direction
        if (this.sortDirection === 'asc') {
          return valueA > valueB ? 1 : valueA < valueB ? -1 : 0;
        } else {
          return valueA < valueB ? 1 : valueA > valueB ? -1 : 0;
        }
      });
    }
    
    this.calculateTotals();
  }
  getUniqueAddedByUsers(): string[] {
    const users = new Set<string>();
    this.sales.forEach(sale => {
      if (sale.addedByDisplayName || sale.addedBy) {
        users.add(sale.addedByDisplayName || sale.addedBy);
      }
    });
    return Array.from(users).sort();
  }
  // Get sort icon class based on current sort state
  getSortIconClass(field: string): string {
    if (this.sortField !== field) {
      return 'fa-sort'; // default icon
    }
    return this.sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down';
  }

  toggleProductDetails(saleId: string): void {
    if (this.expandedSaleId === saleId) {
      this.expandedSaleId = null;
    } else {
      this.expandedSaleId = saleId;
    }
  }

  getProductsDisplayText(products: Product[]): string {
    if (!products || products.length === 0) return 'No products';
    
    if (products.length === 1) {
      return `${products[0].name} (${products[0].quantity})`;
    } else {
      return `${products[0].name} (${products[0].quantity}) and ${products.length - 1} more`;
    }
  }

  getProductNames(products: Product[]): string {
    if (!products || products.length === 0) return '';
    return products.map(p => p.name).join(' ');
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.calculateTotals();
    }
  }

  nextPage(): void {
    if (this.currentPage * this.entriesPerPage < this.totalEntries) {
      this.currentPage++;
      this.calculateTotals();
    }
  }

  exportCSV(): void {
    const headers = ['S.No', 'Customer', 'Sale Date', 'Invoice No', 'Products', 'Status', 
      'Commission %', 'Shipping Status', 'Payment Amount', 'Balance', 'Billing Address']; // 
    
    const data = this.filteredSales.map((sale, index) => {
      return {
        'S.No': index + 1,
        'Customer': sale.customer || 'N/A',
        'Sale Date': sale.saleDate ? new Date(sale.saleDate).toLocaleDateString() : 'N/A',
        'Invoice No': sale.invoiceNo || 'N/A',
        'Products': this.getProductsDisplayText(sale.products),
        'Status': sale.status || 'N/A',
        'Commission %': sale.commissionPercentage || 0,
        'Shipping Status': sale.shippingStatus || 'N/A',
        'Billing Address': sale.billingAddress || 'N/A' ,// Add this line

        'Payment Amount': sale.paymentAmount !== undefined ? `$${Number(sale.paymentAmount).toFixed(2)}` : '$0.00',
        'Balance': sale.balance !== undefined ? `$${Number(sale.balance).toFixed(2)}` : '$0.00'
      };
    });

    const csv = this.convertToCSV(data, headers);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'completed_sales_data.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  private convertToCSV(data: any[], headers: string[]): string {
    const headerString = headers.join(',');
    const rowStrings = data.map(row => 
      headers.map(fieldName => 
        `"${(row[fieldName] ?? '').toString().replace(/"/g, '""')}"`
      ).join(',')
    );
    
    return [headerString, ...rowStrings].join('\n');
  }

  exportExcel(): void {
    const headers = ['S.No', 'Customer', 'Sale Date', 'Invoice No', 'Products', 'Status', 'Commission %', 'Shipping Status', 'Payment Amount', 'Balance'];
    
    const data = this.filteredSales.map((sale, index) => {
      return [
        index + 1,
        sale.customer || 'N/A',
        sale.saleDate ? new Date(sale.saleDate).toLocaleDateString() : 'N/A',
        sale.invoiceNo || 'N/A',
        this.getProductsDisplayText(sale.products),
        sale.status || 'N/A',
        sale.commissionPercentage || 0,
        sale.shippingStatus || 'N/A',
        sale.paymentAmount !== undefined ? `$${Number(sale.paymentAmount).toFixed(2)}` : '$0.00',
        sale.balance !== undefined ? `$${Number(sale.balance).toFixed(2)}` : '$0.00'
      ];
    });

    const worksheet = XLSX.utils.aoa_to_sheet([headers, ...data]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Completed Sales');
    
    XLSX.writeFile(workbook, 'completed_sales_data.xlsx');
  }

  printData(): void {
    const printContent = document.querySelector('.table-responsive')?.innerHTML;
    const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
    
    WindowPrt?.document.write(`
      <html>
        <head>
          <title>Completed Sales Data</title>
          <style>
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .no-print { display: none; }
          </style>
        </head>
        <body>
          <h2>Completed Sales Data</h2>
          <p>Generated on: ${new Date().toLocaleString()}</p>
          ${printContent}
          <script>
            setTimeout(() => {
              window.print();
              window.close();
            }, 500);
          </script>
        </body>
      </html>
    `);
    
    WindowPrt?.document.close();
  }

  exportPDF(): void {
    const headers = ['S.No', 'Customer', 'Sale Date', 'Invoice No', 'Products', 'Status', 'Commission %', 'Shipping Status', 'Payment Amount', 'Balance'];
    
    const data = this.filteredSales.map((sale, index) => {
      return [
        index + 1,
        sale.customer || 'N/A',
        sale.saleDate ? new Date(sale.saleDate).toLocaleDateString() : 'N/A',
        sale.invoiceNo || 'N/A',
        this.getProductsDisplayText(sale.products),
        sale.status || 'N/A',
        sale.commissionPercentage || 0,
        sale.shippingStatus || 'N/A',
        sale.paymentAmount !== undefined ? `$${Number(sale.paymentAmount).toFixed(2)}` : '$0.00',
        sale.balance !== undefined ? `$${Number(sale.balance).toFixed(2)}` : '$0.00'
      ];
    });

    const doc = new jsPDF({ orientation: 'landscape' });
    doc.text('Completed Sales Report', 14, 15);
    
    (doc as any).autoTable({
      head: [headers],
      body: data,
      startY: 25,
      margin: { top: 10 },
      theme: 'grid',
      headStyles: {
        fillColor: [22, 160, 133]
      }
    });
    
    doc.save('completed-sales-report.pdf');
  }
  
  initiateReturn(sale: any): void {
    if (confirm(`Initiate return for invoice #${sale.invoiceNo}?`)) {
      this.router.navigate(['/sell-return'], {
        state: { saleData: sale }
      });
    }
  }
}