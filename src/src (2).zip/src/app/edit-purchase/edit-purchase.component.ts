import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { PurchaseService } from '../services/purchase.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SupplierService } from '../services/supplier.service';
import { LocationService } from '../services/location.service';
import { ProductsService } from '../services/products.service';
import { AuthService } from '../auth.service';
import { UserService } from '../services/user.service';

interface Supplier {
  id: string;
  contactId?: string;
  businessName?: string;
  firstName?: string;
  lastName?: string;
  isIndividual?: boolean;
  addressLine1?: string;
}

interface Product {
  id?: string;
  productId?: string;
  productName: string;
  quantity: number;
  unitCost: number;
  discountPercent: number;
  unitCostBeforeTax: number;
  subtotal: number;
  taxAmount: number;
  lineTotal: number;
  profitMargin: number;
  sellingPrice: number;
  batchNumber: string;
  expiryDate: string;
  taxRate: number;
}

@Component({
  selector: 'app-edit-purchase',
  templateUrl: './edit-purchase.component.html',
  styleUrls: ['./edit-purchase.component.scss']
})
export class EditPurchaseComponent implements OnInit {
  purchaseForm!: FormGroup;
  suppliers: Supplier[] = [];
  businessLocations: any[] = [];
  selectedSupplier: Supplier | null = null;
  totalItems = 0;
  netTotalAmount = 0;
  totalTax = 0;
  users: any[] = [];
  productsList: any[] = [];
  purchaseId: string | null = null;
  currentUser: any = null;
  isLoading = true;
  originalPurchaseData: any = null;
  taxRates = [0, 5, 10, 12, 18, 28];

  constructor(
    private fb: FormBuilder,
    private purchaseService: PurchaseService,
    private supplierService: SupplierService,
    private locationService: LocationService,
    public router: Router,
    private productsService: ProductsService,
    private route: ActivatedRoute,
    private authService: AuthService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadSuppliers();
    this.loadBusinessLocations();
    this.loadProducts();
    this.getCurrentUser();
    this.loadUsers();
    
    this.route.paramMap.subscribe(params => {
      this.purchaseId = params.get('id');
      if (this.purchaseId) {
        this.loadPurchaseData(this.purchaseId);
      } else {
        this.router.navigate(['/list-purchase']);
      }
    });
  }

  loadUsers(): void {
    this.userService.getUsers().subscribe(users => {
      this.users = users;
    });
  }

  getCurrentUser(): void {
    this.authService.getCurrentUser().subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.purchaseForm.patchValue({
          addedBy: {
            id: user.uid,
            name: user.displayName || user.email,
            email: user.email
          },
          assignedTo: user.uid
        });
      }
    });
  }

  loadPurchaseData(purchaseId: string): void {
    this.purchaseService.getPurchaseById(purchaseId)
      .then((purchaseData) => {
        if (purchaseData) {
          this.originalPurchaseData = purchaseData;
          this.prefillForm(purchaseData);
          this.isLoading = false;
        }
      })
      .catch((err: any) => {
        console.error('Error loading purchase:', err);
        this.router.navigate(['/list-purchase']);
      });
  }

  prefillForm(purchaseData: any): void {
    const supplierId = purchaseData.supplierId || '';
    
    this.purchaseForm.patchValue({
      supplierId: supplierId,
      supplierName: purchaseData.supplierName || '',
      address: purchaseData.address || '',
      referenceNo: purchaseData.referenceNo || '',
      purchaseDate: this.formatDateForInput(purchaseData.purchaseDate),
      purchaseStatus: purchaseData.purchaseStatus || '',
      businessLocation: purchaseData.businessLocation || '',
      payTerm: purchaseData.payTerm || '',
      additionalNotes: purchaseData.additionalNotes || '',
      shippingCharges: purchaseData.shippingCharges || 0,
      paymentAmount: purchaseData.paymentAmount || 0,
      paidOn: this.formatDateForInput(purchaseData.paidOn || purchaseData.purchaseDate),
      paymentMethod: purchaseData.paymentMethod || '',
      paymentNote: purchaseData.paymentNote || '',
      balance: purchaseData.balance || 0,
      totalPayable: purchaseData.totalPayable || 0,
      roundOffAmount: purchaseData.roundOffAmount || 0,
      roundedTotal: purchaseData.roundedTotal || 0,
      invoiceNo: purchaseData.invoiceNo || '',
      invoicedDate: this.formatDateForInput(purchaseData.invoicedDate),
      receivedDate: this.formatDateForInput(purchaseData.receivedDate),
      addedBy: purchaseData.addedBy || {
        id: this.currentUser?.uid || '',
        name: this.currentUser?.displayName || this.currentUser?.email || '',
        email: this.currentUser?.email || ''
      },
      assignedTo: purchaseData.assignedTo || this.currentUser?.uid || ''
    });
    
    // Clear existing products
    while (this.productsFormArray.length !== 0) {
      this.productsFormArray.removeAt(0);
    }
    
    // Add products from purchase
    if (purchaseData.products && purchaseData.products.length > 0) {
      purchaseData.products.forEach((product: any) => {
        this.addProductFromPurchase(product);
      });
    }
    
    // Set supplier details if available
    if (supplierId) {
      this.onSupplierChange(supplierId);
    }
    
    this.calculateTotals();
  }

  formatDateForInput(date: any): string {
    if (!date) return '';
    
    try {
      let dateObj: Date;
      if (typeof date === 'object' && 'toDate' in date) {
        dateObj = date.toDate();
      } else if (date instanceof Date) {
        dateObj = date;
      } else {
        dateObj = new Date(date);
      }
      
      return dateObj.toISOString().substring(0, 10);
    } catch (e) {
      console.error('Error formatting date:', e);
      return '';
    }
  }

  addProductFromPurchase(product: any): void {
    const productGroup = this.fb.group({
      productId: [product.productId || product.id || ''],
      productName: [product.productName || '', Validators.required],
      quantity: [product.quantity || 1, [Validators.required, Validators.min(1)]],
      unitCost: [product.unitCost || 0, [Validators.required, Validators.min(0)]],
      discountPercent: [product.discountPercent || 0, [Validators.min(0), Validators.max(100)]],
      unitCostBeforeTax: [{value: product.unitCostBeforeTax || product.unitCost || 0, disabled: true}],
      subtotal: [{value: product.subtotal || 0, disabled: true}],
      taxAmount: [{value: product.taxAmount || 0, disabled: true}],
      lineTotal: [{value: product.lineTotal || (product.quantity * product.unitCost) || 0, disabled: true}],
      profitMargin: [product.profitMargin || 0, [Validators.min(0)]],
      sellingPrice: [{value: product.sellingPrice || 0, disabled: true}],
      batchNumber: [product.batchNumber || product.lotNumber || ''],
      expiryDate: [product.expiryDate || ''],
      taxRate: [product.taxRate || 0]
    });

    this.productsFormArray.push(productGroup);
  }

  loadProducts(): void {
    this.productsService.getProductsRealTime().subscribe((products: any[]) => {
      this.productsList = products;
    });
  }

  initForm(): void {
    this.purchaseForm = this.fb.group({
      supplierId: ['', Validators.required],
      supplierName: ['', Validators.required],
      address: [''],
      referenceNo: ['', Validators.required],
      purchaseDate: [new Date().toISOString().substring(0, 10), Validators.required],
      purchaseStatus: ['', Validators.required],
      businessLocation: ['', Validators.required],
      payTerm: ['', Validators.required],
      document: [null],
      discountType: [''],
      discountAmount: [0],
      purchaseTax: [0],
      additionalNotes: [''],
      shippingCharges: [0, [Validators.min(0)]],
      products: this.fb.array([]),
      purchaseTotal: [0],
      paymentAmount: [0, [Validators.required, Validators.min(0)]],
      paidOn: [new Date().toISOString().substring(0, 10), Validators.required],
      paymentMethod: ['', Validators.required],
      paymentAccount: [''],
      paymentNote: [''],
      balance: [0],
      totalPayable: [0],
      roundOffAmount: [0],
      roundedTotal: [0],
      addedBy: this.fb.group({
        id: [''],
        name: [''],
        email: ['']
      }),
      assignedTo: [''],
      // New fields
      invoiceNo: [''],
      invoicedDate: [''],
      receivedDate: [''],
      batchNumber: [''],
      expiryDate: ['']
    });

    this.addProduct();

    // Listen to form changes
    this.purchaseForm.get('shippingCharges')?.valueChanges.subscribe(() => {
      this.calculateTotals();
    });

    this.purchaseForm.get('paymentAmount')?.valueChanges.subscribe(() => {
      this.calculatePaymentBalance();
    });
  }

  navigateToAddSupplier(): void {
    this.router.navigate(['/suppliers']);
  }

  calculatePaymentBalance(): void {
    const totalPayable = this.purchaseForm.get('totalPayable')?.value || 0;
    const paymentAmount = this.purchaseForm.get('paymentAmount')?.value || 0;
    const balance = Math.max(0, totalPayable - paymentAmount);
    
    this.purchaseForm.patchValue({
      balance: balance
    });
  }

  get productsFormArray(): FormArray {
    return this.purchaseForm.get('products') as FormArray;
  }

  addProduct(): void {
    const productGroup = this.fb.group({
      productId: [''],
      productName: ['', Validators.required],
      quantity: [1, [Validators.required, Validators.min(1)]],
      unitCost: [0, [Validators.required, Validators.min(0)]],
      discountPercent: [0, [Validators.min(0), Validators.max(100)]],
      unitCostBeforeTax: [{value: 0, disabled: true}],
      subtotal: [{value: 0, disabled: true}],
      taxAmount: [{value: 0, disabled: true}],
      lineTotal: [{value: 0, disabled: true}],
      profitMargin: [0, [Validators.min(0)]],
      sellingPrice: [{value: 0, disabled: true}],
      batchNumber: [''],
      expiryDate: [''],
      taxRate: [0]
    });

    this.productsFormArray.push(productGroup);
    this.calculateTotals();
  }

  onProductSelect(index: number, event: Event): void {
    const selectElement = event.target as HTMLSelectElement;
    const productId = selectElement.value;
    
    const selectedProduct = this.productsList.find(p => p.id === productId);
    const productGroup = this.productsFormArray.at(index);
    
    if (selectedProduct) {
      productGroup.patchValue({
        productId: selectedProduct.id,
        productName: selectedProduct.productName,
        unitCost: selectedProduct.defaultPurchasePriceExcTax || 0,
        profitMargin: 0,
        sellingPrice: selectedProduct.defaultSellingPriceExcTax || 0,
        taxRate: selectedProduct.taxRate || 0
      });
      
      this.calculateLineTotal(index);
    }
  }

  removeProduct(index: number): void {
    this.productsFormArray.removeAt(index);
    this.calculateTotals();
  }

  calculateLineTotal(index: number): void {
    const productGroup = this.productsFormArray.at(index);
    const quantity = productGroup.get('quantity')?.value || 0;
    const unitCost = productGroup.get('unitCost')?.value || 0;
    const discountPercent = productGroup.get('discountPercent')?.value || 0;
    const taxRate = productGroup.get('taxRate')?.value || 0;

    const discountedPrice = unitCost * (1 - (discountPercent / 100));
    const subtotal = quantity * discountedPrice;
    const taxAmount = subtotal * (taxRate / 100);
    const lineTotal = subtotal + taxAmount;

    productGroup.patchValue({
      unitCostBeforeTax: discountedPrice.toFixed(2),
      subtotal: subtotal.toFixed(2),
      taxAmount: taxAmount.toFixed(2),
      lineTotal: lineTotal.toFixed(2)
    });

    this.calculateSellingPrice(index);
    this.calculateTotals();
  }

  calculateSellingPrice(index: number): void {
    const productGroup = this.productsFormArray.at(index);
    const unitCostBeforeTax = parseFloat(productGroup.get('unitCostBeforeTax')?.value) || 0;
    const profitMargin = productGroup.get('profitMargin')?.value || 0;
    const taxRate = productGroup.get('taxRate')?.value || 0;

    const priceBeforeTax = unitCostBeforeTax * (1 + (profitMargin / 100));
    const sellingPrice = priceBeforeTax * (1 + (taxRate / 100));
    
    productGroup.patchValue({
      sellingPrice: sellingPrice.toFixed(2)
    });
  }

  calculateTotals(): void {
    this.totalItems = this.productsFormArray.length;
    
    let productsTotal = 0;
    let totalTax = 0;

    this.productsFormArray.controls.forEach(productGroup => {
      productsTotal += (parseFloat(productGroup.get('lineTotal')?.value) || 0);
      totalTax += (parseFloat(productGroup.get('taxAmount')?.value) || 0);
    });

    const shippingCharges = parseFloat(this.purchaseForm.get('shippingCharges')?.value) || 0;
    this.netTotalAmount = productsTotal + shippingCharges;
    this.totalTax = totalTax;

    // Calculate rounded total and round off amount
    const roundedTotal = Math.round(this.netTotalAmount);
    const roundOffAmount = roundedTotal - this.netTotalAmount;

    this.purchaseForm.patchValue({
      purchaseTotal: this.netTotalAmount,
      totalPayable: roundedTotal,
      paymentAmount: roundedTotal,
      roundOffAmount: roundOffAmount.toFixed(2),
      roundedTotal: roundedTotal.toFixed(2)
    });

    this.calculatePaymentBalance();
  }

  loadBusinessLocations(): void {
    this.locationService.getLocations().subscribe(
      (locations) => {
        this.businessLocations = locations;
      },
      (error) => {
        console.error('Error loading business locations:', error);
      }
    );
  }

  loadSuppliers(): void {
    this.supplierService.getSuppliers().subscribe((suppliers) => {
      this.suppliers = (suppliers as unknown as Supplier[]).map(supplier => ({
        ...supplier,
      }));
    });
  }

  getSupplierDisplayName(supplier: Supplier): string {
    if (supplier.isIndividual) {
      return `${supplier.firstName || ''} ${supplier.lastName || ''}`.trim();
    }
    return supplier.businessName || '';
  }

  onSupplierChange(supplierId: string): void {
    const selectedSupplier = this.suppliers.find(s => s.id === supplierId);
    if (selectedSupplier) {
      this.selectedSupplier = selectedSupplier;
      this.purchaseForm.patchValue({
        supplierName: this.getSupplierDisplayName(selectedSupplier),
        address: selectedSupplier.addressLine1 || ''
      });
    }
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.purchaseForm.patchValue({ document: file.name });
    }
  }

  updatePurchase() {
    if (this.purchaseForm.valid && this.productsFormArray.length > 0 && this.purchaseId) {
      const formData = this.purchaseForm.value;
      
      const purchaseData = {
        ...formData,
        products: formData.products,
        supplier: {
          id: formData.supplierId,
          name: formData.supplierName
        },
        totalItems: this.totalItems,
        netTotalAmount: this.netTotalAmount,
        totalTax: this.totalTax,
        balance: formData.balance,
        totalPayable: formData.roundedTotal,
        shippingCharges: formData.shippingCharges,
        updatedAt: new Date(),
        id: this.purchaseId,
        // New fields
        invoiceNo: formData.invoiceNo,
        invoicedDate: formData.invoicedDate,
        receivedDate: formData.receivedDate,
        assignedTo: formData.assignedTo
      };

      this.purchaseService.updatePurchase(this.purchaseId, purchaseData)
        .then(() => {
          alert('Purchase Updated Successfully!');
          this.router.navigate(['/list-purchase']);
        })
        .catch(error => {
          console.error('Error updating purchase:', error);
          alert('Error updating purchase. Please try again.');
        });
    } else {
      alert('Please fill all required fields and add at least one product!');
    }
  }
}