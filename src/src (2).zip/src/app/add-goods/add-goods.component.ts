import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Supplier, SupplierService } from '../services/supplier.service';
import { LocationService } from '../services/location.service';
import { PurchaseService } from '../services/purchase.service';
import { GoodsService } from '../services/goods.service';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth.service';



@Component({
  selector: 'app-add-goods',
  templateUrl: './add-goods.component.html',
  styleUrls: ['./add-goods.component.scss'],

})
export class AddGoodsComponent implements OnInit, OnDestroy {
  goodsReceivedForm!: FormGroup;
  products: any[] = [];
  totalItems: number = 0;
  netTotalAmount: number = 0;
  purchaseTotal: number = 0;
  
  suppliers: Supplier[] = [];
  locations: any[] = [];
  selectedSupplier: Supplier | null = null;
  filteredPurchaseOrders: any[] = []; // Add this line

  purchaseOrders: any[] = [];
  selectedPurchaseOrder: any = null;
  private subscriptions: Subscription[] = [];

  constructor(
    private fb: FormBuilder,
    private supplierService: SupplierService,
    private locationService: LocationService,
    private purchaseService: PurchaseService,
    private goodsService: GoodsService,
    private authService: AuthService // Add this line

  ) { }

  ngOnInit(): void {
    this.initForm();
    this.loadSuppliers();
    this.loadLocations();
    this.loadPurchaseOrders();
    this.setAddedByField();

  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
  setAddedByField(): void {
    const currentUser = this.authService.currentUserValue;
    if (currentUser) {
      const userName = currentUser.displayName || currentUser.email || 'System';
      this.goodsReceivedForm.get('addedBy')?.setValue(userName);
    }
  }
  initForm(): void {
    this.goodsReceivedForm = this.fb.group({
      supplier: ['', Validators.required],
      businessLocation: ['', Validators.required],
      purchaseDate: ['', Validators.required],
      purchaseOrder: [''],
      additionalNotes: [''],
      invoiceNo: [''], // Add this line
      addedBy: [''], // Add this line
    });

    this.subscriptions.push(
      this.goodsReceivedForm.get('supplier')?.valueChanges.subscribe(supplierId => {
        this.onSupplierChange(supplierId);
      }) as Subscription
    );

    this.subscriptions.push(
      this.goodsReceivedForm.get('purchaseOrder')?.valueChanges.subscribe(orderId => {
        this.onPurchaseOrderChange(orderId);
      }) as Subscription
    );
  }

  loadPurchaseOrders(): void {
    this.subscriptions.push(
      this.purchaseService.getPurchases().subscribe(orders => {
        this.purchaseOrders = orders.filter(order => order.purchaseOrder);
      })
    );
  }
  onPurchaseOrderChange(event: any): void {
    const orderId = event.target.value;
    if (!orderId) {
      this.selectedPurchaseOrder = null;
      this.goodsReceivedForm.get('invoiceNo')?.setValue('');
      this.products = [];
      this.calculateTotals();
      return;
    }

    const order = this.purchaseOrders.find(o => o.id === orderId);
    if (order) {
      this.selectedPurchaseOrder = order;
      // Set invoice number from purchase order
      this.goodsReceivedForm.get('invoiceNo')?.setValue(order.invoiceNo || '');
      this.populateProductsFromOrder(order);
    }
  }

  populateProductsFromOrder(order: any): void {
    if (order.products && order.products.length) {
      this.products = order.products.map((product: any) => ({
        id: product.id || product.productId,
        name: product.name || product.productName,
        orderQuantity: product.quantity || 0,
        receivedQuantity: product.quantity || 0, // Default to ordered quantity
        unitPrice: product.price || product.unitCost || 0,
        lineTotal: (product.quantity || 0) * (product.price || product.unitCost || 0)
      }));
    } else {
      this.products = [];
    }
    this.calculateTotals();
  }

  onSupplierChange(event: any): void {
    const supplierId = event.target.value;
    if (!supplierId) {
      this.selectedSupplier = null;
      this.filteredPurchaseOrders = [];
      return;
    }

    const supplier = this.suppliers.find(s => s.id === supplierId);
    if (supplier) {
      this.selectedSupplier = supplier;
      // Filter purchase orders for this supplier
      this.filteredPurchaseOrders = this.purchaseOrders.filter(order => 
        order.supplierId === supplierId
      );
    }
  }

  loadSuppliers(): void {
    this.supplierService.getSuppliers().subscribe(suppliers => {
      this.suppliers = suppliers;
    });
  }

  loadLocations(): void {
    this.locationService.getLocations().subscribe(locations => {
      this.locations = locations;
    });
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      console.log('File selected:', file.name);
      if (file.size > 5 * 1024 * 1024) {
        console.error('File size exceeds the 5MB limit');
      }
    }
  }

  addProduct(): void {
    this.products.push({
      id: this.products.length + 1,
      name: '',
      orderQuantity: 0,
      receivedQuantity: 0,
      unitPrice: 0,
      lineTotal: 0
    });
    this.calculateTotals();
  }

  removeProduct(index: number): void {
    this.products.splice(index, 1);
    this.calculateTotals();
  }

  onQuantityChange(index: number): void {
    const product = this.products[index];
    if (product) {
      product.lineTotal = (product.receivedQuantity || 0) * (product.unitPrice || 0);
      this.calculateTotals();
    }
  }

  calculateTotals(): void {
    this.totalItems = this.products.length;
    this.netTotalAmount = this.products.reduce((sum, product) => sum + (product.lineTotal || 0), 0);
    this.purchaseTotal = this.netTotalAmount;
  }

  saveForm(): void {
    if (this.goodsReceivedForm.valid) {
      const formData = {
        ...this.goodsReceivedForm.value,
        products: this.products,
        totalItems: this.totalItems,
        netTotalAmount: this.netTotalAmount,
        purchaseTotal: this.purchaseTotal,
        supplierDetails: this.selectedSupplier,
        purchaseOrderDetails: this.selectedPurchaseOrder,
        createdAt: new Date(),
        status: 'received',
        receivedDate: new Date()
      };
      
      this.goodsService.addGoodsReceived(formData)
        .then(() => {
          console.log('Goods received note saved successfully');
          this.resetForm();
        })
        .catch(error => {
          console.error('Error saving goods received note:', error);
        });
    } else {
      Object.keys(this.goodsReceivedForm.controls).forEach(key => {
        const control = this.goodsReceivedForm.get(key);
        control?.markAsTouched();
      });
      console.error('Form validation failed');
    }
  }


 
  resetForm(): void {
    this.goodsReceivedForm.reset();
    this.products = [];
    this.totalItems = 0;
    this.netTotalAmount = 0;
    this.purchaseTotal = 0;
    this.selectedSupplier = null;
    this.selectedPurchaseOrder = null;
  }
}