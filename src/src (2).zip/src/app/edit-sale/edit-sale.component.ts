import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SaleService } from '../services/sale.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CustomerService } from '../services/customer.service';
import { ProductsService } from '../services/products.service';

interface Product {
  name: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  subtotal: number;
}

@Component({
  selector: 'app-edit-sale',
  templateUrl: './edit-sale.component.html',
  styleUrls: ['./edit-sale.component.scss'],
  providers: [DatePipe]
})
export class EditSaleComponent implements OnInit {
  saleForm!: FormGroup;
  todayDate: string;
  products: Product[] = [];
  allProducts: any[] = [];
  filteredProducts: any[] = [];
  customers: any[] = [];
  productSearchTerm: string = '';
  saleId: string = '';
  isEditing: boolean = false;
  isLoading: boolean = false;

  defaultProduct: Product = {
    name: '',
    quantity: 0,
    unitPrice: 0,
    discount: 0,
    subtotal: 0
  };
  
  itemsTotal: number = 0;

  constructor(
    private fb: FormBuilder,
    private saleService: SaleService,
    private router: Router,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private customerService: CustomerService,
    private productService: ProductsService
  ) {
    this.todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd') || '';
  }

  ngOnInit(): void {
    this.initializeForm();
    this.setupValueChanges();
    this.loadCustomers();
    this.loadProducts();
    
    this.route.params.subscribe(params => {
      this.saleId = params['id'];
      if (this.saleId) {
        this.isEditing = true;
        this.loadSaleData(this.saleId);
      }
    });
  }

  loadSaleData(saleId: string): void {
    this.isLoading = true;
    this.saleService.getSaleById(saleId).subscribe({
      next: (sale) => {
        // Prefill the form with sale data
        this.saleForm.patchValue({
          customer: sale.customerId,
          billingAddress: sale.billingAddress,
          shippingAddress: sale.shippingAddress,
          saleDate: sale.saleDate,
          status: sale.status,
          invoiceScheme: sale.invoiceScheme,
          invoiceNo: sale.invoiceNo,
          document: sale.document,
          discountType: sale.discountType || 'Percentage',
          discountAmount: sale.discountAmount || 0,
          orderTax: sale.orderTax || 0,
          sellNote: sale.sellNote,
          shippingCharges: sale.shippingCharges || 0,
          shippingStatus: sale.shippingStatus,
          deliveryPerson: sale.deliveryPerson,
          shippingDocuments: sale.shippingDocuments,
          totalPayable: sale.totalPayable || 0,
          paymentAmount: sale.paymentAmount || 0,
          paidOn: sale.paidOn || this.todayDate,
          paymentMethod: sale.paymentMethod,
          paymentNote: sale.paymentNote,
          changeReturn: sale.changeReturn || 0,
          balance: sale.balance || 0
        });

        // Set products
        if (sale.products && sale.products.length > 0) {
          this.products = sale.products.map((p: any) => ({
            name: p.name,
            quantity: p.quantity,
            unitPrice: p.unitPrice,
            discount: p.discount || 0,
            subtotal: p.subtotal || (p.quantity * p.unitPrice) - (p.discount || 0)
          }));
          this.calculateItemsTotal();
          this.calculateTotalPayable();
        }

        // Set items total if available
        if (sale.itemsTotal) {
          this.itemsTotal = sale.itemsTotal;
        }
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading sale data:', error);
        alert('Error loading sale data. Please try again.');
        this.isLoading = false;
      }
    });
  }

  loadCustomers(): void {
    this.isLoading = true;
    this.customerService.getCustomers().subscribe({
      next: (customers: any[]) => {
        this.customers = customers.map(customer => ({
          ...customer,
          displayName: customer.businessName || 
                     `${customer.firstName} ${customer.middleName ? customer.middleName + ' ' : ''}${customer.lastName}`
        }));
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading customers:', error);
        this.isLoading = false;
      }
    });
  }
  
  loadProducts(): void {
    this.isLoading = true;
    this.productService.getProductsRealTime().subscribe({
      next: (products: any[]) => {
        this.allProducts = products;
        this.filteredProducts = [...products];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading products:', error);
        this.isLoading = false;
      }
    });
  }

  filterProducts(): void {
    if (!this.productSearchTerm) {
      this.filteredProducts = [...this.allProducts];
      return;
    }
    
    const searchTerm = this.productSearchTerm.toLowerCase();
    this.filteredProducts = this.allProducts.filter(product => 
      product.productName.toLowerCase().includes(searchTerm)
    );
  }
  
  initializeForm(): void {
    this.saleForm = this.fb.group({
      customer: ['', Validators.required],
      billingAddress: [''],
      shippingAddress: [''],
      saleDate: [this.todayDate, Validators.required],
      status: ['', Validators.required],
      invoiceScheme: [''],
      invoiceNo: [{value: '', disabled: true}],
      document: [null],
      discountType: ['Percentage'],
      discountAmount: [0, [Validators.min(0)]],
      orderTax: [0, [Validators.min(0), Validators.max(100)]],
      sellNote: [''],
      shippingCharges: [0, [Validators.min(0)]],
      shippingStatus: [''],
      deliveryPerson: [''],
      shippingDocuments: [null],
      totalPayable: [0],
      paymentAmount: [0, [Validators.required, Validators.min(0)]],
      paidOn: [this.todayDate],
      paymentMethod: ['', Validators.required],
      paymentNote: [''],
      changeReturn: [0],
      balance: [0]
    });
  }

  onProductSelect(productName: string): void {
    if (!productName) {
      this.defaultProduct.unitPrice = 0;
      this.defaultProduct.quantity = 0;
      this.updateDefaultProduct();
      return;
    }

    const selectedProduct = this.allProducts.find(p => p.productName === productName);
    if (selectedProduct) {
      this.defaultProduct.name = selectedProduct.productName;
      this.defaultProduct.unitPrice = selectedProduct.defaultSellingPriceExcTax || 0;
      this.defaultProduct.quantity = 1;
      this.updateDefaultProduct();
    }
  }

  onDynamicProductSelect(productName: string, index: number): void {
    if (!productName) {
      this.products[index].unitPrice = 0;
      this.products[index].quantity = 0;
      this.updateProduct(index);
      return;
    }

    const selectedProduct = this.allProducts.find(p => p.productName === productName);
    if (selectedProduct) {
      this.products[index].name = selectedProduct.productName;
      this.products[index].unitPrice = selectedProduct.defaultSellingPriceExcTax || 0;
      this.products[index].quantity = 1;
      this.updateProduct(index);
    }
  }

  setupValueChanges(): void {
    this.saleForm.get('paymentAmount')?.valueChanges.subscribe(() => {
      this.calculateBalance();
    });

    this.saleForm.get('discountAmount')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });

    this.saleForm.get('orderTax')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });

    this.saleForm.get('shippingCharges')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });

    this.saleForm.get('discountType')?.valueChanges.subscribe(() => {
      this.calculateTotalPayable();
    });
  }

  updateDefaultProduct(): void {
    this.defaultProduct.subtotal = (this.defaultProduct.quantity * this.defaultProduct.unitPrice) - this.defaultProduct.discount;
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  addProduct(): void {
    // Add the default product if it has data
    if (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) {
      this.products.push({...this.defaultProduct});
      // Reset default product
      this.defaultProduct = {
        name: '',
        quantity: 0,
        unitPrice: 0,
        discount: 0,
        subtotal: 0
      };
    } else {
      // Add empty product
      this.products.push({
        name: '',
        quantity: 1,
        unitPrice: 0,
        discount: 0,
        subtotal: 0
      });
    }
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  updateProduct(index: number): void {
    const product = this.products[index];
    product.subtotal = (product.quantity * product.unitPrice) - product.discount;
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  removeProduct(index: number): void {
    this.products.splice(index, 1);
    this.calculateItemsTotal();
    this.calculateTotalPayable();
  }

  calculateItemsTotal(): void {
    // Include default product in total if it has values
    const defaultProductValue = (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) 
      ? this.defaultProduct.subtotal 
      : 0;
    
    this.itemsTotal = this.products.reduce((sum, product) => sum + product.subtotal, defaultProductValue);
  }

  calculateTotalPayable(): void {
    const discount = this.saleForm.get('discountAmount')?.value || 0;
    const tax = this.saleForm.get('orderTax')?.value || 0;
    const shipping = this.saleForm.get('shippingCharges')?.value || 0;

    let total = this.itemsTotal;
    
    if (this.saleForm.get('discountType')?.value === 'Percentage') {
      total -= (total * discount / 100);
    } else {
      total -= discount;
    }

    total += (total * tax / 100);
    total += shipping;

    this.saleForm.patchValue({ totalPayable: total.toFixed(2) });
    this.calculateBalance();
  }

  calculateBalance(): void {
    const totalPayable = this.saleForm.get('totalPayable')?.value || 0;
    const paymentAmount = this.saleForm.get('paymentAmount')?.value || 0;

    if (paymentAmount > totalPayable) {
      this.saleForm.patchValue({
        changeReturn: (paymentAmount - totalPayable).toFixed(2),
        balance: 0
      });
    } else {
      this.saleForm.patchValue({
        changeReturn: 0,
        balance: (totalPayable - paymentAmount).toFixed(2)
      });
    }
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.saleForm.patchValue({ document: file.name });
    }
  }

  onShippingDocumentSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.saleForm.patchValue({ shippingDocuments: file.name });
    }
  }

  updateSale(): void {
    if (this.saleForm.invalid) {
      this.markFormGroupTouched(this.saleForm);
      const errors = this.getFormErrors();
      console.error('Form validation errors:', errors);
      alert('Please fill all required fields correctly.');
      return;
    }

    if (this.products.length === 0 && 
        !(this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0)) {
      alert('Please add at least one product');
      return;
    }

    // Validate products
    const invalidProducts = this.products.filter(p => 
      !p.name || p.quantity <= 0 || p.unitPrice <= 0
    );

    if (invalidProducts.length > 0 || 
        (this.defaultProduct.name && (this.defaultProduct.quantity <= 0 || this.defaultProduct.unitPrice <= 0))) {
      alert('Some products are invalid. Please check product name, quantity, and price.');
      return;
    }

    this.isLoading = true;

    // Get selected customer details
    const selectedCustomerId = this.saleForm.get('customer')?.value;
    const selectedCustomer = this.customers.find(c => c.id === selectedCustomerId);
    const customerName = selectedCustomer?.displayName || 'Unknown Customer';

    // Include default product if it has values
    const productsToSave = [...this.products];
    if (this.defaultProduct.name || this.defaultProduct.quantity > 0 || this.defaultProduct.unitPrice > 0) {
      productsToSave.push({...this.defaultProduct});
    }

    const saleData = { 
      ...this.saleForm.value,
      invoiceNo: this.saleForm.get('invoiceNo')?.value,
      customerId: selectedCustomerId,
      customer: customerName,
      products: productsToSave,
      itemsTotal: this.itemsTotal,
      updatedAt: new Date()
    };

    console.log('Submitting sale data:', saleData);

    this.saleService.updateSale(this.saleId, saleData)
      .then(() => {
        this.isLoading = false;
        alert('Sale updated successfully!');
        this.router.navigate(['/sales-order']);
      })
      .catch(error => {
        this.isLoading = false;
        console.error('Error updating sale:', error);
        
        let errorMessage = 'Error updating sale. Please try again.';
        if (error.error) {
          if (typeof error.error === 'string') {
            errorMessage = error.error;
          } else if (error.error.message) {
            errorMessage = error.error.message;
          } else {
            errorMessage = JSON.stringify(error.error);
          }
        } else if (error.message) {
          errorMessage = error.message;
        }

        alert(errorMessage);
      });
  }

  resetForm(): void {
    if (confirm('Are you sure you want to reset the form?')) {
      this.isLoading = true;
      this.loadSaleData(this.saleId);
    }
  }

  cancelEdit(): void {
    if (confirm('Are you sure you want to cancel? All unsaved changes will be lost.')) {
      this.router.navigate(['/sales-order']);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  private getFormErrors(): any {
    const errors: any = {};
    Object.keys(this.saleForm.controls).forEach(key => {
      const control = this.saleForm.get(key);
      if (control?.errors) {
        errors[key] = control.errors;
      }
    });
    return errors;
  }
}