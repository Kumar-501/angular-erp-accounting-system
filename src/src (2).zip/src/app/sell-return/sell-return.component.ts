import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SaleService } from '../services/sale.service';

@Component({
  selector: 'app-sell-return',
  templateUrl: './sell-return.component.html',
  styleUrls: ['./sell-return.component.scss']
})
export class SellReturnComponent {
  saleData: any;
  returnedItems: any[] = [];
  returnReason: string = '';
  
  constructor(private router: Router, private saleService: SaleService) {
    const navigation = this.router.getCurrentNavigation();
    this.saleData = navigation?.extras?.state?.['saleData'];
    
    if (!this.saleData) {
    } else {
      this.initializeReturnedItems();
    }
  }

  initializeReturnedItems(): void {
    this.returnedItems = this.saleData.products.map((product: any) => ({
      ...product,
      returnQuantity: 0,
      isReturning: false
    }));
  }

  navigateToSales(): void {
    this.router.navigate(['/sales']);
  }

  toggleItemReturn(index: number): void {
    this.returnedItems[index].isReturning = !this.returnedItems[index].isReturning;
    if (!this.returnedItems[index].isReturning) {
      this.returnedItems[index].returnQuantity = 0;
    }
  }

  validateReturnQuantity(index: number): void {
    const item = this.returnedItems[index];
    
    // Ensure value is a number
    item.returnQuantity = Number(item.returnQuantity) || 0;
    
    // Validate range
    if (item.returnQuantity > item.quantity) {
      item.returnQuantity = item.quantity;
    } else if (item.returnQuantity < 0) {
      item.returnQuantity = 0;
    }
    
    // If quantity is 0, uncheck the returning flag
    if (item.returnQuantity <= 0) {
      item.isReturning = false;
    }
  }

  // New methods for increasing and decreasing return quantity
  increaseReturnQuantity(index: number): void {
    const item = this.returnedItems[index];
    // If not returning yet, enable returning on first increase
    if (!item.isReturning) {
      item.isReturning = true;
    }
    
    // Increase quantity if below max
    if (item.returnQuantity < item.quantity) {
      item.returnQuantity = Number(item.returnQuantity) + 1;
    }
  }

  decreaseReturnQuantity(index: number): void {
    const item = this.returnedItems[index];
    // Decrease quantity if above 0
    if (item.returnQuantity > 0) {
      item.returnQuantity = Number(item.returnQuantity) - 1;
      
      // If quantity reaches 0, uncheck the returning flag
      if (item.returnQuantity === 0) {
        item.isReturning = false;
      }
    }
  }

  get totalRefundAmount(): number {
    return this.returnedItems.reduce((total, item) => {
      return total + (item.isReturning ? item.unitPrice * item.returnQuantity : 0);
    }, 0);
  }

 // Update the processReturn method in sell-return.component.ts
async processReturn(): Promise<void> {
  if (this.returnedItems.every(item => !item.isReturning || item.returnQuantity <= 0)) {
    alert('Please select at least one item to return with a valid quantity');
    return;
  }

  if (!this.returnReason) {
    alert('Please provide a reason for the return');
    return;
  }

  if (confirm(`Process return with total refund amount of $${this.totalRefundAmount.toFixed(2)}?`)) {
    try {
      // Create return data
      const returnData = {
        originalSaleId: this.saleData.id,
        invoiceNo: this.saleData.invoiceNo,
        customer: this.saleData.customer,
        returnedItems: this.returnedItems
          .filter(item => item.isReturning && item.returnQuantity > 0)
          .map(item => ({
            productId: item.id,
            name: item.name,
            quantity: item.returnQuantity,
            originalQuantity: item.quantity,
            unitPrice: item.unitPrice,
            reason: this.returnReason,
            subtotal: item.unitPrice * item.returnQuantity
          })),
        totalRefund: this.totalRefundAmount,
        returnDate: new Date(),
        status: 'Processed',
        returnReason: this.returnReason
      };

      // Process the return
      await this.saleService.processReturn(returnData);

      // Update the original sale to reduce quantities
      const updatedProducts = this.saleData.products.map((product: any) => {
        const returnedItem = this.returnedItems.find(item => item.id === product.id && item.isReturning);
        if (returnedItem) {
          return {
            ...product,
            quantity: product.quantity - returnedItem.returnQuantity
          };
        }
        return product;
      });

      // Calculate new totals for the sale
      const newSubtotal = updatedProducts.reduce((sum: number, product: any) => 
        sum + (product.unitPrice * product.quantity), 0);
      
      // Update the original sale document
      await this.saleService.updateSale(this.saleData.id, {
        products: updatedProducts,
        subtotal: newSubtotal,
        total: newSubtotal + (this.saleData.tax || 0) + (this.saleData.shippingCost || 0),
        updatedAt: new Date()
      });

      alert('Return processed successfully!');
      this.router.navigate(['/sales']);
    } catch (error) {
      console.error('Error processing return:', error);
      alert('Error processing return. Please try again.');
    }
  }
}
}