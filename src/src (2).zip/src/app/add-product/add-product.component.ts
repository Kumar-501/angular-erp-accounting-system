import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ProductsService } from '../services/products.service';
import { CategoriesService } from '../services/categories.service';
import { BrandsService } from '../services/brands.service';
import { UnitsService } from '../services/units.service';
import { TaxService } from '../services/tax.service';
import { VariationsService } from '../services/variations.service';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { LocationService } from '../services/location.service';
import { UserService } from '../services/user.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit, OnDestroy {
  @ViewChild('productForm') productForm!: NgForm;
  
  product: any = this.getInitialProduct();
  users: any[] = [];
  selectedUser: any = null;

  availableProducts: any[] = [];
  availableVariations: any[] = [];
  selectedVariations: any[] = [];
  variantCombinations: any[] = [];
  locations: any[] = [];
  allCategories: any[] = []; // To store all categories including subcategories
  categories: any[] = [];
  productFormSubmitted: boolean = false;

  brands: any[] = [];
  units: any[] = [];
  subCategories: any[] = [];
  filteredSubCategories: any[] = [];
  products: any[] = [];
  taxRates: any[] = [];
  private roundToWholeNumber(value: number): number {
    return Math.round(value);
  }

  
  roundToTwoDecimals(value: number): number {
    return Math.round(value * 100) / 100;
  }
  categoryTaxMapping: { [key: string]: string } = {
    'medicines': '10',
    'drugs': '12',
    'food': '5',
    'electronics': '18'
  };

  isGeneratingSku = false;
  isLoading = false;
  isEditing = false;

  private subscriptions: Subscription[] = [];

  constructor(
    private productsService: ProductsService,
    private categoriesService: CategoriesService,
    private brandsService: BrandsService,
    private unitsService: UnitsService,
    private taxService: TaxService,
    private userService: UserService,
    private variationsService: VariationsService,
    private locationService: LocationService,
    private router: Router,
    private route: ActivatedRoute,
    
    
  ) {}

  ngOnInit() {
    this.subscriptions.push(
      this.route.queryParams.subscribe(params => {
        if (params['duplicate']) {
          try {
            const duplicatedProduct = JSON.parse(params['duplicate']);
            this.product = {
              ...this.getInitialProduct(),
              ...duplicatedProduct,
            };
            this.isEditing = false;
          } catch (e) {
            console.error('Error parsing duplicated product data:', e);
          }
        }
      })
    );
    
    this.loadInitialData();
    this.loadTaxRates();
    this.loadAvailableProducts();
    this.loadVariations();
    this.product.components = (this.product.components || []).filter((c: any) => c.productId);

    // Handle duplicated product from router state
    const navigation = this.router.getCurrentNavigation();
    const duplicatedProduct = navigation?.extras?.state?.['duplicateProduct'];
    
    if (duplicatedProduct) {
      this.product = {
        ...this.getInitialProduct(),
        ...duplicatedProduct
      };
      
      // If it's a combination product, ensure components are properly set
      if (this.product.productType === 'Combination' && this.product.components) {
        this.product.components = [...this.product.components];
      }
      
      // If it's a variant product, ensure variations are properly set
      if (this.product.productType === 'Variant' && this.product.variations) {
        this.variantCombinations = [...this.product.variations];
        // Initialize selected variations based on the duplicated product
        this.initializeSelectedVariationsFromCombinations();
      }
      
      this.isEditing = false; // Ensure we're creating a new product
      
      // Filter subcategories based on the duplicated product's category
      if (this.product.category) {
        setTimeout(() => this.filterSubCategories(), 500);
      }
    }
  }
  
  private initializeSelectedVariationsFromCombinations() {
    if (!this.variantCombinations.length) return;
    
    // We'll need to set this up once variations are loaded
    setTimeout(() => {
      const valuesByVariationIndex = new Map();
      
      this.variantCombinations.forEach(combo => {
        combo.values.forEach((value: string, index: number) => {
          if (!valuesByVariationIndex.has(index)) {
            valuesByVariationIndex.set(index, new Set());
          }
          valuesByVariationIndex.get(index).add(value);
        });
      });
      
      // Rebuild selectedVariations based on the combinations
      this.selectedVariations = Array.from(valuesByVariationIndex.keys()).map(index => {
        const variationValues = Array.from(valuesByVariationIndex.get(index));
        const matchingVariation = this.availableVariations.find(v => 
          variationValues.every(val => v.values.includes(val))
        );
        
        if (matchingVariation) {
          return {
            id: matchingVariation.id,
            name: matchingVariation.name,
            values: variationValues
          };
        }
        return null;
      }).filter(Boolean);
    }, 1000);
  }

  ngOnDestroy() {
    // Unsubscribe from all subscriptions
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

private getInitialProduct() {
  return {
    productName: '',
    sku: '',
    location: '',
    hsnCode: '',
    barcodeType: 'Code 128 (C128)',
    unit: '',
    addedBy: '',
    addedByName: '',
    addedDate: new Date().toISOString(), // Ensure this is in ISO format

    brand: '',
    category: '',
    subCategory: '',
    manageStock: true,
    alertQuantity: null,
    productDescription: '',
    productImage: null,
    productBrochure: null,
    enableProductDescription: false,
    notForSelling: false,
    weight: null,
    length: null,
    breadth: null,
    height: null,
    customField1: '',
    customField2: '',
    customField3: '',
    customField4: '',
    applicableTax: 'None',
    taxPercentage: 0,
    sellingPriceTaxType: 'Inclusive',
    productType: 'Single',
    marginPercentage: 25.0,
    defaultPurchasePriceExcTax: null,
    defaultPurchasePriceIncTax: null,
    defaultSellingPriceExcTax: null,
    defaultSellingPriceIncTax: null,
    components: [], 
    variations: []
  };
}

  private loadTaxRates() {
    const subscription = this.taxService.getTaxRates().subscribe({
      next: (rates) => {
        this.taxRates = rates.filter(rate => !rate.forTaxGroupOnly);
        console.log('Loaded tax rates:', this.taxRates);
      },
      error: (err) => {
        console.error('Failed to fetch tax rates:', err);
      }
    });
    this.subscriptions.push(subscription);
  }
  
  private loadAvailableProducts(): void {
    const subscription = this.productsService.getProductsRealTime().subscribe({
      next: (products) => {
        this.availableProducts = products;
        console.log('Loaded available products:', this.availableProducts.length);
      },
      error: (err) => {
        console.error('Failed to fetch products:', err);
      }
    });
    this.subscriptions.push(subscription);
  }

  private async loadInitialData() {
    try {
      this.isLoading = true;
      await Promise.all([
        this.loadCategories(),
        this.loadBrands(),
        this.loadUsers(),
        this.loadLocations(),
        this.loadUnits(),
        this.loadSubCategories(),
      ]);
    } catch (error) {
      console.error('Error loading initial data:', error);
    } finally {
      this.isLoading = false;
    }
  }

  addComponent() {
    if (!this.product.components) {
      this.product.components = [];
    }
    this.product.components.push({
      productId: '',
      quantity: 1
    });
  }
calculateFromMRP() {
  const taxPercentage = this.getTaxPercentage();
  if (this.product.defaultSellingPriceIncTax !== null) {
    // Calculate price before tax from MRP
    this.product.defaultSellingPriceExcTax = 
      this.product.defaultSellingPriceIncTax / (1 + taxPercentage / 100);
    
    // Calculate margin based on purchase price
    if (this.product.defaultPurchasePriceExcTax) {
      const cost = parseFloat(this.product.defaultPurchasePriceExcTax);
      const sellingPrice = parseFloat(this.product.defaultSellingPriceExcTax);
      this.product.marginPercentage = this.roundToTwoDecimals(((sellingPrice - cost) / cost) * 100);
    }
    
    // Round the values
    this.product.defaultSellingPriceExcTax = this.roundToTwoDecimals(this.product.defaultSellingPriceExcTax);
    this.product.defaultSellingPriceIncTax = this.roundToTwoDecimals(this.product.defaultSellingPriceIncTax);
  }
}
  private loadCategories(): Promise<void> {
    return new Promise((resolve) => {
      const subscription = this.categoriesService.categories$.subscribe({
        next: (categories) => {
          this.categories = (categories || []).filter(cat => !cat.parentCategory);
          this.allCategories = categories || []; // Store all categories including subcategories
          console.log('Loaded categories:', this.categories.length);
          resolve();
        },
        error: (error) => {
          console.error('Error loading categories:', error);
          resolve();
        }
      });
      this.subscriptions.push(subscription);
    });
  }

  

  private loadLocations(): Promise<void> {
    return new Promise((resolve) => {
      const subscription = this.locationService.getLocations().subscribe({
        next: (locations) => {
          this.locations = locations.filter((loc: any) => loc.active !== false);
          console.log('Loaded locations:', this.locations.length);
          resolve();
        },
        error: (error) => {
          console.error('Error loading locations:', error);
          resolve();
        }
      });
      this.subscriptions.push(subscription);
    });
  }

  private loadUsers(): Promise<void> {
    return new Promise((resolve) => {
      const subscription = this.userService.getUsers().subscribe({
        next: (users) => {
          this.users = users || [];
          console.log('Loaded users:', this.users.length);
          resolve();
        },
        error: (error) => {
          console.error('Error loading users:', error);
          resolve();
        }
      });
      this.subscriptions.push(subscription);
    });
  }

  onUserSelect(user: any) {
    if (!user) return;
    
    this.selectedUser = user;
    this.product.addedBy = user.id;
    this.product.addedByName = user.name || user.email;
  }

  private loadBrands(): Promise<void> {
    return new Promise((resolve) => {
      const subscription = this.brandsService.brands$.subscribe({
        next: (brands) => {
          this.brands = brands || [];
          console.log('Loaded brands:', this.brands.length);
          resolve();
        },
        error: (error) => {
          console.error('Error loading brands:', error);
          resolve();
        }
      });
      this.subscriptions.push(subscription);
    });
  }

  private loadVariations() {
    const subscription = this.variationsService.getVariations().subscribe({
      next: (variations) => {
        this.availableVariations = variations || [];
        console.log('Loaded variations:', this.availableVariations.length);
      },
      error: (err) => {
        console.error('Failed to fetch variations:', err);
      }
    });
    this.subscriptions.push(subscription);
  }

  private loadUnits(): Promise<void> {
    return new Promise((resolve) => {
      const subscription = this.unitsService.units$.subscribe({
        next: (units) => {
          this.units = units || [];
          console.log('Loaded units:', this.units.length);
          resolve();
        },
        error: (error) => {
          console.error('Error loading units:', error);
          resolve();
        }
      });
      this.subscriptions.push(subscription);
    });
  }

  private loadSubCategories(): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(() => {
        this.subCategories = [
          { name: 'Office Chairs', category: 'Furniture' },
          { name: 'Dining Chairs', category: 'Furniture' },
          { name: 'Smartphones', category: 'Electronics' },
          { name: 'Laptops', category: 'Electronics' },
          { name: 'General', category: 'Medicines' },
          { name: 'Antibiotics', category: 'Drugs' }
        ];
        console.log('Loaded subcategories:', this.subCategories.length);
        resolve();
      }, 500);
    });
  }

 // Update the onCategoryChange method
onCategoryChange() {
  this.filterSubCategories();

  if (this.product.category) {
    const category = this.allCategories.find(cat => cat.id === this.product.category);
    if (category) {
      const categoryName = category.name.toLowerCase();
      if (this.categoryTaxMapping[categoryName]) {
        this.setTaxBasedOnCategory(categoryName);
      }
    }
  }
}

  private setTaxBasedOnCategory(categoryName: string) {
    const taxPercentage = this.categoryTaxMapping[categoryName];
    if (taxPercentage) {
      const matchingTax = this.taxRates.find(tax => tax.percentage == taxPercentage);

      if (matchingTax) {
        this.product.applicableTax = matchingTax;
        this.product.taxPercentage = matchingTax.percentage;
      } else {
        this.product.applicableTax = {
          name: `${categoryName.charAt(0).toUpperCase() + categoryName.slice(1)} GST`,
          percentage: Number(taxPercentage)
        };
        this.product.taxPercentage = Number(taxPercentage);
      }

      this.calculateAllPrices();
    }
  }

  navigateToUnitsPage() {
    this.router.navigate(['/units']);
  }

  navigateToBrandsPage() {
    this.router.navigate(['/brands']);
  }

  private filterSubCategories() {
    if (this.product.category) {
      this.filteredSubCategories = this.subCategories.filter(
        sub => sub.category === this.product.category
      );
    } else {
      this.filteredSubCategories = [];
    }
    this.product.subCategory = '';
  }

private async generateNumericSku(): Promise<string> {
  try {
    this.isGeneratingSku = true;
    const lastSku = await this.productsService.getLastUsedSku();
    let nextNumber = 100001;
    
    if (lastSku) {
      const lastNumber = parseInt(lastSku, 10);
      if (!isNaN(lastNumber)) {
        nextNumber = lastNumber + 1;
      }
    }
    
    return nextNumber.toString();
  } finally {
    this.isGeneratingSku = false;
  }
}

async onProductNameChange() {
  if (this.product.productName && !this.product.sku) {
    this.isGeneratingSku = true;
    try {
      this.product.sku = await this.generateNumericSku();
    } catch (error) {
      console.error('Error generating SKU:', error);
      // Fallback to timestamp-based SKU
      this.product.sku = Date.now().toString().slice(-6);
    } finally {
      this.isGeneratingSku = false;
    }
  }
}

  onProductTypeChange() {
    if (this.product.productType === 'Combination') {
      // Initialize with one empty component
      if (!this.product.components || this.product.components.length === 0) {
        this.product.components = [];
        this.addComponent();
      }
      // For combination products, calculate price based on components
      this.calculateCombinationPrices();
    } else if (this.product.productType === 'Variant') {
      // Initialize variant data if needed
      if (!this.selectedVariations) {
        this.selectedVariations = [];
      }
      this.generateVariantCombinations();
    }
  }

  removeComponent(index: number) {
    this.product.components.splice(index, 1);
    this.calculateCombinationPrices();
  }

  onComponentProductChange(index: number) {
    this.calculateCombinationPrices();
  }

  getComponentProduct(index: number): any {
    const component = this.product.components[index];
    if (!component || !component.productId) return null;
    return this.availableProducts.find(p => p.id === component.productId);
  }


 
  calculateRecommendedPrice(): number {
    const cost = this.calculateCombinationPrices();
    const price = cost * (1 + (this.product.marginPercentage / 100));
    return this.roundToWholeNumber(price);
  }

  calculateCombinationPrices(): number {
    if (!this.product.components) return 0;
    
    const cost = this.product.components.reduce((total: number, component: any) => {
      const product = this.getComponentProduct(this.product.components.indexOf(component));
      if (product && product.defaultPurchasePriceExcTax) {
        return total + (product.defaultPurchasePriceExcTax * component.quantity);
      }
      return total;
    }, 0);
    
    // Round the calculated cost
    return this.roundToWholeNumber(cost);
  }


  // Variant Product Methods
  isVariationSelected(variationId: string): boolean {
    return this.selectedVariations.some(v => v.id === variationId);
  }

  toggleVariationSelection(variation: any) {
    const index = this.selectedVariations.findIndex(v => v.id === variation.id);
    if (index >= 0) {
      this.selectedVariations.splice(index, 1);
    } else {
      this.selectedVariations.push({
        id: variation.id,
        name: variation.name,
        values: []
      });
    }
    this.generateVariantCombinations();
  }

  isValueSelected(variationId: string, value: string): boolean {
    const variation = this.selectedVariations.find(v => v.id === variationId);
    return variation ? variation.values.includes(value) : false;
  } 

  toggleValueSelection(variationId: string, value: string) {
    const variation = this.selectedVariations.find(v => v.id === variationId);
    if (variation) {
      const valueIndex = variation.values.indexOf(value);
      if (valueIndex >= 0) {
        variation.values.splice(valueIndex, 1);
      } else {
        variation.values.push(value);
      }
      this.generateVariantCombinations();
    }
  }

  generateVariantCombinations() {
    if (!this.selectedVariations || this.selectedVariations.length === 0) {
      this.variantCombinations = [];
      return;
    }

    // Filter out variations with no selected values
    const activeVariations = this.selectedVariations.filter(v => v.values && v.values.length > 0);
    
    if (activeVariations.length === 0) {
      this.variantCombinations = [];
      return;
    }

    // Generate all possible combinations of selected values
    const combinations = this.getCombinations(activeVariations);
    
    // Update or create variant combinations
    const newCombinations = combinations.map(comb => {
      const existing = this.variantCombinations.find(vc => 
        this.arraysEqual(vc.values, comb.values)
      );
      
      return existing || {
        values: comb.values,
        sku: this.generateVariantSku(comb.values),
        price: this.roundToWholeNumber(this.product.defaultSellingPriceExcTax || 0),
        quantity: 0
      };
    });
  
    this.variantCombinations = newCombinations;
  }
  getCombinations(variations: any[]): any[] {
    if (variations.length === 0) return [];
    if (variations.length === 1) {
      return variations[0].values.map((value: string) => ({
        values: [value]
      }));
    }
    
    const first = variations[0];
    const rest = this.getCombinations(variations.slice(1));
    
    const result: any[] = [];
    first.values.forEach((value: string) => {
      rest.forEach((r) => {
        result.push({
          values: [value, ...r.values]
        });
      });
    });
    
    return result;
  }

generateVariantSku(values: string[]): string {
  const baseSku = this.product.sku || '100001'; // Default fallback
  const variantCode = values.map(v => {
    // Convert first 3 letters to numeric representation
    return v.substring(0, 3).split('').map(c => c.charCodeAt(0)).join('');
  }).join('-');
  return `${baseSku}-${variantCode}`;
}

  arraysEqual(a1: any[], a2: any[]): boolean {
    return a1.length === a2.length && a1.every((v, i) => v === a2[i]);
  }

  onTaxChange() {
    if (this.product.applicableTax && this.product.applicableTax !== 'None') {
      if (typeof this.product.applicableTax === 'object') {
        this.product.taxPercentage = this.product.applicableTax.percentage;
      } else {
        const selectedTax = this.taxRates.find(tax =>
          tax.id === this.product.applicableTax || tax.name === this.product.applicableTax
        );
        this.product.taxPercentage = selectedTax ? selectedTax.percentage : 0;
      }
    } else {
      this.product.taxPercentage = 0;
    }

    this.calculateAllPrices();
  }

  private getTaxPercentage(): number {
    return this.product.taxPercentage || 0;
  }
calculateTaxAmount(): number {
  const taxPercentage = this.getTaxPercentage();
  if (!taxPercentage || !this.product.defaultSellingPriceIncTax) return 0;
  
  const taxAmount = this.product.defaultSellingPriceIncTax - 
                   (this.product.defaultSellingPriceIncTax / (1 + taxPercentage / 100));
  
  return this.roundToTwoDecimals(taxAmount);
}

  calculateTax() {
    this.calculateAllPrices();
  }

calculateSellingPrice() {
  const { defaultPurchasePriceExcTax, marginPercentage } = this.product;
  if (defaultPurchasePriceExcTax && marginPercentage !== null) {
    // Calculate selling price before tax
    const calculatedPrice = parseFloat(defaultPurchasePriceExcTax) * (1 + marginPercentage / 100);
    this.product.defaultSellingPriceExcTax = this.roundToTwoDecimals(calculatedPrice);
    
    // Calculate MRP (including tax)
    this.calculateSellingPriceIncTax();
  }
}

 calculateSellingPriceIncTax() {
  const taxPercentage = this.getTaxPercentage();
  if (this.product.defaultSellingPriceExcTax !== null) {
    // Calculate MRP by adding tax to selling price
    const calculatedPrice = parseFloat(this.product.defaultSellingPriceExcTax) * (1 + taxPercentage / 100);
    this.product.defaultSellingPriceIncTax = this.roundToTwoDecimals(calculatedPrice);
  }
}
  

  calculatePurchasePriceExcTax() {
    const taxPercentage = this.getTaxPercentage();
    if (this.product.defaultPurchasePriceIncTax !== null) {
      this.product.defaultPurchasePriceExcTax =
        this.product.defaultPurchasePriceIncTax / (1 + taxPercentage / 100);

      this.calculateSellingPrice();
    }
  }

  calculatePurchasePriceIncTax() {
    const taxPercentage = this.getTaxPercentage();
    if (this.product.defaultPurchasePriceExcTax !== null) {
      this.product.defaultPurchasePriceIncTax =
        parseFloat(this.product.defaultPurchasePriceExcTax) * (1 + taxPercentage / 100);
    }
  }


calculateAllPrices() {
  const taxPercentage = this.getTaxPercentage();
  
  // Calculate from margin if MRP is not set
  if (!this.product.defaultSellingPriceIncTax) {
    // For combination products, use component costs as base
    if (this.product.productType === 'Combination' && this.product.components?.length) {
      const cost = this.calculateCombinationPrices();
      const priceBeforeTax = cost * (1 + this.product.marginPercentage / 100);
      this.product.defaultSellingPriceExcTax = this.roundToTwoDecimals(priceBeforeTax);
      this.product.defaultSellingPriceIncTax = this.roundToTwoDecimals(priceBeforeTax * (1 + taxPercentage / 100));
    }
    // For regular products, we can't calculate without a base price, so leave fields empty
  } else {
    // If MRP is set, calculate the other values from it
    this.calculateFromMRP();
  }
}
async addProduct() {
  this.productFormSubmitted = true;
  
  // Validate form before proceeding
  if (!this.validateForm()) {
    this.isLoading = false;
    return;
  }

  try {
    this.isLoading = true;

    // Generate SKU if not provided
    if (!this.product.sku && this.product.productName) {
      this.product.sku = await this.generateNumericSku();
    }
  if (!this.product.addedDate) {
      this.product.addedDate = new Date();
    }

    // Validate based on product type
    switch (this.product.productType) {
      case 'Combination':
        this.validateCombinationProduct();
        break;
      case 'Variant':
        this.validateVariantProduct();
        break;
    }

    // Calculate final prices
    this.calculateAllPrices();

    // Save or update product
    if (this.isEditing && this.product.id) {
      await this.productsService.updateProduct(this.product.id, this.product);
      this.showSuccess('Product updated successfully!');
    } else {
      await this.productsService.addProduct(this.product);
      this.showSuccess('Product added successfully!');
    }

    this.resetForm();
  } catch (error) {
    this.handleError(error);
  } finally {
    this.isLoading = false;
  }
}
// Helper methods for better organization
private validateCombinationProduct() {
  this.product.components = (this.product.components || []).filter((c: { productId: any; }) => c.productId);
  if (this.product.components.length === 0) {
    throw new Error('Please add at least one component for combination products');
  }
}

private validateVariantProduct() {
  this.product.variations = this.variantCombinations.map(vc => ({
    values: vc.values,
    sku: vc.sku,
    price: vc.price,
    quantity: vc.quantity
  }));
  
  if (this.product.variations.length === 0) {
    throw new Error('Please select at least one variation for variant products');
  }
}

private showSuccess(message: string) {
  // You could replace this with a toast notification or other UI feedback
  alert(message);
}

private handleError(error: unknown) {
  console.error('Error saving product:', error);
  const errorMessage = error instanceof Error ? error.message : 'Failed to save product';
  
  // More user-friendly error messages
  if (errorMessage.includes('Applicable Tax')) {
    alert('Please select a valid tax option or choose "None" if no tax applies');
  } else {
    alert(`Error: ${errorMessage}`);
  }
}
validateForm(): boolean {
  // Check required fields
  if (!this.product.productName) {
    alert('Product name is required');
    return false;
  }
  
  if (!this.product.unit) {
    alert('Unit is required');
    return false;
  }
  
  if (!this.product.barcodeType) {
    alert('Barcode type is required');
    return false;
  }
  
  if (!this.product.sellingPriceTaxType) {
    alert('Selling price tax type is required');
    return false;
  }
  
  // Updated validation for Applicable Tax
  if (this.product.applicableTax === null || this.product.applicableTax === undefined) {
    alert('Applicable Tax is required');
    return false;
  }
  
  if (!this.product.defineProduct) {
    alert('Product definition is required');
    return false;
  }
  
  if (!this.product.productType) {
    alert('Product type is required');
    return false;
  }
  
  // If it's a variant type, ensure there are variations
  if (this.product.productType === 'Variant' && (!this.variantCombinations || this.variantCombinations.length === 0)) {
    alert('Please select at least one variation');
    return false;
  }
  
  // If it's a combination type, ensure there are components
  if (this.product.productType === 'Combination' && (!this.product.components || this.product.components.length === 0)) {
    alert('Please add at least one component');
    return false;
  }
  
  return true;
}

  async saveAndAddOpeningStock() {
    if (!this.validateForm()) {
      return;
    }
    
    try {
      this.isLoading = true;

      if (!this.product.sku && this.product.productName) {
this.product.sku = await this.generateNumericSku();
      }

      this.calculateAllPrices();

      let productId: string;

      if (this.isEditing && this.product.id) {
        await this.productsService.updateProduct(this.product.id, this.product);
        productId = this.product.id;
      } else {
        productId = await this.productsService.addProduct(this.product);
      }

      const productData = {
        id: productId,
        productName: this.product.productName,
        unit: this.product.unit,
        defaultPurchasePriceExcTax: this.product.defaultPurchasePriceExcTax,
        sku: this.product.sku
      };

      this.router.navigate(['/opening-stock'], {
        queryParams: {
          productId: productId,
          productData: JSON.stringify(productData)
        }
      });

    } catch (error) {
      console.error('Error in saveAndAddOpeningStock:', error);
      alert(`Error: ${error instanceof Error ? error.message : 'Failed to save product'}`);
    } finally {
      this.isLoading = false;
    }
  }

  async saveAndAddAnother() {
    try {
      await this.addProduct();
      this.resetForm();
      setTimeout(() => {
        const firstInput = document.querySelector('input');
        (firstInput as HTMLInputElement)?.focus();
      }, 100);
    } catch (error) {
      console.error('Error in saveAndAddAnother:', error);
    }
  }

  editProduct(product: any) {
    this.product = { ...product };
    if (product.applicableTax && product.applicableTax !== 'None') {
      if (typeof product.applicableTax === 'object') {
        this.product.taxPercentage = product.applicableTax.percentage;
      } else {
        const selectedTax = this.taxRates.find(tax =>
          tax.id === product.applicableTax || tax.name === product.applicableTax
        );
        this.product.taxPercentage = selectedTax ? selectedTax.percentage : 0;
      }
    }
    this.isEditing = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }


  async deleteProduct(productId: string) {
    if (confirm('Are you sure you want to delete this product?')) {
      try {
        await this.productsService.deleteProduct(productId);
        alert('Product deleted successfully!');
      } catch (error) {
        console.error('Error deleting product:', error);
        alert('Failed to delete product');
      }
    }
  }

  resetForm() {
    this.product = this.getInitialProduct();
    this.isEditing = false;
    this.filteredSubCategories = [];
  }

  onFileSelected(event: Event, type: 'image' | 'brochure') {
    const input = event.target as HTMLInputElement;
    if (input?.files && input.files.length > 0) {
      const file = input.files[0];
      if (type === 'image') {
        this.product.productImage = file;
      } else {
        this.product.productBrochure = file;
      }
    }
  }
}