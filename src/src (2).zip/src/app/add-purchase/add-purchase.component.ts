import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { PurchaseService } from '../services/purchase.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SupplierService } from '../services/supplier.service';
import { LocationService } from '../services/location.service';
import { ProductsService } from '../services/products.service';
import { PurchaseOrderService } from '../services/purchase-order.service';
import { PurchaseOrder } from '../services/purchase-order.service';
import { AuthService } from '../auth.service';
import { UserService } from '../services/user.service';
import { TaxService } from '../services/tax.service';
import { TaxRate } from '../tax/tax.model';
import { AccountService } from '../services/account.service';
// Add to imports
import { PurchaseRequisitionService } from '../services/purchase-requisition.service';



interface Supplier {
  id: string;
  contactId?: string;
  businessName?: string;
  firstName?: string;
  lastName?: string;
  isIndividual?: boolean;
  addressLine1?: string;
  postalCode?: string;
  address?: string;
  email?: string;
  mobile?: string;
}
// Update the interface at the top of your component file
// Update your existing Product interface to include all needed properties
interface Product {
  id?: string;
  productId?: string;
  productName: string;
  quantity: number;
  unitCost: number;
  discountPercent: number;
  unitCostBeforeTax: number;
  subtotal: number;
  taxAmount: number;
  lineTotal: number;
  profitMargin: number;
  sellingPrice: number;
  batchNumber: string;
  expiryDate: string;
  taxRate: number;
  commissionPercent?: number;
  commissionAmount?: number;
  netCost?: number;
  productTax?: number;
}

@Component({
  selector: 'app-add-purchase',
  templateUrl: './add-purchase.component.html',
  styleUrls: ['./add-purchase.component.scss']
})
export class AddPurchaseComponent implements OnInit {
  purchaseForm!: FormGroup;
  suppliers: Supplier[] = [];

  requisitions: any[] = [];
  selectedRequisition: any = null;
purchaseOrders: any[] = []; // Add this line with other properties
requisitionData: any = null;
  businessLocations: any[] = [];
// In your AddPurchaseOrderComponent

// Add this property to track requisition data
  selectedSupplier: Supplier | null = null;
  totalItems = 0;
  netTotalAmount = 0;
  totalTax = 0;
  paymentAccounts: any[] = [];
  selectedProducts: Set<number> = new Set<number>();

  users: any[] = [];
  productsList: any[] = [];
  purchaseOrderId: string | null = null;
  purchaseOrderData: any = null;
  isLoadingFromPurchaseOrder = false;
  currentUser: any = null;
  taxRates = [0, 5, 10, 12, 18, 28]; 
  taxRatesList: TaxRate[] = [];
  additionalTaxAmount = 0;

  constructor(
    private fb: FormBuilder,
    private purchaseService: PurchaseService,
    private supplierService: SupplierService,
    private locationService: LocationService,
    private router: Router,
    private productsService: ProductsService,
    private route: ActivatedRoute,
    private purchaseOrderService: PurchaseOrderService,
    private authService: AuthService,
    private userService: UserService,
    private taxService: TaxService,
    private accountService: AccountService,
      private purchaseRequisitionService: PurchaseRequisitionService // Add this line


  ) {}
onPurchaseOrderSelect(orderId: string): void {
  if (orderId) {
    this.purchaseOrderId = orderId;
    this.isLoadingFromPurchaseOrder = true;
    this.loadPurchaseOrderData(orderId);
  } else {
    this.purchaseOrderId = null;
    this.isLoadingFromPurchaseOrder = false;
    // Reset form if needed
    this.generateReferenceNumber();
    this.generateInvoiceNumber();
  }
}
// Update ngOnInit
ngOnInit(): void {
  this.initForm();
  this.loadSuppliers();
  this.loadBusinessLocations();
  this.loadProducts();
  this.getCurrentUser();
  this.loadUsers();
  this.loadTaxRates();
    this.loadPurchaseOrders(); // Add this line

  this.loadPaymentAccounts();

  this.route.queryParams.subscribe(params => {
    const requisitionId = params['requisitionId'];
    const orderId = params['orderId'];
    
    if (requisitionId) {
      this.loadRequisitionData(requisitionId);
    } else if (orderId) {
      this.purchaseOrderId = orderId;
      this.isLoadingFromPurchaseOrder = true;
      this.loadPurchaseOrderData(orderId);
    } else {
      this.generateReferenceNumber();
      this.generateInvoiceNumber();
    }
  });
}

async loadRequisitionData(requisitionId: string) {
  try {
    const requisition = await this.purchaseRequisitionService.getRequisitionById(requisitionId).toPromise();
    this.requisitionData = requisition;
    this.prefillFormFromRequisition(requisition);
  } catch (error) {
    console.error('Error loading requisition:', error);
    this.generateReferenceNumber();
    this.generateInvoiceNumber();
  }
}
loadPurchaseOrders(): void {
  this.purchaseOrderService.getOrders().subscribe(orders => {
    this.purchaseOrders = orders.filter((order: any) => order.status !== 'Completed');
  });
}
prefillFormFromRequisition(requisition: any) {
  this.purchaseForm.patchValue({
    referenceNo: requisition.referenceNo || '',
    businessLocation: requisition.location || '',
    additionalNotes: `Created from Requisition: ${requisition.referenceNo}`,
    purchaseDate: new Date().toISOString().substring(0, 10)
  });

  if (requisition.items && requisition.items.length > 0) {
    this.productsFormArray.clear();
    requisition.items.forEach((item: any) => {
      this.addProductFromRequisition(item);
    });
  }
  this.calculateTotals();
}

addProductFromRequisition(item: any) {
  const productGroup = this.fb.group({
    productId: [item.productId || ''],
    productName: [item.productName || '', Validators.required],
    quantity: [item.requiredQuantity || 1, [Validators.required, Validators.min(1)]],
    unitCost: [0, [Validators.required, Validators.min(0)]],
    discountPercent: [0, [Validators.min(0), Validators.max(100)]],
    unitCostBeforeTax: [{value: 0, disabled: true}],
    netCost: [{value: 0, disabled: true}],
    productTax: [{value: 0, disabled: true}],
    subtotal: [{value: 0, disabled: true}],
    taxAmount: [{value: 0, disabled: true}],
    lineTotal: [{value: 0, disabled: true}],
    profitMargin: [0, [Validators.min(0)]],
    sellingPrice: [{value: 0, disabled: true}],
    batchNumber: [''],
    expiryDate: [''],
    taxRate: [0],
    commissionPercent: [0, [Validators.min(0), Validators.max(100)]],
    commissionAmount: [{value: 0, disabled: true}]
  });
  this.productsFormArray.push(productGroup);
}
  loadTaxRates(): void {
    this.taxService.getTaxRates().subscribe(rates => {
      this.taxRatesList = rates;
    });
  }
  loadPaymentAccounts(): void {
    this.accountService.getAccounts((accounts: any[]) => {
      this.paymentAccounts = accounts;
    });
  }
  loadUsers(): void {
    this.userService.getUsers().subscribe(users => {
      this.users = users;
    });
  }
  
  getCommissionAmount(index: number): number {
    const productGroup = this.productsFormArray.at(index);
    const subtotal = parseFloat(productGroup.get('subtotal')?.value) || 0;
    const commissionPercent = parseFloat(productGroup.get('commissionPercent')?.value) || 0;
    return subtotal * (commissionPercent / 100);
}

getSubtotal(index: number): number {
    const productGroup = this.productsFormArray.at(index);
    return parseFloat(productGroup.get('subtotal')?.value) || 0;
}

get totalCommission(): number {
    let total = 0;
    for (let i = 0; i < this.productsFormArray.length; i++) {
        total += this.getCommissionAmount(i);
    }
    return total;
}
onSupplierChange(supplierId: string): void {
  const selectedSupplier = this.suppliers.find(s => s.id === supplierId);
  if (selectedSupplier) {
    this.selectedSupplier = selectedSupplier;
    this.purchaseForm.patchValue({
      supplierName: this.getSupplierDisplayName(selectedSupplier),
      address: selectedSupplier.addressLine1 || ''
    });
    
    // Load purchase orders for this supplier
  }




}
  toggleProductSelection(index: number): void {
    if (this.selectedProducts.has(index)) {
      this.selectedProducts.delete(index);
    } else {
      this.selectedProducts.add(index);
    }
  }
  isProductSelected(index: number): boolean {
    return this.selectedProducts.has(index);
  }
  deleteSelectedProducts(): void {
    if (this.selectedProducts.size === 0) {
      alert('Please select at least one product to delete');
      return;
    }
  
    if (confirm(`Are you sure you want to delete ${this.selectedProducts.size} selected products?`)) {
      // Convert the Set to an array and sort in descending order
      const indexesToDelete = Array.from(this.selectedProducts).sort((a, b) => b - a);
      
      // Remove each selected product
      indexesToDelete.forEach(index => {
        this.productsFormArray.removeAt(index);
      });
      
      // Clear selection
      this.selectedProducts.clear();
      
      // Recalculate totals
      this.calculateTotals();
    }
  }  
  // Add this method to your component class
toggleSelectAll(event: any): void {
  const isChecked = event.target.checked;
  
  if (isChecked) {
    // Select all products
    this.productsFormArray.controls.forEach((_, index) => {
      this.selectedProducts.add(index);
    });
  } else {
    // Deselect all products
    this.selectedProducts.clear();
  }
}
  getCurrentUser(): void {
    this.authService.getCurrentUser().subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.purchaseForm.patchValue({
          addedBy: {
            id: user.uid,
            name: user.displayName || user.email,
            email: user.email
          },
          assignedTo: user.uid
        });
      }
    });
  }

  loadPurchaseOrderData(orderId: string): void {
    this.purchaseOrderService.getOrderById(orderId)
      .then((orderData) => {
        if (orderData) {
          this.purchaseOrderData = orderData;
          this.prefillFormFromPurchaseOrder(orderData);
        }
      })
      .catch((err: any) => {
        console.error('Error loading purchase order:', err);
        this.generateReferenceNumber();
        this.generateInvoiceNumber();
      });
  }
addProductFromPurchaseOrder(product: any): void {
    const productGroup = this.fb.group({
        productId: [product.id || product.productId || ''],
        productName: [product.productName || '', Validators.required],
        quantity: [product.quantity || 1, [Validators.required, Validators.min(1)]],
        unitCost: [product.unitCost || product.unitPrice || 0, [Validators.required, Validators.min(0)]],
        discountPercent: [product.discountPercent || 0, [Validators.min(0), Validators.max(100)]],
        unitCostBeforeTax: [{value: product.unitCost || 0, disabled: true}],
         netCost: [{value: 0, disabled: true}], // New field
        productTax: [{value: 0, disabled: true}],
        subtotal: [{value: 0, disabled: true}],
        taxAmount: [{value: 0, disabled: true}],
        lineTotal: [{value: (product.quantity * product.unitCost) || 0, disabled: true}],
        profitMargin: [product.profitMargin || 0, [Validators.min(0)]],
        sellingPrice: [{value: 0, disabled: true}],
        batchNumber: [product.batchNumber || ''],
        expiryDate: [product.expiryDate || ''],
        taxRate: [product.taxRate || 0],
        commissionPercent: [product.commissionPercent || 0, [Validators.min(0), Validators.max(100)]],
        commissionAmount: [{value: 0, disabled: true}]
    });

    this.productsFormArray.push(productGroup);
    this.calculateLineTotal(this.productsFormArray.length - 1);
}
prefillFormFromPurchaseOrder(orderData: any): void {
  const supplierId = orderData.supplierId || '';
  
  this.purchaseForm.patchValue({
    supplierId: supplierId,
    supplierName: orderData.supplier || '',
    purchaseOrder: orderData.referenceNo || '', // Set this only once
    referenceNo: orderData.referenceNo || '',
    businessLocation: orderData.businessLocation || '',
    additionalNotes: orderData.notes || '',
    shippingCharges: orderData.shippingCharges || 0,
    invoicedDate: orderData.invoicedDate || '',
    receivedDate: orderData.receivedDate || '',
    invoiceNo: orderData.invoiceNo || '',
    purchaseTaxId: orderData.purchaseTaxId || ''
  });

  this.purchaseForm.get('referenceNo')?.enable();
  
  while (this.productsFormArray.length !== 0) {
    this.productsFormArray.removeAt(0);
  }
  
  if (orderData.products && orderData.products.length > 0) {
    orderData.products.forEach((product: any) => {
      this.addProductFromPurchaseOrder(product);
    });
  } else {
    this.addProduct();
  }
  
  if (supplierId) {
    this.onSupplierChange(supplierId);
  }
  
  this.calculateTotals();
}

  navigateToAddSupplier(): void {
    this.router.navigate(['/suppliers']);
  }

addProduct(): void {
    const productGroup = this.fb.group({
        productId: [''],
        productName: ['', Validators.required],
        quantity: [1, [Validators.required, Validators.min(1)]],
        unitCost: [0, [Validators.required, Validators.min(0)]],
        discountPercent: [0, [Validators.min(0), Validators.max(100)]],
        unitCostBeforeTax: [{value: 0, disabled: true}],
        subtotal: [{value: 0, disabled: true}],
        taxAmount: [{value: 0, disabled: true}],
        lineTotal: [{value: 0, disabled: true}],
        netCost: [{value: 0, disabled: true}], // New field
        productTax: [{value: 0, disabled: true}],
        profitMargin: [0, [Validators.min(0)]],
        sellingPrice: [{value: 0, disabled: true}],
        batchNumber: [''],
        expiryDate: [''],
        taxRate: [0],
        commissionPercent: [0, [Validators.min(0), Validators.max(100)]],
        commissionAmount: [{value: 0, disabled: true}]
    });

    this.productsFormArray.push(productGroup);
    this.calculateTotals();
}

  loadProducts(): void {
    this.productsService.getProductsRealTime().subscribe((products: any[]) => {
      this.productsList = products.map(product => ({
        ...product,
        // Ensure these fields are available
        defaultPurchasePriceExcTax: product.defaultPurchasePriceExcTax || 0,
        defaultSellingPriceExcTax: product.defaultSellingPriceExcTax || 0,
        marginPercentage: product.marginPercentage || 0,
        applicableTax: product.applicableTax || { percentage: 0 },
        batchNumber: product.batchNumber || '',
        expiryDate: product.expiryDate || ''
      }));
    });
}

  initForm(): void {
    this.purchaseForm = this.fb.group({
      address: [''],
      referenceNo: [{value: '', disabled: true}, Validators.required],
      purchaseDate: [new Date().toISOString().substring(0, 10), Validators.required],
    purchaseStatus: ['Received', Validators.required], // Set default value
      businessLocation: ['', Validators.required],
      payTerm: [''],
      purchaseOrder: ['']  ,
          purchaseOrderId: [''], // Add this line

      document: [null],
      discountType: [''],
      discountAmount: [0],
      purchaseTaxId: [''], // New field for tax id
      purchaseTaxRate: [0], // New field for tax rate value
      additionalNotes: [''],
      shippingCharges: [0, [Validators.min(0)]],
      products: this.fb.array([]),
      purchaseTotal: [0],
      paymentAmount: [0, [Validators.required, Validators.min(0)]],
      paidOn: [new Date().toISOString().substring(0, 10), Validators.required],
      paymentMethod: ['', Validators.required],
      paymentAccount: [''],
      paymentNote: [''],
      balance: [0],
      totalPayable: [0],
      roundedTotal: [0],
      addedBy: this.fb.group({
        id: [''],
        name: [''],
        email: ['']
      }),
      // New fields
      invoiceNo: [''],
      invoicedDate: [''],
      receivedDate: [''],
      batchNumber: [''],
      expiryDate: ['']
    });

    this.addProduct();

    // Listen to form changes
    this.purchaseForm.get('shippingCharges')?.valueChanges.subscribe(() => {
      this.calculateTotals();
    });

    this.purchaseForm.get('paymentAmount')?.valueChanges.subscribe(() => {
      this.calculatePaymentBalance();
    });

    // Listen to tax rate changes
    this.purchaseForm.get('purchaseTaxId')?.valueChanges.subscribe((taxId) => {
      if (taxId) {
        const selectedTax = this.taxRatesList.find(tax => tax.id === taxId);
        if (selectedTax) {
          this.purchaseForm.get('purchaseTaxRate')?.setValue(selectedTax.rate);
        } else {
          this.purchaseForm.get('purchaseTaxRate')?.setValue(0);
        }
      } else {
        this.purchaseForm.get('purchaseTaxRate')?.setValue(0);
      }
      this.calculateTotals();
    });
  }

  generateInvoiceNumber(): void {
    const randomNumber = Math.floor(100000 + Math.random() * 900000);
    const now = new Date();
    const year = now.getFullYear().toString().slice(-2);
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const invNumber = `INV-${year}${month}${day}-${randomNumber}`;
    this.purchaseForm.get('invoiceNo')?.setValue(invNumber);
  }

  calculatePaymentBalance(): void {
    const totalPayable = this.purchaseForm.get('totalPayable')?.value || 0;
    const paymentAmount = this.purchaseForm.get('paymentAmount')?.value || 0;
    const balance = Math.max(0, totalPayable - paymentAmount);
    
    this.purchaseForm.patchValue({
      balance: balance
    });
  }

  get productsFormArray(): FormArray {
    return this.purchaseForm.get('products') as FormArray;
  }

getNetCost(index: number): number {
    const productGroup = this.productsFormArray.at(index);
    const quantity = productGroup.get('quantity')?.value || 0;
    const unitCost = productGroup.get('unitCost')?.value || 0;
    const discountPercent = productGroup.get('discountPercent')?.value || 0;
    
    const grossAmount = quantity * unitCost;
    const discountAmount = grossAmount * (discountPercent / 100);
    return grossAmount - discountAmount;
}
onProductSelect(index: number, event: Event): void {
    const selectElement = event.target as HTMLSelectElement;
    const productId = selectElement.value;
    const selectedProduct = this.productsList.find(p => p.id === productId);
    const productGroup = this.productsFormArray.at(index);
    
    if (selectedProduct) {
        // Calculate the unit cost before tax (after discount)
        const unitCost = selectedProduct.defaultPurchasePriceExcTax || 0;
        const discountPercent = productGroup.get('discountPercent')?.value || 0;
        const netCost = unitCost * (1 - (discountPercent / 100));
        const unitCostBeforeTax = unitCost * (1 - (discountPercent / 100));
        
        // Calculate selling price with profit margin
        const profitMargin = selectedProduct.marginPercentage || 0;
        const taxRate = selectedProduct.applicableTax?.percentage || selectedProduct.taxRate || 0;
        const productTax = netCost * (taxRate / 100);
        const sellingPrice = unitCostBeforeTax * (1 + (profitMargin / 100)) * (1 + (taxRate / 100));
        
        // Update the form values
        productGroup.patchValue({
            productId: selectedProduct.id,
            productName: selectedProduct.productName,
            unitCost: unitCost.toFixed(2),
            unitCostBeforeTax: unitCostBeforeTax.toFixed(2),
            profitMargin: profitMargin,
            sellingPrice: sellingPrice.toFixed(2),
            netCost: netCost.toFixed(2),
            productTax: productTax.toFixed(2),
            taxRate: taxRate,
            batchNumber: selectedProduct.batchNumber || '',
            expiryDate: selectedProduct.expiryDate || ''
        }, { emitEvent: false });
        
        // Calculate line total
        this.calculateLineTotal(index);
    } else {
        // Reset the form if no product is selected
        productGroup.patchValue({
            productId: '',
            productName: '',
            unitCost: 0,
            unitCostBeforeTax: 0,
            profitMargin: 0,
            sellingPrice: 0,
            taxRate: 0,
            netCost: 0,
            productTax: 0,
            batchNumber: '',
            expiryDate: ''
        }, { emitEvent: false });
    }
}
calculateAdditionalTax(): void {
    const purchaseTaxId = this.purchaseForm.get('purchaseTaxId')?.value;
    const selectedTax = this.taxRatesList.find(tax => tax.id === purchaseTaxId);
    
    if (selectedTax) {
        const taxableAmount = this.netTotalAmount;
        this.additionalTaxAmount = taxableAmount * (selectedTax.rate / 100);
    } else {
        this.additionalTaxAmount = 0;
    }
    
    // You might want to recalculate the total here
    this.calculateTotals();
}


  removeProduct(index: number): void {
    this.productsFormArray.removeAt(index);
    this.calculateTotals();
  }

calculateLineTotal(index: number): void {
    const productGroup = this.productsFormArray.at(index);
    const quantity = productGroup.get('quantity')?.value || 0;
    const unitCost = productGroup.get('unitCost')?.value || 0;
    const discountPercent = productGroup.get('discountPercent')?.value || 0;
    const taxRate = productGroup.get('taxRate')?.value || 0;
    const commissionPercent = productGroup.get('commissionPercent')?.value || 0;
      const netCost = unitCost * (1 - (discountPercent / 100));
    // Calculate product tax amount
    const productTax = netCost * (taxRate / 100);
    const discountedPrice = unitCost * (1 - (discountPercent / 100));
    const subtotal = quantity * discountedPrice;
    const taxAmount = subtotal * (taxRate / 100);
    const lineTotal = subtotal + taxAmount;
    const commissionAmount = subtotal * (commissionPercent / 100);
  
    productGroup.patchValue({
        unitCostBeforeTax: discountedPrice.toFixed(2),
        subtotal: subtotal.toFixed(2),
        taxAmount: taxAmount.toFixed(2),
        lineTotal: lineTotal.toFixed(2),
            netCost: netCost.toFixed(2),
        productTax: productTax.toFixed(2),
        commissionAmount: commissionAmount.toFixed(2)
    }, { emitEvent: false });
  
    this.calculateTotals();
}

calculateSellingPrice(index: number): void {
    const productGroup = this.productsFormArray.at(index);
    const unitCostBeforeTax = parseFloat(productGroup.get('unitCostBeforeTax')?.value) || 0;
    const profitMargin = productGroup.get('profitMargin')?.value || 0;
    const taxRate = productGroup.get('taxRate')?.value || 0;
  
    const priceBeforeTax = unitCostBeforeTax * (1 + (profitMargin / 100));
    const sellingPrice = priceBeforeTax * (1 + (taxRate / 100));
    
    productGroup.patchValue({
        sellingPrice: sellingPrice.toFixed(2)
    }, { emitEvent: false });
}
  calculateTotals(): void {
    this.totalItems = this.productsFormArray.length;
    
    let productsTotal = 0;
    let productsTax = 0;

    this.productsFormArray.controls.forEach(productGroup => {
      productsTotal += (parseFloat(productGroup.get('lineTotal')?.value) || 0);
      productsTax += (parseFloat(productGroup.get('taxAmount')?.value) || 0);
    });

    const shippingCharges = parseFloat(this.purchaseForm.get('shippingCharges')?.value) || 0;
    const purchaseTaxRate = parseFloat(this.purchaseForm.get('purchaseTaxRate')?.value) || 0;
    
    // Calculate additional tax on the subtotal (excluding product-specific taxes)
    const subtotalBeforeTax = productsTotal - productsTax;
    this.additionalTaxAmount = subtotalBeforeTax * (purchaseTaxRate / 100);
    
    // Total tax is product-specific taxes plus purchase tax
    this.totalTax = productsTax + this.additionalTaxAmount;
    
    // Net total amount includes products total and shipping charges
    this.netTotalAmount = productsTotal + shippingCharges + this.additionalTaxAmount;

    // Calculate rounded total and round off amount
    const roundedTotal = Math.round(this.netTotalAmount);
    const roundOffAmount = roundedTotal - this.netTotalAmount;

    this.purchaseForm.patchValue({
      purchaseTotal: this.netTotalAmount,
      totalPayable: roundedTotal, // Use rounded total for payment
      paymentAmount: roundedTotal,
      roundOffAmount: roundOffAmount.toFixed(2),
      roundedTotal: roundedTotal.toFixed(2)
    });

    this.calculatePaymentBalance();
  }

  loadBusinessLocations(): void {
    this.locationService.getLocations().subscribe(
      (locations) => {
        this.businessLocations = locations;
      },
      (error) => {
        console.error('Error loading business locations:', error);
      }
    );
  }

generateReferenceNumber(): void {
  // Generate a random 6-digit number (100000 to 999999)
  const randomNumber = Math.floor(100000 + Math.random() * 900000);
  const refNumber = `PR${randomNumber}`;
  this.purchaseForm.get('referenceNo')?.setValue(refNumber);
}


loadSuppliers(): void {
  this.supplierService.getSuppliers().subscribe((suppliers: any[]) => {
    this.suppliers = suppliers.map(supplier => ({
      id: supplier.id,
      contactId: supplier.contactId,
      businessName: supplier.businessName || '',
      firstName: supplier.firstName || '',
      lastName: supplier.lastName || '',
      isIndividual: supplier.isIndividual || false,
      addressLine1: supplier.addressLine1 || '',
      postalCode: supplier.postalCode,
      address: supplier.address,
      email: supplier.email,
      mobile: supplier.mobile
    } as Supplier)); // Add type assertion here
    
    // Sort suppliers alphabetically by display name
    this.suppliers.sort((a, b) => 
      this.getSupplierDisplayName(a).localeCompare(this.getSupplierDisplayName(b))
    );
  });
}

getSupplierDisplayName(supplier: Supplier): string {
  if (!supplier) return '';
  
  if (supplier.isIndividual) {
    return `${supplier.firstName || ''} ${supplier.lastName || ''}`.trim();
  }
  return supplier.businessName || '';
}


  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.purchaseForm.patchValue({ document: file.name });
    }
  }

async savePurchase() {
  // Mark all fields as touched to show validation errors
  this.markFormGroupTouched(this.purchaseForm);

  // Check if form is valid and has at least one product
  if (this.purchaseForm.valid && this.productsFormArray.length > 0) {
    try {
      // Prepare the purchase data
      const formValue = this.purchaseForm.getRawValue();
      
      // Handle case when selectedSupplier might be null
      const supplierName = this.selectedSupplier ? 
        this.getSupplierDisplayName(this.selectedSupplier) : 
        'Unknown Supplier';

      const purchaseData = {
        ...formValue,
        supplierName: supplierName,
        products: this.productsFormArray.value.map((product: Product) => ({
          ...product,
          // Ensure numeric values are numbers, not strings
          quantity: Number(product.quantity),
          unitCost: Number(product.unitCost),
          discountPercent: Number(product.discountPercent),
          unitCostBeforeTax: Number(product.unitCostBeforeTax),
          subtotal: Number(product.subtotal),
          taxAmount: Number(product.taxAmount),
          lineTotal: Number(product.lineTotal),
          profitMargin: Number(product.profitMargin),
          sellingPrice: Number(product.sellingPrice),
          taxRate: Number(product.taxRate),
          commissionPercent: Number(product.commissionPercent || 0),
          commissionAmount: Number(product.commissionAmount || 0),
          netCost: Number(product.netCost || 0),
          productTax: Number(product.productTax || 0)
        })),
        totalAmount: this.netTotalAmount,
        totalTax: this.totalTax,
        totalItems: this.totalItems,
        status: formValue.purchaseStatus,
        purchaseTotal: this.netTotalAmount,
        grandTotal: this.netTotalAmount,
      };

      // Call your purchase service to save the data
      const result = await this.purchaseService.createPurchase(purchaseData);
      
      // Show success message
      alert('Purchase saved successfully!');
      
      // Navigate to purchases list or reset form
      this.router.navigate(['/list-purchase']);
    } catch (error) {
      console.error('Error saving purchase:', error);
      alert('Error saving purchase. Please try again.');
    }
  } else {
    // Show more specific error messages
    if (this.productsFormArray.length === 0) {
      alert('Please add at least one product!');
    } else {
      alert('Please fill all required fields correctly!');
    }
  }
}

// Helper method to mark all form controls as touched
private markFormGroupTouched(formGroup: FormGroup) {
  Object.values(formGroup.controls).forEach(control => {
    control.markAsTouched();

    if (control instanceof FormGroup) {
      this.markFormGroupTouched(control);
    } else if (control instanceof FormArray) {
      control.controls.forEach(arrayControl => {
        if (arrayControl instanceof FormGroup) {
          this.markFormGroupTouched(arrayControl);
        }
      });
    }
  });
}
}