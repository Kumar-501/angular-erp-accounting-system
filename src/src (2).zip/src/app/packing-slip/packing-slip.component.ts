import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SaleService } from '../services/sale.service';
import { Location } from '@angular/common';
import { Observable, of } from 'rxjs';

interface Product {
  id: string;
  name: string;
  productCode: string;
  quantity: number;
  unitPrice: number;
}

interface PackingSlip {
  id: string;
  packingSlipId: string;
  invoiceNo: string;
  date: string;
  customer: string;
  contactNumber: string;
  location: string;
  deliveryPerson: string;
  products: Product[];
}

@Component({
  selector: 'app-packing-slip',
  templateUrl: './packing-slip.component.html',
  styleUrls: ['./packing-slip.component.scss']
})
export class PackingSlipComponent implements OnInit {
  packingSlip: PackingSlip | null = null;
  loading = true;
  error = false;
  companyName = 'Awesome Shop, Awesome Shop';
  companyAddress = 'Packing Street, Phoenix, Jawai Timur, 80001, Indonesia';
  companyPhone = '+62 (021) 5551-8819';
  companyGSTIN = '34T2569900';
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private saleService: SaleService,
    private location: Location
  ) { }

  ngOnInit(): void {
    const shipmentId = this.route.snapshot.paramMap.get('id');
    if (shipmentId) {
      this.loadPackingSlipData(shipmentId);
    } else {
      this.error = true;
      this.loading = false;
    }
  }

  loadPackingSlipData(shipmentId: string): void {
    this.saleService.getSaleById(shipmentId).subscribe({
      next: (sale) => {
        if (sale) {
          const packingSlipId = `AS${new Date().getFullYear().toString().substr(-2)}${String(new Date().getMonth() + 1).padStart(2, '0')}${String(new Date().getDate()).padStart(2, '0')}-${sale.invoiceNo?.substring(sale.invoiceNo.length - 4) || '0000'}`;
          
          const products = sale.products ?? (sale as any).items ?? [];
          
          this.packingSlip = {
            id: sale.id || '',
            packingSlipId: packingSlipId,
            invoiceNo: sale.invoiceNo || '',
            date: sale.saleDate || new Date().toISOString(),
            customer: sale.customer || '',
            contactNumber: sale.customerPhone || '',
            location: sale.billingAddress || sale.shippingAddress || '',
            deliveryPerson: sale.deliveryPerson || '',
            products: products.map((product: any) => ({
              id: product.id || '',
              name: product.name || product.productName || '',
              productCode: product.productCode || product.sku || '',
              quantity: product.quantity || 0,
              unitPrice: product.unitPrice || product.price || 0
            }))
          };
        } else {
          this.error = true;
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading packing slip data:', error);
        this.error = true;
        this.loading = false;
      }
    });
  }

  print(): void {
    // Store the original display values
    const originalDisplayValues = {
      sidebar: document.querySelector('.sidebar') as HTMLElement,
      navbar: document.querySelector('.navbar') as HTMLElement,
      actions: document.querySelector('.packing-slip-actions') as HTMLElement
    };
  
    // Hide elements before printing
    if (originalDisplayValues.sidebar) originalDisplayValues.sidebar.style.display = 'none';
    if (originalDisplayValues.navbar) originalDisplayValues.navbar.style.display = 'none';
    if (originalDisplayValues.actions) originalDisplayValues.actions.style.display = 'none';
  
    // Get the printable content
    const printContent = document.getElementById('packing-slip-printable')?.innerHTML;
    
    if (printContent) {
      const originalContent = document.body.innerHTML;
      document.body.innerHTML = printContent;
      window.print();
      document.body.innerHTML = originalContent;
    } else {
      window.print();
    }
  
    // Restore the display values after printing
    setTimeout(() => {
      if (originalDisplayValues.sidebar) originalDisplayValues.sidebar.style.display = '';
      if (originalDisplayValues.navbar) originalDisplayValues.navbar.style.display = '';
      if (originalDisplayValues.actions) originalDisplayValues.actions.style.display = '';
    }, 500);
  }
  

  exportToPDF(): void {
    if (!this.packingSlip?.id) return;

    this.saleService.generateDocument(this.packingSlip.id, 'delivery-note').subscribe({
      next: (response: Blob) => {
        this.downloadPdf(response, `packing-slip-${this.packingSlip?.packingSlipId}.pdf`);
      },
      error: (error: any) => {
        console.error('Error generating PDF:', error);
      }
    });
  }

  private downloadPdf(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  goBack(): void {
    this.location.back();
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return `${String(date.getMonth() + 1).padStart(2, '0')}/${String(date.getDate()).padStart(2, '0')}/${date.getFullYear()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  }
}