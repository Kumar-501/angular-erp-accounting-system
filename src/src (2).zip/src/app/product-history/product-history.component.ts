import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from '../services/products.service';
import { PurchaseService, Purchase } from '../services/purchase.service';
import { SaleService } from '../services/sale.service';
import { Product } from '../models/product.model';

interface PurchaseItem {
  productId: string;
  productName: string;
  quantity: number;
  unitCost: number;
}

interface PurchaseWithMatchedItem extends Purchase {
  matchedItem?: PurchaseItem;
}

interface SaleWithMatchedItem {
  id: string;
  saleDate: string;
  invoiceNo: string;
  customer: string;
  paymentStatus: string;
  status: string;
  matchedItem?: {
    productId: string;
    quantity: number;
    unitPrice: number;
    total: number;
  };
}

@Component({
  selector: 'app-product-history',
  templateUrl: './product-history.component.html',
  styleUrls: ['./product-history.component.scss']
})
export class ProductHistoryComponent implements OnInit {
  productId: string = '';
  product: Product | null = null;
  purchaseHistory: PurchaseWithMatchedItem[] = [];
  salesHistory: SaleWithMatchedItem[] = [];
  totalPurchasedQuantity: number = 0;
  totalPurchaseAmount: number = 0;
  totalSoldQuantity: number = 0;
  totalSalesAmount: number = 0;
  isLoading: boolean = true;
  discountAmount:number = 0;
  activeTab: 'purchases' | 'sales' = 'purchases';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductsService,
    private purchaseService: PurchaseService,
    private salesService: SaleService
  ) {}

  async ngOnInit(): Promise<void> {
    this.productId = this.route.snapshot.paramMap.get('id') || '';
    const navigation = this.router.getCurrentNavigation();
    this.product = navigation?.extras.state?.['productData'] || null;

    if (this.productId) {
      if (!this.product) {
        await this.loadProductDetails();
      }
      await this.loadPurchaseHistory();
      await this.loadSalesHistory();
    }
  }

  private async loadProductDetails(): Promise<void> {
    this.isLoading = true;
    try {
      this.product = await this.productService.getProductById(this.productId);
    } catch (error: unknown) {
      console.error('Error loading product details:', error);
    } finally {
      this.isLoading = false;
    }
  }

  private async loadPurchaseHistory(): Promise<void> {
    this.isLoading = true;
    try {
      const purchases = await this.purchaseService.getPurchasesByProductId(this.productId);
      this.processPurchaseHistory(purchases);
    } catch (error: unknown) {
      console.error('Error loading purchase history:', error);
    }
  }

  private async loadSalesHistory(): Promise<void> {
    try {
      const sales = await this.salesService.getSalesByProductId(this.productId).toPromise();
      this.processSalesHistory(sales || []);
    } catch (error: unknown) {
      console.error('Error loading sales history:', error);
    } finally {
      this.isLoading = false;
    }
  }

  private processPurchaseHistory(purchases: Purchase[]): void {
    this.purchaseHistory = [];
    this.totalPurchasedQuantity = 0;
    this.totalPurchaseAmount = 0;

    purchases.forEach((purchase: Purchase) => {
      const matchedItem = purchase.products?.find(item => 
        item.productId === this.productId
      );

      if (matchedItem) {
        const purchaseWithDetails: PurchaseWithMatchedItem = {
          ...purchase,
          matchedItem
        };

        this.purchaseHistory.push(purchaseWithDetails);
        this.totalPurchasedQuantity += matchedItem.quantity || 0;
        this.totalPurchaseAmount += (matchedItem.quantity || 0) * (matchedItem.unitCost || 0);
      }
    });

    this.purchaseHistory.sort((a, b) => {
      const dateA = this.parseDate(a.purchaseDate);
      const dateB = this.parseDate(b.purchaseDate);
      return dateB.getTime() - dateA.getTime();
    });
  }

  private processSalesHistory(sales: any[]): void {
    this.salesHistory = [];
    this.totalSoldQuantity = 0;
    this.totalSalesAmount = 0;

    sales.forEach((sale: any) => {
      const matchedItem = sale.products?.find((item: any) => {
        return item.productId === this.productId || 
               item.id === this.productId ||
               (typeof item.product === 'string' && item.product === this.productId);
      });

      if (matchedItem) {
        const quantity = matchedItem.quantity || 0;
        const unitPrice = matchedItem.unitPrice || matchedItem.defaultSellingPriceExcTax || 0;
        const total = quantity * unitPrice;

        const saleWithDetails: SaleWithMatchedItem = {
          id: sale.id,
          saleDate: sale.saleDate,
          invoiceNo: sale.invoiceNo,
          customer: sale.customer,
          paymentStatus: sale.paymentStatus,
          status: sale.status,
          matchedItem: {
            productId: matchedItem.productId || matchedItem.id || this.productId,
            quantity,
            unitPrice,
            total
          }
        };

        this.salesHistory.push(saleWithDetails);
        this.totalSoldQuantity += quantity;
        this.totalSalesAmount += total;
      }
    });

    this.salesHistory.sort((a, b) => {
      const dateA = this.parseDate(a.saleDate);
      const dateB = this.parseDate(b.saleDate);
      return dateB.getTime() - dateA.getTime();
    });
  }

  public formatDate(date: string | Date | null): string {
    if (!date) return '';
    try {
      const d = this.parseDate(date);
      return d.toLocaleDateString();
    } catch (error: unknown) {
      console.error('Error formatting date:', error);
      return '';
    }
  }

  private parseDate(date: string | Date | null): Date {
    if (!date) return new Date(0);
    if (date instanceof Date) return date;
    return new Date(date);
  }
}