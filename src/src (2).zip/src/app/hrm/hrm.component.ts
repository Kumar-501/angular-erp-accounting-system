import { Component } from '@angular/core';

@Component({
  selector: 'app-hrm',
  templateUrl: './hrm.component.html',
  styleUrl: './hrm.component.scss'
})
export class HrmComponent {

}