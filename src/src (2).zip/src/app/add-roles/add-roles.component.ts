import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RolesService } from '../services/roles.service';

@Component({
  selector: 'app-add-roles',
  templateUrl: './add-roles.component.html',
  styleUrls: ['./add-roles.component.scss']
})
export class AddRolesComponent implements OnInit {
  roleForm: FormGroup;
  isLoading = false;
  allComponents = [
    { name: 'Warranties', component: 'WarrantiesComponent' },

    
    { name: 'View Expense', component: 'ViewExpenseComponent' },
    { name: 'List Accounts', component: 'ListAccountsComponent' },
    { name: 'Trial Balance', component: 'TrialBalanceComponent' },
    { name: 'Cash Flow', component: 'CashFlowComponent' },
    { name: 'Payment Report', component: 'PaymentReportComponent' },
    { name: 'Balance Sheet', component: 'BalanceSheetComponent' },
    { name: 'Business Settings', component: 'BusinessSettingsComponent' },
    { name: 'Business Locations', component: 'BusinessLocationsComponent' },
    { name: 'Invoice Settings', component: 'InvoiceSettingsComponent' },
    { name: 'Barcodes', component: 'BarcodesComponent' },
    { name: 'Printers', component: 'PrintersComponent' },
    { name: 'Tax', component: 'TaxComponent' },
    { name: 'Modifier', component: 'ModifierComponent' },
    { name: 'Type Of Service', component: 'TypeOfServiceComponent' },
    { name: 'Package Subscription', component: 'PackageSubscriptionComponent' },
    { name: 'Add Barcodes', component: 'AddBarcodesComponent' },
    { name: 'Add Printers', component: 'AddPrintersComponent' },
    { name: 'Shipment Details', component: 'ShipmentDetailsComponent' },
    { name: 'CRM', component: 'CrmComponent' },
    { name: 'Leads', component: 'LeadsComponent' },
    { name: 'Follows Up', component: 'FollowsUpComponent' },
    { name: 'Followup Category', component: 'FollowupCategoryComponent' },
    { name: 'Life Stage', component: 'LifeStageComponent' },
    { name: 'Sources', component: 'SourcesComponent' },
    { name: 'Create', component: 'CreateComponent' },
    { name: 'Edit Purchase', component: 'EditPurchaseComponent' },
    { name: 'Edit Purchase Order', component: 'EditPurchaseOrderComponent' },
    { name: 'Login', component: 'LoginComponent' },
    { name: 'Register', component: 'RegisterComponent' },
    { name: 'Opening Stock', component: 'OpeningStockComponent' },
    { name: 'Stock Report', component: 'StockReportComponent' },
    { name: 'Edit Sale', component: 'EditSaleComponent' },
    { name: 'HRM', component: 'HrmComponent' },
    { name: 'Leave Type', component: 'LeaveTypeComponent' },
    { name: 'Leave', component: 'LeaveComponent' },
    { name: 'Attendance', component: 'AttendanceComponent' },
    { name: 'Payroll', component: 'PayrollComponent' },
    { name: 'Holiday', component: 'HolidayComponent' },
    { name: 'Departments', component: 'DepartmentsComponent' },
    { name: 'Designations', component: 'DesignationsComponent' },
    { name: 'Sales Targets', component: 'SalesTargetsComponent' },
    { name: 'Settings', component: 'SettingsComponent' },
    { name: 'View Entry', component: 'ViewEntryComponent' },
    { name: 'Account Book', component: 'AccountBookComponent' },
    { name: 'Add Payroll', component: 'AddPayrollComponent' },
    { name: 'Dashboard', component: 'DashboardComponent' },
    { name: 'Packing Slip', component: 'PackingSlipComponent' },
    { name: 'CRM Dashboard', component: 'CrmDashboardComponent' },
    { name: 'Layout', component: 'LayoutComponent' }
  ];

  constructor(
    private fb: FormBuilder,
    private rolesService: RolesService,
    private snackBar: MatSnackBar,
    private router: Router
  ) {
    this.roleForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['']
    });
  }

  ngOnInit(): void {}

  async onSubmit(): Promise<void> {
    if (this.roleForm.invalid) {
      this.snackBar.open('Please fill all required fields', 'Close', {
        duration: 3000
      });
      return;
    }

    this.isLoading = true;

    try {
      // For this version, we're giving access to all components by default
      const permissions = this.createPermissionsObject();
      
      const roleData = {
        name: this.roleForm.value.name,
        description: this.roleForm.value.description,
        permissions: permissions
      };

      await this.rolesService.createRole(roleData);
      this.snackBar.open('Role created successfully!', 'Close', { duration: 3000 });
      this.router.navigate(['/roles-table']); // Navigate after successful save
    } catch (error) {
      console.error('Error creating role:', error);
      this.snackBar.open('Failed to create role. Please try again.', 'Close', { duration: 3000 });
    } finally {
      this.isLoading = false;
    }
  }

  private createPermissionsObject(): { [key: string]: any } {
    const permissions: { [key: string]: any } = {};
    
    // Give access to all components by default
    this.allComponents.forEach(componentObj => {
      permissions[componentObj.component] = {
        view: true,
        create: true,
        edit: true,
        delete: true
      };
    });
    
    return permissions;
  }

  onClose(): void {
    this.router.navigate(['/roles-table']);
  }
}