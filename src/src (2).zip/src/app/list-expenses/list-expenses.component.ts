import { Component, OnInit, OnDestroy } from '@angular/core';
import { ExpenseService } from '../services/expense.service';
import { LocationService } from '../services/location.service';
import { ExpenseCategoriesService } from '../services/expense-categories.service';
import { SaleService } from '../services/sale.service';
import { PayrollService } from '../services/payroll.service';
import { Expense } from '../models/expense.model';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { DatePipe } from '@angular/common';

interface CombinedEntry {
  id: string;
  date: Date | string;
  referenceNo?: string;
  businessLocation?: string;
  businessLocationName?: string;
  expenseCategory?: string;
  categoryName?: string;
  expenseType?: string;
  accountHead?: string;
  expenseFor?: string;
  expenseForContact?: string;
  applicableTax?: string;
  totalAmount?: number;
  expenseNote?: string;
  isRefund?: boolean;
  isRecurring?: boolean;
  recurringInterval?: string;
  repetitions?: string;
  paymentAmount?: number;
  paidOn?: Date | string;
  paymentMethod?: string;
  paymentAccount?: string;
  paymentNote?: string;
  paymentStatus?: string;
  customer?: string;
  addedBy?: string;
  addedByDisplayName?: string;
  commissionPercentage?: number;
  totalCommission?: number;
  employeeDetails?: EmployeeDetail[];
  products?: any[];
  entryType: 'expense' | 'sale' | 'shipment' | 'payroll';
  
  // Add missing properties from compilation errors
  tax?: number;
  paymentDue?: number;
  entryFor?: string;
  category?: string;
  subCategory?: string;
  balance?: number;
  
  // Add these to make them explicitly available for sorting
  [key: string]: any; // This is the index signature that allows string access
}
interface EmployeeDetail {
  email?: string;
  name: string;
  amount: number;
}
@Component({
  selector: 'app-list-expenses',
  templateUrl: './list-expenses.component.html',
  styleUrls: ['./list-expenses.component.scss'],
  providers: [DatePipe]
})
export class ListExpensesComponent implements OnInit, OnDestroy {
  expenses: Expense[] = [];
  sales: any[] = [];
  shipments: any[] = [];
  payrolls: any[] = [];
  // Add these properties to your component class
sortField: string = 'date';
sortDirection: 'asc' | 'desc' = 'desc';
  combinedEntries: CombinedEntry[] = [];
  filteredEntries: CombinedEntry[] = [];
  businessLocations: any[] = [];
  expenseCategories: any[] = [];
  
  private expensesSub!: Subscription;
  private salesSub!: Subscription;
  private shipmentsSub!: Subscription;
  private locationsSub!: Subscription;
  private categoriesSub!: Subscription;
  private payrollsSub!: Subscription;
  
  currentPage: number = 1;
  entriesPerPage: number = 25;
  totalEntries: number = 0;
  searchTerm: string = '';
  isLoading: boolean = true;
  activeFilter: string = 'overall';
  expandedEntryId: string | null = null;

  constructor(
    private expenseService: ExpenseService,
    private saleService: SaleService,
    private locationService: LocationService,
    private expenseCategoriesService: ExpenseCategoriesService,
    private payrollService: PayrollService,
    private router: Router,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    this.loadLocationsAndCategories();
  }

  loadLocationsAndCategories(): void {
    this.isLoading = true;
    
    this.locationsSub = this.locationService.getLocations().subscribe(locations => {
      this.businessLocations = locations;
      
      this.categoriesSub = this.expenseCategoriesService.getCategories().subscribe(categories => {
        this.expenseCategories = categories;
        this.loadExpensesAndSales();
      });
    });
  }
// Add these methods to your component
sortData(field: string): void {
  if (this.sortField === field) {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    this.sortField = field;
    this.sortDirection = 'asc';
  }

  this.applySorting();
}

private applySorting(): void {
  this.filteredEntries.sort((a, b) => {
    let valueA: any;
    let valueB: any;

    // Handle special cases for different fields
    switch (this.sortField) {
      case 'date':
        valueA = new Date(a.date).getTime();
        valueB = new Date(b.date).getTime();
        break;
      case 'totalAmount':
      case 'totalCommission':
      case 'paymentDue':
      case 'tax':
        valueA = a[this.sortField] || 0;
        valueB = b[this.sortField] || 0;
        break;
      default:
        valueA = a[this.sortField] || '';
        valueB = b[this.sortField] || '';
        
        if (typeof valueA === 'string') valueA = valueA.toLowerCase();
        if (typeof valueB === 'string') valueB = valueB.toLowerCase();
    }

    if (valueA < valueB) return this.sortDirection === 'asc' ? -1 : 1;
    if (valueA > valueB) return this.sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  // Reset to first page after sorting
  this.currentPage = 1;
}
  loadExpensesAndSales(): void {
    this.expensesSub = this.expenseService.getExpenses().subscribe(expenses => {
      this.expenses = expenses;
      
      this.salesSub = this.saleService.listenForSales().subscribe(sales => {
        this.sales = sales.filter(sale => sale.status === 'Completed');
        
        this.shipmentsSub = this.saleService.listenForSales().subscribe(allSales => {
          this.shipments = allSales.filter(sale => 
            (sale as any).shippingStatus === 'Delivered'
          );
          
          this.payrollsSub = this.payrollService.getPayrollsRealTime().subscribe(payrolls => {
            this.payrolls = payrolls.filter(payroll => payroll.status === 'Final');
            
            this.combinedEntries = [
              ...this.mapExpensesToCombinedEntries(this.expenses),
              ...this.mapSalesToCombinedEntries(this.sales),
              ...this.mapShipmentsToCombinedEntries(this.shipments),
              ...this.mapPayrollsToCombinedEntries(this.payrolls)
            ];
            
            this.combinedEntries.sort((a, b) => {
              const dateA = new Date(a.date).getTime();
              const dateB = new Date(b.date).getTime();
              return dateB - dateA;
            });
            
            this.applyFilter(this.activeFilter);
            this.isLoading = false;
          });
        });
      });
    });
  }

  applyFilter(filterType: string): void {
    this.activeFilter = filterType;
    this.currentPage = 1;
    
    switch(filterType) {
      case 'sale':
        this.filteredEntries = this.combinedEntries.filter(entry => entry.entryType === 'sale');
        break;
      case 'shipment':
        this.filteredEntries = this.combinedEntries.filter(entry => entry.entryType === 'shipment');
        break;
      case 'payment':
        this.filteredEntries = this.combinedEntries.filter(entry => 
          (entry.paymentStatus && ['Paid', 'Partial', 'Unpaid'].includes(entry.paymentStatus))
        );
        break;
      case 'payroll':
        this.filteredEntries = this.combinedEntries.filter(entry => entry.entryType === 'payroll');
        break;
      default: // 'overall'
        this.filteredEntries = [...this.combinedEntries];
        break;
    }
    
    this.totalEntries = this.filteredEntries.length;
    this.onSearch({ target: { value: this.searchTerm } }); // Reapply search if any
  }

  toggleProductDetails(entryId: string): void {
    if (this.expandedEntryId === entryId) {
      this.expandedEntryId = null;
    } else {
      this.expandedEntryId = entryId;
    }
  }
  calculateEmployeeAmount(totalAmount: number, employeeCount: number): number {
    if (employeeCount === 0) return 0;
    return totalAmount / employeeCount;
  }
  getProductsDisplayText(products: any[]): string {
    if (!products || products.length === 0) return 'No products';
    if (products.length === 1) {
      return `${products[0].name} (${products[0].quantity})`;
    }
    return `${products[0].name} (${products[0].quantity}) + ${products.length - 1} more`;
  }

  private formatDate(date: any): string {
    if (!date) return '';
    
    try {
      if (typeof date === 'object' && 'toDate' in date) {
        return this.datePipe.transform(date.toDate(), 'shortDate') || '';
      } else if (date instanceof Date) {
        return this.datePipe.transform(date, 'shortDate') || '';
      } else {
        return this.datePipe.transform(new Date(date), 'shortDate') || '';
      }
    } catch (e) {
      console.error('Error formatting date:', e);
      return '';
    }
  }

  mapExpensesToCombinedEntries(expenses: Expense[]): CombinedEntry[] {
    return expenses.map(expense => {
      const location = this.businessLocations.find(loc => loc.id === expense.businessLocation);
      const category = this.expenseCategories.find(cat => cat.id === expense.expenseCategory);
      
      // Cast expense to any to avoid TypeScript errors with potentially missing properties
      const expenseAny = expense as any;
      
      return {
        id: expense.id || '',
        date: expense.date,
        referenceNo: expense.referenceNo,
        businessLocation: expense.businessLocation,
        businessLocationName: location ? location.name : '-',
        expenseCategory: expense.expenseCategory,
        categoryName: category ? category.categoryName : '-',
        expenseType: expense.expenseNote,
        accountHead: '-',
        expenseFor: expense.expenseFor,
        expenseForContact: expense.expenseForContact,
        applicableTax: expense.applicableTax,
        totalAmount: expense.totalAmount,
        expenseNote: expense.expenseNote,
        isRefund: expense.isRefund,
        isRecurring: expense.isRecurring,
        recurringInterval: expense.recurringInterval,
        repetitions: expense.repetitions?.toString(),
        paymentAmount: expense.paymentAmount,
        paidOn: expense.paidOn,
        paymentMethod: expense.paymentMethod,
        paymentAccount: expense.paymentAccount,
        paymentNote: expense.paymentNote,
        paymentStatus: 'Paid',
        customer: '-',
        addedBy: expenseAny.addedBy || 'System',
        addedByDisplayName: expenseAny.addedByDisplayName || expenseAny.addedBy || 'System',
        commissionPercentage: 0,
        totalCommission: 0,
        products: [],
        entryType: 'expense',
        tax: 0,
        paymentDue: 0,
        entryFor: expense.expenseFor || '-'
      };
    });
  }
  
  mapSalesToCombinedEntries(sales: any[]): CombinedEntry[] {
    return sales.map(sale => {
      const location = this.businessLocations.find(loc => loc.id === sale.businessLocation);
      
      return {
        id: sale.id || '',
        date: this.formatDate(sale.saleDate) || new Date(),
        referenceNo: sale.invoiceNo,
        category: 'Sale',
        categoryName: 'Sale',
        subCategory: '-',
        businessLocation: sale.businessLocation,
        businessLocationName: location ? location.name : '-',
        paymentStatus: sale.status,
        paymentMethod: sale.paymentMethod || '-',
        tax: sale.orderTax || 0,
        totalAmount: sale.paymentAmount || 0,
        paymentDue: sale.balance || 0,
        entryFor: sale.customer || '-',
        customer: sale.customer || '-',
        addedBy: sale.addedBy || 'System',
        addedByDisplayName: sale.addedByDisplayName || sale.addedBy || 'System',
        commissionPercentage: sale.commissionPercentage || 0,
        totalCommission: sale.totalCommission || 0,
        products: sale.products || [],
        entryType: 'sale'
      };
    });
  }

  mapShipmentsToCombinedEntries(shipments: any[]): CombinedEntry[] {
    return shipments.map(shipment => {
      const location = this.businessLocations.find(loc => loc.id === shipment.businessLocation);
      
      let paymentStatus = 'Unpaid';
      if (shipment.balance === 0 && shipment.paymentAmount > 0) {
        paymentStatus = 'Paid';
      } else if (shipment.balance > 0 && shipment.paymentAmount > 0) {
        paymentStatus = 'Partial';
      }
      
      return {
        id: shipment.id || '',
        date: this.formatDate(shipment.saleDate) || new Date(),
        referenceNo: shipment.invoiceNo || '-',
        category: 'Shipment',
        categoryName: 'Shipment',
        subCategory: '-',
        businessLocation: shipment.businessLocation,
        businessLocationName: location ? location.name : '-',
        paymentStatus: paymentStatus,
        paymentMethod: shipment.paymentMethod || '-',
        tax: shipment.orderTax || 0,
        totalAmount: shipment.paymentAmount || 0,
        paymentDue: shipment.balance || 0,
        entryFor: shipment.customer || '-',
        customer: shipment.customer || '-',
        addedBy: shipment.addedBy || 'System',
        addedByDisplayName: shipment.addedByDisplayName || shipment.addedBy || 'System',
        commissionPercentage: shipment.commissionPercentage || 0,
        totalCommission: shipment.totalCommission || 0,
        products: shipment.products || [],
        entryType: 'shipment'
      };
    });
  }
  
  mapPayrollsToCombinedEntries(payrolls: any[]): CombinedEntry[] {
    return payrolls.map(payroll => {
      const location = this.businessLocations.find(loc => loc.name === payroll.location);
      
      // Process employee details
      const employeeDetails: EmployeeDetail[] = payroll.employeeDetails?.map((emp: any) => ({
        id: emp.id || emp.employeeId || '',
        name: emp.name || emp.employeeName || 'Unknown',
        amount: emp.amount || emp.salary || 0
      })) || [];
  
      return {
        id: payroll.id || '',
        date: payroll.monthYear ? new Date(payroll.monthYear) : new Date(),
        referenceNo: payroll.name || 'Payroll',
        category: 'Payroll',
        categoryName: 'Payroll',
        subCategory: '-',
        businessLocation: location?.id || '',
        businessLocationName: payroll.location || '-',
        paymentStatus: 'Fixed',
        paymentMethod: 'Bank Transfer',
        tax: 0,
        totalAmount: payroll.totalGross || 0,
        paymentDue: 0,
        entryFor: employeeDetails.length > 0 
          ? this.getFormattedEmployeeNames(employeeDetails) 
          : 'Various Employees',
        customer: employeeDetails.length > 0 
          ? this.getFormattedEmployeeNames(employeeDetails) 
          : 'Various Employees',
        addedBy: payroll.addedBy || 'System',
        addedByDisplayName: payroll.addedByDisplayName || payroll.addedBy || 'System',
        commissionPercentage: 0,
        totalCommission: 0,
        products: [],
        entryType: 'payroll',
        expenseType: 'Salary',
        employeeDetails: employeeDetails
      };
    });
  }

  exportCSV(): void {
    const headers = [
      'Date', 'Reference No', 'Type', 'Category', 'Customer', 'Location', 
      'Payment Status', 'Added By', 'Commission %', 'Commission Amt', 'Tax', 'Total Amount', 'Payment Due', 'Entry For'
    ];
    
    const data = this.filteredEntries.map(entry => [
      new Date(entry.date).toLocaleDateString(),
      entry.referenceNo || '-',
      this.getEntryTypeDisplay(entry.entryType),
      entry.categoryName || '-',
      entry.customer || '-',
      entry.businessLocationName || '-',
      entry.paymentStatus || '-',
      entry.addedByDisplayName || '-',
      entry.commissionPercentage || '0',
      entry.totalCommission || '0.00',
      entry.tax || '0.00',
      entry.totalAmount || '0.00',
      entry.paymentDue || '0.00',
      entry.entryFor || '-'
    ]);

    let csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(',') + "\n" 
      + data.map(e => e.join(',')).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `expenses_sales_payments_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  exportExcel(): void {
    const worksheet = XLSX.utils.json_to_sheet(this.filteredEntries.map(entry => ({
      'Date': new Date(entry.date).toLocaleDateString(),
      'Reference No': entry.referenceNo || '-',
      'Type': this.getEntryTypeDisplay(entry.entryType),
      'Category': entry.categoryName || '-',
      'Customer': entry.customer || '-',
      'Location': entry.businessLocationName || '-',
      'Payment Status': entry.paymentStatus || '-',
      'Added By': entry.addedByDisplayName || '-',
      'Commission %': entry.commissionPercentage || 0,
      'Commission Amt': entry.totalCommission || '0.00',
      'Tax': entry.tax || '0.00',
      'Total Amount': entry.totalAmount || '0.00',
      'Payment Due': entry.paymentDue || '0.00',
      'Entry For': entry.entryFor || '-'
    })));
    
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Expenses Sales");
    XLSX.writeFile(workbook, `expenses_sales_payments_${new Date().toISOString().slice(0, 10)}.xlsx`);
  }

  printTable(): void {
    const printContent = document.getElementById('print-section');
    const WindowObject = window.open('', 'PrintWindow', 'width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes');
    
    if (WindowObject && printContent) {
      WindowObject.document.writeln(`
        <html>
          <head>
            <title>Expenses, Sales, and Payments Report</title>
            <style>
              body { font-family: Arial, sans-serif; }
              table { width: 100%; border-collapse: collapse; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f2f2f2; }
              .total-row { font-weight: bold; }
              .expense-row { background-color: #fff; }
              .sale-row { background-color: #f0f8ff; }
              .shipment-row { background-color: #fffaf0; }
              .payroll-row { background-color: #f8f0ff; }
            </style>
          </head>
          <body>
            <h1>Expenses, Sales, and Payments Report</h1>
            ${printContent.innerHTML}
            <script>
              window.onload = function() {
                setTimeout(function() {
                  window.print();
                  window.close();
                }, 100);
              };
            </script>
          </body>
        </html>
      `);
      WindowObject.document.close();
    }
  }

  exportPDF(): void {
    const doc = new jsPDF();
    const title = 'Expenses, Sales, and Payments Report';
    
    doc.text(title, 14, 16);
    
    (doc as any).autoTable({
      head: [['Date', 'Reference', 'Type', 'Category', 'Customer', 'Location', 'Status', 'Added By', 'Commission %', 'Commission Amt', 'Amount', 'Due']],
      body: this.filteredEntries.map(entry => [
        new Date(entry.date).toLocaleDateString(),
        entry.referenceNo || '-',
        this.getEntryTypeDisplay(entry.entryType),
        entry.categoryName || '-',
        entry.customer || '-',
        entry.businessLocationName || '-',
        entry.paymentStatus || '-',
        entry.addedByDisplayName || '-',
        entry.commissionPercentage || 0,
        entry.totalCommission || '0.00',
        entry.totalAmount || '0.00',
        entry.paymentDue || '0.00'
      ]),
      startY: 25,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255 },
      alternateRowStyles: { fillColor: [245, 245, 245] }
    });
    
    doc.save(`expenses_sales_payments_${new Date().toISOString().slice(0, 10)}.pdf`);
  }

  onSearch(event: any): void {
    this.searchTerm = event.target.value.toLowerCase();
    this.filteredEntries = this.combinedEntries.filter(entry => 
      (entry.referenceNo?.toLowerCase().includes(this.searchTerm)) ||
      (entry.categoryName?.toLowerCase().includes(this.searchTerm)) ||
      (entry.businessLocationName?.toLowerCase().includes(this.searchTerm)) ||
      (entry.paymentStatus?.toLowerCase().includes(this.searchTerm)) ||
      (entry.entryFor?.toLowerCase().includes(this.searchTerm)) ||
      (entry.customer?.toLowerCase().includes(this.searchTerm)) ||
      (entry.addedByDisplayName?.toLowerCase().includes(this.searchTerm)) ||
      (this.getEntryTypeDisplay(entry.entryType).toLowerCase().includes(this.searchTerm))
    );
    
    // Reapply the active filter after search
    if (this.activeFilter !== 'overall') {
      this.applyFilter(this.activeFilter);
    } else {
      this.totalEntries = this.filteredEntries.length;
      this.currentPage = 1;
    }
  }

  changeEntriesPerPage(event: any): void {
    this.entriesPerPage = parseInt(event.target.value);
    this.currentPage = 1;
  }

  get paginatedEntries(): CombinedEntry[] {
    const start = (this.currentPage - 1) * this.entriesPerPage;
    const end = start + this.entriesPerPage;
    return this.filteredEntries.slice(start, end);
  }

  nextPage(): void {
    if (this.currentPage * this.entriesPerPage < this.totalEntries) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  getPaginatedEndIndex(): number {
    return Math.min(this.currentPage * this.entriesPerPage, this.totalEntries);
  }

  editEntry(entry: CombinedEntry): void {
    if (entry.entryType === 'expense') {
      this.router.navigate(['/edit-expense', entry.id]);
    } else if (entry.entryType === 'sale') {
      this.router.navigate(['/edit-sale', entry.id]);
    } else if (entry.entryType === 'shipment') {
      this.router.navigate(['/edit-shipment', entry.id]);
    } else if (entry.entryType === 'payroll') {
      this.router.navigate(['/edit-payroll', entry.id]);
    }
  }

  viewEntry(entry: CombinedEntry): void {
    if (this.expandedEntryId === entry.id) {
      this.expandedEntryId = null;
    } else {
      this.expandedEntryId = entry.id;
    }
  }

  async deleteEntry(entry: CombinedEntry): Promise<void> {
    if (confirm(`Are you sure you want to delete this ${entry.entryType}?`)) {
      try {
        if (entry.entryType === 'expense') {
          await this.expenseService.deleteExpense(entry.id);
        } else if (entry.entryType === 'sale' || entry.entryType === 'shipment') {
          await this.saleService.deleteSale(entry.id);
        } else if (entry.entryType === 'payroll') {
          await this.payrollService.deletePayroll(entry.id);
        }
        this.loadLocationsAndCategories();
      } catch (error) {
        console.error(`Error deleting ${entry.entryType}:`, error);
        alert(`Error deleting ${entry.entryType}. Please try again.`);
      }
    }
  }

  addNewExpense(): void {
    this.router.navigate(['/add-expense']);
  }

  getTotalAmount(): number {
    return this.filteredEntries.reduce((total, entry) => total + (entry.totalAmount || 0), 0);
  }

  getTotalDue(): number {
    return this.filteredEntries.reduce((total, entry) => total + (entry.paymentDue || 0), 0);
  }

  getFormattedEmployeeNames(employees: any[]): string {
    if (!employees || employees.length === 0) return 'No employees';
    
    return employees.map(emp => {
      // Handle different employee data structures
      if (typeof emp === 'string') {
        return emp;
      } else if (emp.id) {
        return emp.name || emp.username || emp.id;
      }
      return 'Unknown';
    }).join(', ');
  }

  getEntryTypeClass(entryType: string): string {
    if (entryType === 'expense') return 'expense-row';
    if (entryType === 'sale') return 'sale-row';
    if (entryType === 'shipment') return 'shipment-row';
    if (entryType === 'payroll') return 'payroll-row';
    return '';
  }

  getEntryTypeDisplay(entryType: string): string {
    if (entryType === 'expense') return 'Expense';
    if (entryType === 'sale') return 'Sale';
    if (entryType === 'shipment') return 'Shipment';
    if (entryType === 'payroll') return 'Payroll';
    return '';
  }

  ngOnDestroy(): void {
    if (this.expensesSub) this.expensesSub.unsubscribe();
    if (this.salesSub) this.salesSub.unsubscribe();
    if (this.shipmentsSub) this.shipmentsSub.unsubscribe();
    if (this.locationsSub) this.locationsSub.unsubscribe();
    if (this.categoriesSub) this.categoriesSub.unsubscribe();
    if (this.payrollsSub) this.payrollsSub.unsubscribe();
  }
}