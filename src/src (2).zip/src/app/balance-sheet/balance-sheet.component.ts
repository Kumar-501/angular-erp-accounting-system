import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../services/products.service';
import { AccountService } from '../services/account.service';
import { PurchaseService } from '../services/purchase.service';
import { SaleService } from '../services/sale.service';

interface BalanceSheetItem {
  name: string;
  amount: number;
}

@Component({
  selector: 'app-balance-sheet',
  templateUrl: './balance-sheet.component.html',
  styleUrls: ['./balance-sheet.component.scss']
})
export class BalanceSheetComponent implements OnInit {
  // Liabilities
  liabilities: BalanceSheetItem[] = [
    { name: 'Supplier Due', amount: 0 },
      { name: 'Capital Account', amount: 0 } // Added Capital Account to liabilities

    // Removed "Last Year Profit" from liabilities
  ];
  totalLiability: number = 0;
// Add these properties to your component class
cashPayments: number = 0;
bankTransferPayments: number = 0;



  // Assets
  assets: BalanceSheetItem[] = [
    { name: 'Customer Due', amount: 0 },
    { name: 'Closing Stock', amount: 0 },
    { name: 'Last Year Profit', amount: 0 }, // Added "Last Year Profit" to assets
    { name: 'Account Balances:', amount: 0 },
    { name: 'Sales: Total Payments', amount: 0 },
     // New entry

  ];
  
  accountBalances: BalanceSheetItem[] = [];
  totalAssets: number = 0;
  isLoading: boolean = true;

  constructor(
    private productService: ProductsService,
    private accountService: AccountService,
    private purchaseService: PurchaseService,
    private saleService: SaleService
  ) {}

  ngOnInit(): void {
    this.loadAccounts();
    this.loadSupplierDue();
    this.loadProductsAndCalculateAssets();
    this.loadCustomerDue();
    this.calculateLastYearProfit(); // Added for profit calculation
    this.loadSalesPayments(); 
  }

  // New method to calculate last year's profit
  calculateLastYearProfit(): void {
    // Get current date and calculate last year's date range
    const currentDate = new Date();
    const lastYearStart = new Date(currentDate.getFullYear() - 1, 0, 1); // Jan 1 of last year
    const lastYearEnd = new Date(currentDate.getFullYear() - 1, 11, 31); // Dec 31 of last year

    // Get sales data for last year
    this.saleService.listenForSales().subscribe({
      next: (salesData: any[]) => {
        const lastYearSales = salesData.filter(sale => {
          const saleDate = sale.saleDate?.toDate ? sale.saleDate.toDate() : new Date(sale.saleDate);
          return saleDate >= lastYearStart && saleDate <= lastYearEnd && sale.status === 'Completed';
        });

        // Calculate total revenue from sales (selling price)
        const totalRevenue = lastYearSales.reduce((sum, sale) => {
          if (sale.products && sale.products.length > 0) {
            const saleRevenue = sale.products.reduce((productSum: number, product: any) => {
              return productSum + ((product.unitPrice || product.price || 0) * (product.quantity || 0));
            }, 0);
            return sum + saleRevenue;
          }
          return sum;
        }, 0);

        // Get purchase data for last year
        this.purchaseService.getPurchases().subscribe({
          next: (purchases: any[]) => {
            const lastYearPurchases = purchases.filter(purchase => {
              const purchaseDate = purchase.purchaseDate?.toDate ? purchase.purchaseDate.toDate() : new Date(purchase.purchaseDate);
              return purchaseDate >= lastYearStart && purchaseDate <= lastYearEnd;
            });

            // Calculate total cost of goods sold (purchase price)
            const totalCost = lastYearPurchases.reduce((sum, purchase) => {
              if (purchase.products && purchase.products.length > 0) {
                const purchaseCost = purchase.products.reduce((productSum: number, product: any) => {
                  return productSum + ((product.unitCost || product.price || 0) * (product.quantity || 0));
                }, 0);
                return sum + purchaseCost;
              }
              return sum;
            }, 0);

            // Calculate profit (Revenue - Cost)
            const lastYearProfit = totalRevenue - totalCost;

            // Update the Last Year Profit value in assets instead of liabilities
            const profitIndex = this.assets.findIndex(item => item.name === 'Last Year Profit');
            if (profitIndex !== -1) {
              this.assets[profitIndex].amount = lastYearProfit;
            }

            // Recalculate totals after profit is updated
            this.calculateTotalAssets();
            this.checkLoadingStatus();
          },
          error: (error) => {
            console.error('Error loading purchases:', error);
            this.checkLoadingStatus();
          }
        });
      },
      error: (error) => {
        console.error('Error loading sales:', error);
        this.checkLoadingStatus();
      }
    });
  }
// Update the loadSalesPayments method

// Update the loadSalesPayments method
// Update the loadSalesPayments method
loadSalesPayments(): void {
  this.saleService.listenForSales().subscribe({
    next: (salesData: any[]) => {
      const completedSales = salesData.filter(sale => sale.status === 'Completed');
      
      let totalPayments = 0;
      let cashTotal = 0;
      let bankTransferTotal = 0;
      
      completedSales.forEach(sale => {
        const paymentAmount = sale.paymentAmount ? Number(sale.paymentAmount) : 0;
        totalPayments += paymentAmount;
        
        if (sale.paymentMethod === 'Cash') {
          cashTotal += paymentAmount;
        } else {
          // All other payment methods (Card, Bank Transfer, Cheque, etc.) go to Bank Transfer
          bankTransferTotal += paymentAmount;
        }
      });
      
      const paymentsIndex = this.assets.findIndex(item => item.name === 'Sales: Total Payments');
      if (paymentsIndex !== -1) {
        this.assets[paymentsIndex].amount = totalPayments;
      }
      
      this.cashPayments = cashTotal;
      this.bankTransferPayments = bankTransferTotal;
      
      this.calculateTotalAssets();
      this.checkLoadingStatus();
    },
    error: (error) => {
      console.error('Error loading sales payments:', error);
      this.checkLoadingStatus();
    }
  });
}
  loadCustomerDue(): void {
    this.saleService.listenForSales().subscribe({
      next: (salesData: any[]) => {
        const completedSales = salesData.filter(sale => sale.status === 'Completed');
        let totalBalance = completedSales.reduce((sum, sale) => 
          sum + (sale.balance ? Number(sale.balance) : 0), 0);
          
        const customerDueIndex = this.assets.findIndex(item => item.name === 'Customer Due');
        if (customerDueIndex !== -1) {
          this.assets[customerDueIndex].amount = -totalBalance;
        }
        
        this.calculateTotalAssets();
      },
      error: (error) => {
        console.error('Error loading customer due:', error);
        this.calculateTotalAssets();
      }
    });
  }

loadAccounts(): void {
  this.accountService.getAccounts((accounts: any[]) => {
    this.accountBalances = [];
    accounts.forEach(account => {
      if (account.name === 'Capital Account') {
        // Add to liabilities instead of accountBalances
        const capitalIndex = this.liabilities.findIndex(item => item.name === 'Capital Account');
        if (capitalIndex !== -1) {
          this.liabilities[capitalIndex].amount = account.openingBalance || 0;
        }
      } else {
        this.accountBalances.push({
          name: account.name,
          amount: account.openingBalance || 0
        });
      }
    });
    this.calculateTotalLiability(); // Make sure to recalculate liabilities
    this.calculateTotalAssets();
  });
}

  loadSupplierDue(): void {
    this.purchaseService.getPurchases().subscribe({
      next: (purchases: any[]) => {
        let totalSupplierDue = 0;
        purchases.forEach(purchase => {
          const paymentDue = Number(purchase.paymentDue) || 0;
          totalSupplierDue += paymentDue;
        });
        
        const supplierDueIndex = this.liabilities.findIndex(item => item.name === 'Supplier Due');
        if (supplierDueIndex !== -1) {
          this.liabilities[supplierDueIndex].amount = totalSupplierDue;
        }
        
        this.calculateTotalLiability();
      },
      error: (error) => {
        console.error('Error loading supplier dues:', error);
        this.calculateTotalLiability();
      }
    });
  }

  calculateTotalLiability(): void {
    this.totalLiability = this.liabilities.reduce((total, item) => total + item.amount, 0);
  }

  calculateTotalAssets(): void {
    const assetsSubtotal = this.assets.reduce((total, item) => {
      if (item.name !== 'Account Balances:') {
        return total + item.amount;
      }
      return total;
    }, 0);
    
    const accountBalancesTotal = this.accountBalances.reduce((total, item) => total + item.amount, 0);
    this.totalAssets = assetsSubtotal + accountBalancesTotal;
    this.checkLoadingStatus();
  }

  loadProductsAndCalculateAssets(): void {
    this.productService.getProductsRealTime().subscribe(
      (products: any[]) => {
        let totalInventoryValue = 0;
        products.forEach(product => {
          const purchasePrice = product.defaultPurchasePriceExcTax || 0;
          const currentStock = product.currentStock || 0;
          totalInventoryValue += purchasePrice * currentStock;
        });
        
        const closingStockIndex = this.assets.findIndex(item => item.name === 'Closing Stock');
        if (closingStockIndex !== -1) {
          this.assets[closingStockIndex].amount = totalInventoryValue;
        }
        
        this.calculateTotalAssets();
        this.checkLoadingStatus();
      },
      (error) => {
        console.error('Error loading products:', error);
        this.checkLoadingStatus();
      }
    );
  }
  get salesTotalPayments(): number {
    const salesItem = this.assets.find(item => item.name === 'Sales: Total Payments');
    return salesItem ? salesItem.amount : 0;
  }
  get showSalesTotalPayments(): boolean {
    return this.assets.some(item => item.name === 'Sales: Total Payments' && item.amount !== undefined);
  }  
  // Update the checkLoadingStatus method to include the new properties
private checkLoadingStatus(): void {
  if (this.assets.find(item => item.name === 'Closing Stock')?.amount !== undefined &&
      this.liabilities.find(item => item.name === 'Supplier Due')?.amount !== undefined &&
      this.assets.find(item => item.name === 'Customer Due')?.amount !== undefined &&
            this.liabilities.find(item => item.name === 'Capital Account')?.amount !== undefined && // Added this check

      this.assets.find(item => item.name === 'Last Year Profit')?.amount !== undefined &&
      this.assets.find(item => item.name === 'Sales: Total Payments')?.amount !== undefined) {
    this.isLoading = false;
  }
}
}