import { Component } from '@angular/core';
import { SaleService } from '../services/sale.service';

@Component({
  selector: 'app-import-shipping',
  templateUrl: './import-shipping.component.html',
  styleUrls: ['./import-shipping.component.scss']
})
export class ImportShippingComponent {
  selectedFile: File | null = null;
  isLoading = false;
  importResult: { success: number; errors: number } | null = null;

  constructor(private saleService: SaleService) {}

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
    this.importResult = null;
  }

  onSubmit(): void {
    if (this.selectedFile) {
      this.isLoading = true;
      
      this.saleService.importShippingData(this.selectedFile).subscribe(
        (result) => {
          this.importResult = result;
          this.isLoading = false;
          this.selectedFile = null;
        },
        (error) => {
          console.error('Import error:', error);
          this.importResult = { success: 0, errors: 1 };
          this.isLoading = false;
        }
      );
    }
  }

  downloadTemplate(): void {
    // CSV template content with all required fields
    const csvContent = `Date,Invoice No.,Customer,Contact Number,Location,Delivery Person,Shipping Status,Shipping Charge,Payment Status
2025-05-01,INV-1001,John Doe,555-1234,123 Main St,New York,NY,10001,Delivery Person 1,Delivered,10.00,Paid
2025-05-02,INV-1002,Jane Smith,555-5678,456 Oak Ave,Chicago,IL,60601,Delivery Person 2,Pending,15.00,Unpaid
2025-05-03,INV-1003,Robert Johnson,555-9012,789 Pine St,Los Angeles,CA,90001,Delivery Person 3,Shipped,12.50,Partial`;
    
    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'shipping_template.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}