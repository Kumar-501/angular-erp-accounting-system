import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../services/payment.service';
import { DatePipe } from '@angular/common';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-payment-history',
  templateUrl: './payment-history.component.html',
  styleUrls: ['./payment-history.component.scss'],
  providers: [DatePipe]
})
export class PaymentHistoryComponent implements OnInit {
  payments: any[] = [];
  supplierName = '';
  purchaseId = '';
  purchaseRef = '';
  supplierId = '';
  isLoading = true;
  errorMessage = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private paymentService: PaymentService,
    private datePipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.supplierName = params['supplierName'] || '';
      this.purchaseId = params['purchaseId'] || '';
      this.supplierId = params['supplierId'] || '';
      this.purchaseRef = params['purchaseRef'] || '';
      
      this.loadPaymentHistory();
    });
  }

  async loadPaymentHistory() {
    this.isLoading = true;
    this.errorMessage = '';
    
    try {
      let result: any[] = [];
      
      if (this.purchaseId) {
        result = await firstValueFrom(
          this.paymentService.getPaymentsByPurchase(this.purchaseId).pipe(
            catchError((error: any) => {
              console.error('Error loading payments by purchase:', error);
              this.errorMessage = error.message || 'Failed to load payments for this purchase';
              return of([]);
            })
          )
        ) || [];
      } else if (this.supplierId) {
        result = await firstValueFrom(
          this.paymentService.getPaymentsBySupplier(this.supplierId).pipe(
            catchError((error: any) => {
              console.error('Error loading payments by supplier:', error);
              this.errorMessage = error.message || 'Failed to load payments for this supplier';
              return of([]);
            })
          )
        ) || [];
      } else {
        this.errorMessage = 'No purchase or supplier specified';
        this.payments = [];
        return;
      }
      
      this.payments = result;
      
      // Sort by date (newest first)
      this.payments = this.payments.sort((a, b) => {
        const dateA = a.paymentDate?.toDate ? a.paymentDate.toDate() : new Date(a.paymentDate);
        const dateB = b.paymentDate?.toDate ? b.paymentDate.toDate() : new Date(b.paymentDate);
        return dateB.getTime() - dateA.getTime();
      });
      
    } catch (error) {
      console.error('Error loading payments:', error);
      this.errorMessage = error instanceof Error ? error.message : 'Failed to load payment history';
      this.payments = [];
    } finally {
      this.isLoading = false;
    }
  }

  formatDate(date: any): string {
    if (!date) return 'N/A';
    try {
      const dateObj = date.toDate ? date.toDate() : new Date(date);
      return this.datePipe.transform(dateObj, 'medium') || 'N/A';
    } catch {
      return 'N/A';
    }
  }

  getTotalPayments(): number {
    return this.payments.reduce((sum, payment) => sum + (payment.amount || 0), 0);
  }

  goBack(): void {
    this.router.navigate(['/list-purchase']);
  }
}