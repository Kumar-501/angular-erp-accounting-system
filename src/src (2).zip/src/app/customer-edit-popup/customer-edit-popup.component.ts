import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-customer-edit-popup',
  templateUrl: './customer-edit-popup.component.html',
  styleUrls: ['./customer-edit-popup.component.scss']
})
export class CustomerEditPopupComponent implements OnChanges {
  @Input() customerData: any;
  @Output() save = new EventEmitter<any>();
  @Output() close = new EventEmitter<void>();

  show = true;
  isSaving = false;
  sameAsBilling = false;
  showCopySuccessMsg = false;

  constructor(private customerService: CustomerService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['customerData'] && this.customerData) {
      // Initialize isIndividual if not set
      if (this.customerData.isIndividual === undefined) {
        this.customerData.isIndividual = !this.customerData.businessName;
      }
      
      // Initialize addresses if not set
      if (!this.customerData.billingAddress) {
        this.customerData.billingAddress = this.customerData.addressLine1 || '';
      }
      if (!this.customerData.shippingAddress) {
        this.customerData.shippingAddress = this.customerData.addressLine1 || '';
      }
      
      // Check if addresses are same
      this.sameAsBilling = this.customerData.billingAddress === this.customerData.shippingAddress;
      
      // Update display name whenever other name fields change
      this.updateDisplayName();
    }
  }

  updateDisplayName(): void {
    if (this.customerData.isIndividual) {
      // For individuals: "FirstName LastName"
      const names = [
        this.customerData.firstName,
        this.customerData.middleName,
        this.customerData.lastName
      ].filter(name => name && name.trim());
      
      this.customerData.displayName = names.join(' ');
    } else {
      // For businesses: use business name
      this.customerData.displayName = this.customerData.businessName;
    }
  }

  onSameAsBillingChange(): void {
    if (this.sameAsBilling) {
      this.customerData.shippingAddress = this.customerData.billingAddress;
    }
  }

  async onSave(): Promise<void> {
    this.isSaving = true;
    try {
      // Ensure display name is updated before saving
      this.updateDisplayName();
      
      // Preserve the address data from the form
      const updatedCustomer = {
        ...this.customerData,
        // Keep the address fields as they were edited
        billingAddress: this.customerData.billingAddress,
        shippingAddress: this.customerData.shippingAddress,
        // Update addressLine1 only if it's empty or if billing address was changed
        addressLine1: this.customerData.addressLine1 || this.customerData.billingAddress,
        updatedAt: new Date()
      };
      
      // Emit the updated customer data to parent
      this.save.emit(updatedCustomer);
      this.show = false;
    } catch (error) {
      console.error('Error in customer edit popup:', error);
      alert('Failed to save customer changes. Please try again.');
    } finally {
      this.isSaving = false;
    }
  }

  onClose(): void {
    this.close.emit();
  }
}