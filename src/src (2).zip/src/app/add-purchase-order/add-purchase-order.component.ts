import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PurchaseOrderService } from '../services/purchase-order.service';
import { SupplierService } from '../services/supplier.service';
import { LocationService } from '../services/location.service';
import { ProductsService } from '../services/products.service';
import { UserService } from '../services/user.service';

interface Supplier {
  id?: string;
  contactId?: string;
  businessName?: string;
  firstName?: string;
  lastName?: string;
  isIndividual?: boolean;
  address: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  zipCode?: string; // Add this line
}
interface Product {
  id: string;
  productName: string;
  sku?: string;
  purchasePrice?: number;
  sellingPrice?: number;
  defaultPurchasePrice?: number;
  currentStock?: number;
 
  
  barcode?: string;
  productDescription?: string;
}

@Component({
  selector: 'app-add-purchase-order',
  templateUrl: './add-purchase-order.component.html',
  styleUrls: ['./add-purchase-order.component.scss']
})
export class AddPurchaseOrderComponent implements OnInit {
  purchaseOrderForm!: FormGroup;
  suppliers: Supplier[] = [];
  businessLocations: any[] = [];
  productsList: Product[] = [];
  filteredProducts: Product[] = [];
  searchResults: Product[] = []; // Added for search results
  showSearchResults: boolean = false; // Control visibility of search results
  searchTerm: string = ''; // Track search term
  totalItems: number = 0;
  netTotalAmount: number = 0;
  users: any[] = [];
  selectedSupplierDetails: any = null;
  private searchTimeout: any; // or more specifically: private searchTimeout: ReturnType<typeof setTimeout> | null = null;


  selectedProductIndex: number = -1;


  constructor(
    private fb: FormBuilder,
    private orderService: PurchaseOrderService,
    private supplierService: SupplierService,
    private locationService: LocationService,
    private productsService: ProductsService,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadSuppliers();
    this.loadBusinessLocations();
    this.loadProducts();
    this.generateReferenceNumber();
    this.loadUsers();
    
  }

  initForm(): void {
    this.purchaseOrderForm = this.fb.group({
      supplier: ['', Validators.required],
      address: [''],
      referenceNo: [{ value: '', disabled: true }, Validators.required],
      orderDate: [new Date().toISOString().split('T')[0], Validators.required],
      deliveryDate: [''],
      shippingDate: [''],
      purchaseOrder: ['', Validators.required], // Added Purchase Order field

      requiredDate: [''],
      addedBy: [''],
      businessLocation: ['', Validators.required],
      payTerm: [''],
      products: this.fb.array([]),
      shippingDetails: this.fb.group({
        shippingDetails: [''],
        shippingAddress: [''],
        shippingCharges: [0],
        shippingStatus: [''],
        deliveredTo: [''],
        shippingDocuments: [null]
      }),
      attachDocument: [null],
      additionalNotes: ['']
    });
    
    // Initialize with one empty product
    this.addEmptyProduct();
  }

  loadProducts(): void {
    this.productsService.getProductsRealTime().subscribe({
      next: (products: any[]) => {
        this.productsList = products.map(product => ({
          ...product,
          defaultPurchasePrice: product.purchasePrice || product.sellingPrice || 100,
          currentStock: product.currentStock || 0
        }));
        this.filteredProducts = [...this.productsList];
      },
      error: (err) => {
        console.error('Error loading products:', err);
      }
    });
  }

  loadUsers(): void {
    this.userService.getUsers().subscribe(users => {
      this.users = users;
    });
  }

  loadBusinessLocations(): void {
    this.locationService.getLocations().subscribe(
      (locations) => {
        this.businessLocations = locations;
      },
      (error) => {
        console.error('Error loading business locations:', error);
      }
    );
  }
generateReferenceNumber(): void {
  // Generate a 6-digit random number between 100000 and 999999 with "PR" prefix
  const refNumber = 'PR' + Math.floor(100000 + Math.random() * 900000).toString();
  this.purchaseOrderForm.get('referenceNo')?.setValue(refNumber);
} loadSuppliers(): void {
    this.supplierService.getSuppliers().subscribe((suppliers: Supplier[]) => {
      this.suppliers = suppliers;
    });
  }

  getSupplierDisplayName(supplier: Supplier): string {
    if (supplier.isIndividual) {
      return `${supplier.firstName || ''} ${supplier.lastName || ''}`.trim();
    }
    return supplier.businessName || '';
  }
onSupplierChange(): void {
  const supplierId = this.purchaseOrderForm.get('supplier')?.value;
  if (supplierId) {
    this.supplierService.getSupplierById(supplierId).subscribe({
      next: (supplier: Supplier | undefined) => {
        if (supplier) {
          this.selectedSupplierDetails = supplier;
          const addressParts = [
            supplier.address,
            supplier.addressLine1,
            supplier.addressLine2,
            supplier.city,
            supplier.state,
            'postalCode' in supplier ? supplier.postalCode : supplier.zipCode,
            supplier.country
          ].filter(part => !!part);
          
          this.purchaseOrderForm.patchValue({
            address: addressParts.join(', ')
          });
        }
      },
      error: (err) => {
        console.error('Error loading supplier:', err);
      }
    });
  }
}

  get productsFormArray() {
    return this.purchaseOrderForm.get('products') as FormArray;
  }

  addEmptyProduct() {
    this.productsFormArray.push(
      this.fb.group({
        productId: ['', Validators.required],
        productName: [''],
        quantity: [1, [Validators.required, Validators.min(1)]],
        unitCost: [0, [Validators.required, Validators.min(0)]],
        discountPercent: [0, [Validators.min(0), Validators.max(100)]],
        unitCostBeforeTax: [0],
        lineTotal: [0],
        profitMargin: [0],
        sellingPrice: [0],
        currentStock: [0],
        selected: [false]
      })
    );
    this.updateTotals();
  }

 
  removeProduct(index: number) {
    this.productsFormArray.removeAt(index);
    this.updateTotals();
  }
  get orderItemsFormArray() {
    return this.purchaseOrderForm.get('orderItems') as FormArray;
  }


  onProductSelect(index: number) {
    const productFormGroup = this.productsFormArray.at(index);
    const productId = productFormGroup.get('productId')?.value;
    
    if (productId) {
      const selectedProduct = this.productsList.find(p => p.id === productId);
      if (selectedProduct) {
        productFormGroup.patchValue({
          productName: selectedProduct.productName,
          unitCost: selectedProduct.defaultPurchasePrice || 100,
          currentStock: selectedProduct.currentStock || 0,
          profitMargin: 0,
          sellingPrice: 0
        });
        
        this.calculateLineTotal(index);
      }
    }
  }

  calculateLineTotal(index: number) {
    const productFormGroup = this.productsFormArray.at(index);
    const quantity = parseFloat(productFormGroup.get('quantity')?.value) || 0;
    const unitCost = parseFloat(productFormGroup.get('unitCost')?.value) || 0;
    const discountPercent = parseFloat(productFormGroup.get('discountPercent')?.value) || 0;

    const discountAmount = (unitCost * discountPercent) / 100;
    const unitCostAfterDiscount = unitCost - discountAmount;
    productFormGroup.get('unitCostBeforeTax')?.setValue(unitCostAfterDiscount.toFixed(2));

    const lineTotal = quantity * unitCostAfterDiscount;
    productFormGroup.get('lineTotal')?.setValue(lineTotal.toFixed(2));

    this.calculateSellingPrice(index);
    this.updateTotals();
  }

  calculateSellingPrice(index: number) {
    const productFormGroup = this.productsFormArray.at(index);
    const unitCostBeforeTax = parseFloat(productFormGroup.get('unitCostBeforeTax')?.value) || 0;
    const profitMargin = parseFloat(productFormGroup.get('profitMargin')?.value) || 0;

    const profitAmount = (unitCostBeforeTax * profitMargin) / 100;
    const sellingPrice = unitCostBeforeTax + profitAmount;
    
    productFormGroup.get('sellingPrice')?.setValue(sellingPrice.toFixed(2));
  }

  updateTotals() {
    this.totalItems = this.productsFormArray.length;
    
    this.netTotalAmount = this.productsFormArray.controls.reduce((total, control) => {
      return total + (parseFloat(control.get('lineTotal')?.value) || 0);
    }, 0);
  }

  onFileChange(event: any, fieldName: string) {
    const file = event.target.files[0];
    if (file && file.size <= 5 * 1024 * 1024) {
      const allowedExtensions = ['.pdf', '.csv', '.zip', '.doc', '.docx', '.jpeg', '.jpg', '.png'];
      const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
      
      if (allowedExtensions.includes(fileExtension)) {
        if (fieldName === 'shippingDocuments') {
          this.purchaseOrderForm.get('shippingDetails')?.get('shippingDocuments')?.setValue(file);
        } else {
          this.purchaseOrderForm.get(fieldName)?.setValue(file);
        }
      } else {
        alert('Invalid file type!');
      }
    } else {
      alert('File size exceeds 5MB!');
    }
  }

// Update the searchProducts function in your component
// Update the searchProducts function in your component
searchProducts(event: any) {
  const searchTerm = event.target.value.toLowerCase().trim();
  this.searchTerm = searchTerm;
  
  if (!searchTerm || searchTerm.length < 2) {
    this.searchResults = [];
    this.showSearchResults = false;
    return;
  }
  
  this.searchResults = this.productsList.filter(product => {
    // Create a search string containing all relevant fields
    const searchString = [
      product.productName,
      product.sku,
    
    ]
    .filter(field => field) // Remove null/undefined
    .join(' ') // Combine into one string
    .toLowerCase();
    
    return searchString.includes(searchTerm);
  });
  
  this.showSearchResults = this.searchResults.length > 0;
}
onSearchFocus() {
  this.showSearchResults = true;
  // You might want to trigger an initial search here if needed
}
onSearchInput(event: any): void {
  // Clear the previous timeout
  if (this.searchTimeout) {
    clearTimeout(this.searchTimeout);
  }
  
  // Set a new timeout to avoid excessive filtering
  this.searchTimeout = setTimeout(() => {
    this.searchProducts(event);
  }, 300); // 300ms debounce time
}

onSearchBlur() {
  // Add a small delay to allow click events to process
  setTimeout(() => {
    this.showSearchResults = false;
  }, 200);
}
// Add debounce to prevent excessive searching
private debounceTimer: any;
debounceSearch(searchTerm: string) {
  clearTimeout(this.debounceTimer);
  this.debounceTimer = setTimeout(() => {
    this.performSearch(searchTerm);
  }, 300);
}

performSearch(searchTerm: string) {
  this.searchResults = this.productsList.filter(product => {
    if (!product) return false;
    
    // Check in multiple fields with exact matches first
    const exactMatch = 
      product.productName?.toLowerCase() === searchTerm ||
      product.sku?.toLowerCase() === searchTerm ||
      product.barcode?.toLowerCase() === searchTerm;
    
    if (exactMatch) return true;
    
    // Then check for partial matches
    return (
      product.productName?.toLowerCase().includes(searchTerm) ||
      product.sku?.toLowerCase().includes(searchTerm) ||
      product.barcode?.toLowerCase().includes(searchTerm) ||
      (product.productDescription?.toLowerCase().includes(searchTerm))
    );
  }).slice(0, 50); // Limit results for performance
  
  this.showSearchResults = true;
}
// Highlight matching text in results
highlightMatch(text: string, searchTerm: string): string {
  if (!text || !searchTerm) return text;
  
  const regex = new RegExp(searchTerm, 'gi');
  return text.replace(regex, match => 
    `<span class="highlight">${match}</span>`
  );
}


// Add keyboard navigation
// Keyboard navigation
handleKeyDown(event: KeyboardEvent) {
  if (!this.showSearchResults) return;
  
  const results = document.querySelectorAll('.search-results-dropdown .list-group-item');
  
  if (event.key === 'ArrowDown') {
    event.preventDefault();
    const currentIndex = Array.from(results).findIndex(el => el === document.activeElement);
    if (currentIndex < results.length - 1) {
      (results[currentIndex + 1] as HTMLElement)?.focus();
    }
  } else if (event.key === 'ArrowUp') {
    event.preventDefault();
    const currentIndex = Array.from(results).findIndex(el => el === document.activeElement);
    if (currentIndex > 0) {
      (results[currentIndex - 1] as HTMLElement)?.focus();
    } else {
      (event.target as HTMLElement)?.focus();
    }
  } else if (event.key === 'Enter') {
    const activeElement = document.activeElement;
    if (activeElement?.classList.contains('list-group-item')) {
      const index = Array.from(results).findIndex(el => el === activeElement);
      if (index >= 0) {
        this.addProductFromSearch(this.searchResults[index]);
      }
    }
  }
}

addProductFromSearch(product: Product) {
  // Check if product already exists in the form
  const existingIndex = this.productsFormArray.controls.findIndex(
    control => control.get('productId')?.value === product.id
  );
  
  if (existingIndex >= 0) {
    // Increment quantity if product exists
    const currentQty = this.productsFormArray.at(existingIndex).get('quantity')?.value || 0;
    this.productsFormArray.at(existingIndex).get('quantity')?.setValue(currentQty + 1);
    this.calculateLineTotal(existingIndex);
  } else {
    // Add new product
    const productFormGroup = this.fb.group({
      productId: [product.id, Validators.required],
      productName: [product.productName],
      quantity: [1, [Validators.required, Validators.min(1)]],
      unitCost: [product.defaultPurchasePrice || 0, [Validators.required, Validators.min(0)]],
      discountPercent: [0, [Validators.min(0), Validators.max(100)]],
      unitCostBeforeTax: [product.defaultPurchasePrice || 0],
      lineTotal: [product.defaultPurchasePrice || 0],
      profitMargin: [0],
      sellingPrice: [product.sellingPrice || 0],
      currentStock: [product.currentStock || 0],
      selected: [false]
    });
    
    this.productsFormArray.push(productFormGroup);
    this.calculateLineTotal(this.productsFormArray.length - 1);
  }
  
  this.updateTotals();
  this.clearSearch();
}


clearSearch() {
  this.searchTerm = '';
  this.searchResults = [];
  this.showSearchResults = false;
}

hideSearchResults() {
  setTimeout(() => {
    this.showSearchResults = false;
  }, 200);
}

  selectAllProducts(event: any) {
    const isChecked = event.target.checked;
    this.productsFormArray.controls.forEach(control => {
      control.get('selected')?.setValue(isChecked);
    });
  }

  toggleProductSelection(index: number) {
    const control = this.productsFormArray.at(index);
    const currentValue = control.get('selected')?.value || false;
    control.get('selected')?.setValue(!currentValue);
  }

  deleteSelectedProducts() {
    if (confirm('Are you sure you want to delete selected products?')) {
      for (let i = this.productsFormArray.length - 1; i >= 0; i--) {
        if (this.productsFormArray.at(i).get('selected')?.value) {
          this.productsFormArray.removeAt(i);
        }
      }
      this.updateTotals();
    }
  }

  addAdditionalExpenses() {
    alert('This feature will be implemented soon!');
  }

  async saveOrder() {
    // Check form validity
    if (this.purchaseOrderForm.invalid) {
      this.markFormGroupTouched(this.purchaseOrderForm);
      alert('Please fill all required fields correctly.');
      return;
    }
  
    if (this.productsFormArray.length === 0) {
      alert('Please add at least one product.');
      return;
    }
  
    try {
      // Enable referenceNo for submission
      this.purchaseOrderForm.get('referenceNo')?.enable();
  
      // Prepare form data
      const formData = this.purchaseOrderForm.value;
      
      // Add additional metadata
      formData.createdAt = new Date().toISOString();
      formData.status = 'pending'; // Add status field
      formData.supplierName = this.getSupplierDisplayName(this.selectedSupplierDetails);
      
      // Process products array
      formData.products = formData.products.map((product: any) => ({
        ...product,
        productName: this.productsList.find(p => p.id === product.productId)?.productName || '',
        currentStock: this.productsList.find(p => p.id === product.productId)?.currentStock || 0
      }));
  
      // Calculate totals
      formData.totalItems = this.totalItems;
      formData.netTotalAmount = this.netTotalAmount;
  
      // Save to Firestore
      await this.orderService.addOrder(formData);
      
      // Success handling
      alert('Purchase Order Saved Successfully!');
      this.router.navigate(['/purchase-order']);
    } catch (error) {
      console.error('Error saving order:', error);
      alert(`Error saving purchase order: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      this.purchaseOrderForm.get('referenceNo')?.disable();
    }
  }
  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
  
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
  
}