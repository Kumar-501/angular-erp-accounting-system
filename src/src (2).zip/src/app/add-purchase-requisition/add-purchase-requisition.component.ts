import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PurchaseRequisitionService } from '../services/purchase-requisition.service';
import { BrandsService, Brand } from '../services/brands.service';
import { CategoriesService } from '../services/categories.service';
import { LocationService } from '../services/location.service';
import { ProductsService } from '../services/products.service';
import { UserService } from '../services/user.service';
import { SupplierService } from '../services/supplier.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-purchase-requisition',
  templateUrl: './add-purchase-requisition.component.html',
  styleUrls: ['./add-purchase-requisition.component.scss']
})
export class AddPurchaseRequisitionComponent implements OnInit, OnDestroy {
  purchaseForm!: FormGroup;
  brands: Brand[] = [];
  categories: any[] = [];
  businessLocations: any[] = [];
  productsList: any[] = [];
  users: any[] = [];
  suppliers: any[] = [];
  filteredProducts: any[] = [];
  private locationsSubscription: Subscription | undefined;
  private usersSubscription: Subscription | undefined;
  private suppliersSubscription: Subscription | undefined;

  constructor(
    private fb: FormBuilder,
    private requisitionService: PurchaseRequisitionService,
    private brandsService: BrandsService,
    private categoriesService: CategoriesService,
    private locationService: LocationService,
    private productsService: ProductsService,
    private userService: UserService,
    private supplierService: SupplierService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.loadData();
    this.addProduct();
    this.generateReferenceNumber();
  }

  ngOnDestroy(): void {
    if (this.locationsSubscription) {
      this.locationsSubscription.unsubscribe();
    }
    if (this.usersSubscription) {
      this.usersSubscription.unsubscribe();
    }
    if (this.suppliersSubscription) {
      this.suppliersSubscription.unsubscribe();
    }
  }

  initializeForm(): void {
    const today = new Date().toISOString().split('T')[0];
    
    this.purchaseForm = this.fb.group({
      brand: ['', Validators.required],
      category: ['', Validators.required],
      location: ['', Validators.required],
      locationName: [''],
      referenceNo: ['', Validators.required],
      requiredByDate: ['', Validators.required],
      date: [today, Validators.required],
      addedBy: ['', Validators.required],
      status: ['pending', Validators.required],
      shippingStatus: ['not_shipped'],
      supplier: [''],
      shippingDate: [''],
      products: this.fb.array([])
    });
    
    this.purchaseForm.get('location')?.valueChanges.subscribe((locationId) => {
      if (locationId && this.businessLocations.length > 0) {
        const selectedLocation = this.businessLocations.find(loc => loc.id === locationId);
        if (selectedLocation) {
          this.purchaseForm.get('locationName')?.setValue(selectedLocation.name);
        }
      }
    });
  }

  async loadData(): Promise<void> {
    try {
      this.brandsService.brands$.subscribe(brands => {
        this.brands = brands;
      });

      this.categoriesService.categories$.subscribe(categories => {
        this.categories = categories;
      });

      this.locationsSubscription = this.locationService.getLocations().subscribe(locations => {
        if (locations && locations.length > 0) {
          this.businessLocations = locations;
          console.log('Business Locations loaded:', this.businessLocations);
          
          const locationId = this.purchaseForm.get('location')?.value;
          if (locationId) {
            const selectedLocation = this.businessLocations.find(loc => loc.id === locationId);
            if (selectedLocation) {
              this.purchaseForm.get('locationName')?.setValue(selectedLocation.name);
            }
          }
        } else {
          console.log('No business locations found');
          this.businessLocations = [];
        }
      });

      this.productsService.getProductsRealTime().subscribe(products => {
        this.productsList = products;
        this.filteredProducts = products;
      });

      this.usersSubscription = this.userService.getUsers().subscribe(users => {
        this.users = users;
      });

      this.suppliersSubscription = this.supplierService.getSuppliers().subscribe(suppliers => {
        this.suppliers = suppliers;
      });
      
    } catch (error) {
      console.error('Error loading data:', error);
    }
  }

async generateReferenceNumber(): Promise<void> {
  try {
    const latestRequisition = await this.requisitionService.getLatestRequisition();
    
    let nextPrNumber = 1;
    if (latestRequisition) {
      const match = latestRequisition.referenceNo.match(/PR-(\d+)/);
      if (match) {
        nextPrNumber = parseInt(match[1], 10) + 1;
      }
    }

    const formattedPrNumber = `PR-${nextPrNumber.toString().padStart(3, '0')} 001`;
    
    this.purchaseForm.patchValue({
      referenceNo: formattedPrNumber
    });
    
    console.log('Generated reference number:', formattedPrNumber);
  } catch (error) {
    console.error('Error generating reference number:', error);
    const fallbackRef = `PR-001 001`;
    this.purchaseForm.patchValue({
      referenceNo: fallbackRef
    });
  }
}


  get products() {
    return this.purchaseForm.get('products') as FormArray;
  }

 addProduct(): void {
  this.products.push(
    this.fb.group({
      productId: ['', Validators.required],
      productName: ['', Validators.required],
      alertQuantity: ['', [Validators.required, Validators.min(0)]],
      currentStock: ['', [Validators.required, Validators.min(0)]],
      requiredQuantity: ['', [Validators.required, Validators.min(1)]]
    })
  );
}

  removeProduct(index: number): void {
    this.products.removeAt(index);
  }

onProductSelect(index: number): void {
  const selectedProductId = this.products.at(index).get('productId')?.value;
  const selectedProduct = this.productsList.find(p => p.id === selectedProductId);
  
  if (selectedProduct) {
    this.products.at(index).patchValue({
      productName: selectedProduct.productName,
      alertQuantity: selectedProduct.alertQuantity || 0,
      currentStock: selectedProduct.currentStock || 0
    });
  }
}

  

async savePurchase(): Promise<void> {
  if (this.purchaseForm.invalid) {
    alert('Please fill all required fields!');
    return;
  }

  try {
    const formData = this.purchaseForm.getRawValue();
    
    // Generate item numbers (001, 002, etc.) for each product
    formData.items = formData.products.map((product: any, index: number) => {
      // Split the reference number to get the PR part
      const refParts = formData.referenceNo.split(' ');
      const prNumber = refParts[0];
      const itemNumber = (index + 1).toString().padStart(3, '0');
      
      return {
        productId: product.productId,
        productName: product.productName,
        requiredQuantity: product.requiredQuantity,
        alertQuantity: product.alertQuantity,
        currentStock: product.currentStock,
        itemReference: `${prNumber} ${itemNumber}` // Add item reference
      };
    });
    
    delete formData.products;

    await this.requisitionService.addRequisition(formData);
    alert('Purchase Requisition Added Successfully!');
    this.router.navigate(['/purchase-requisition']);
  } catch (error) {
    console.error('Error adding requisition:', error);
    alert('Failed to add purchase requisition. Please try again.');
  }
}
}