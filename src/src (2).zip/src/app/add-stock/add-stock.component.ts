import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators, FormControl, ValidatorFn, AbstractControl } from '@angular/forms';
import { StockService } from '../services/stock.service';
import { Router } from '@angular/router';
import { ProductsService } from '../services/products.service';
import { LocationService } from '../services/location.service';

@Component({
  selector: 'app-add-stock',
  templateUrl: './add-stock.component.html',
  styleUrls: ['./add-stock.component.scss']
})
export class AddStockComponent implements OnInit {
  stockForm: FormGroup;
  grandTotal: number = 0;
  isSubmitting: boolean = false;
  submitError: string | null = null;
  allProducts: any[] = [];
  allLocations: any[] = []; 
  stockValidationErrors: { [key: number]: string | null } = {};

  constructor(
    private fb: FormBuilder,
    private stockService: StockService,
    private router: Router,
    private productService: ProductsService,
    private locationService: LocationService
  ) {
    this.stockForm = this.fb.group({
      date: ['', Validators.required],
      referenceNo: [{ value: this.generateReferenceNumber(), disabled: true }],
      status: ['pending', Validators.required],
      additionalNotes: [''],
      locationTransfers: this.fb.array([this.createLocationTransfer()], this.atLeastOneTransferValidator())
    });
  }

  ngOnInit(): void {
    // Load products and locations
    this.loadProducts();
    this.loadLocations();
  }

  get locationTransfers(): FormArray {
    return this.stockForm.get('locationTransfers') as FormArray;
  }

  createLocationTransfer(): FormGroup {
    return this.fb.group({
      locationFrom: ['', Validators.required],
      locationTo: ['', Validators.required],
      shippingCharges: [0, [Validators.min(0)]],
      products: this.fb.array([this.createProduct()], this.atLeastOneProductValidator())
    });
  }

  addLocationTransfer(): void {
    this.locationTransfers.push(this.createLocationTransfer());
    this.calculateTotal();
  }

  removeLocationTransfer(index: number): void {
    this.locationTransfers.removeAt(index);
    this.calculateTotal();
  }

  getProductsArray(transfer: AbstractControl): FormArray {
    return transfer.get('products') as FormArray;
  }

  createProduct(): FormGroup {
    return this.fb.group({
      product: ['', Validators.required],
      quantity: [0, [Validators.required, Validators.min(1)]],
      unitPrice: [0, [Validators.required, Validators.min(0.01)]],
      subtotal: [0]
    });
  }

  addProduct(transferIndex: number): void {
    const transfer = this.locationTransfers.at(transferIndex);
    const productsArray = this.getProductsArray(transfer);
    productsArray.push(this.createProduct());
    this.stockForm.updateValueAndValidity();
  }

  removeProduct(transferIndex: number, productIndex: number): void {
    const transfer = this.locationTransfers.at(transferIndex);
    const productsArray = this.getProductsArray(transfer);
    productsArray.removeAt(productIndex);
    this.calculateTotal();
    this.stockForm.updateValueAndValidity();
  }

  calculateSubtotal(transferIndex: number, productIndex: number): void {
    const transfer = this.locationTransfers.at(transferIndex);
    const productsArray = this.getProductsArray(transfer);
    const productGroup = productsArray.at(productIndex) as FormGroup;
    
    const quantity = productGroup.get('quantity')?.value || 0;
    const unitPrice = productGroup.get('unitPrice')?.value || 0;
    const subtotal = quantity * unitPrice;

    productGroup.patchValue({ subtotal });
    this.calculateTotal();
  }

  getSubtotal(transferIndex: number, productIndex: number): number {
    const transfer = this.locationTransfers.at(transferIndex);
    const productsArray = this.getProductsArray(transfer);
    const productGroup = productsArray.at(productIndex) as FormGroup;
    return productGroup.get('subtotal')?.value || 0;
  }

  getTransferSubtotal(transferIndex: number): number {
    const transfer = this.locationTransfers.at(transferIndex);
    const productsArray = this.getProductsArray(transfer);
    return productsArray.controls.reduce((sum, productGroup) => {
      return sum + (productGroup.get('subtotal')?.value || 0);
    }, 0);
  }

  getTransferTotal(transferIndex: number): number {
    const transfer = this.locationTransfers.at(transferIndex);
    const subtotal = this.getTransferSubtotal(transferIndex);
    const shipping = transfer.get('shippingCharges')?.value || 0;
    return subtotal + shipping;
  }

  calculateTotal(): void {
    this.grandTotal = this.locationTransfers.controls.reduce((sum, transfer) => {
      return sum + this.getTransferTotal(this.locationTransfers.controls.indexOf(transfer));
    }, 0);
  }

  getFilteredFromLocations(transferIndex: number): any[] {
    const currentToLocation = this.locationTransfers.at(transferIndex).get('locationTo')?.value;
    return this.allLocations.filter(location => 
      location.id !== currentToLocation && 
      !this.isLocationUsedInOtherTransfers(location.id, 'locationTo', transferIndex)
    );
  }

  getFilteredToLocations(transferIndex: number): any[] {
    const currentFromLocation = this.locationTransfers.at(transferIndex).get('locationFrom')?.value;
    return this.allLocations.filter(location => 
      location.id !== currentFromLocation && 
      !this.isLocationUsedInOtherTransfers(location.id, 'locationFrom', transferIndex)
    );
  }

  isLocationUsedInOtherTransfers(locationId: string, field: 'locationFrom' | 'locationTo', excludeIndex: number): boolean {
    for (let i = 0; i < this.locationTransfers.length; i++) {
      if (i !== excludeIndex) {
        const transfer = this.locationTransfers.at(i);
        if (transfer.get(field)?.value === locationId) {
          return true;
        }
      }
    }
    return false;
  }

  loadLocations(): void {
    this.locationService.getLocations().subscribe({
      next: (locations: any[]) => {
        this.allLocations = locations.filter(location => location.active);
      },
      error: (error) => {
        console.error('Error loading locations:', error);
      }
    });
  }

  loadProducts(): void {
    this.productService.getProductsRealTime().subscribe({
      next: (products: any[]) => {
        this.allProducts = products;
      },
      error: (error) => {
        console.error('Error loading products:', error);
      }
    });
  }

  generateReferenceNumber(): string {
    const date = new Date();
    const year = date.getFullYear().toString().substr(-2);
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    const random = Math.floor(Math.random() * 9000) + 1000;
    
    return `REF-${year}${month}${day}-${random}`;
  }

  private atLeastOneTransferValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
      const transfersArray = control as FormArray;
      if (!transfersArray || !transfersArray.controls) {
        return { noValidTransfers: true };
      }

      const hasValidTransfers = transfersArray.controls.some(transferGroup => {
        if (!(transferGroup instanceof FormGroup)) return false;
        
        const locationFrom = transferGroup.get('locationFrom')?.value;
        const locationTo = transferGroup.get('locationTo')?.value;
        const products = transferGroup.get('products') as FormArray;
        
        return locationFrom && locationTo && products && products.valid;
      });

      return hasValidTransfers ? null : { noValidTransfers: true };
    };
  }

  private atLeastOneProductValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
      const productsArray = control as FormArray;
      if (!productsArray || !productsArray.controls) {
        return { noValidProducts: true };
      }

      const hasValidProducts = productsArray.controls.some(productGroup => {
        if (!(productGroup instanceof FormGroup)) return false;
        
        const product = productGroup.get('product')?.value;
        const quantity = productGroup.get('quantity')?.value;
        const unitPrice = productGroup.get('unitPrice')?.value;
        return product && quantity > 0 && unitPrice > 0;
      });

      return hasValidProducts ? null : { noValidProducts: true };
    };
  }

  async validateStockQuantities(): Promise<boolean> {
    this.stockValidationErrors = {};
    let isValid = true;

    for (let i = 0; i < this.locationTransfers.length; i++) {
      const transfer = this.locationTransfers.at(i);
      const productsArray = this.getProductsArray(transfer);
      const locationFrom = transfer.get('locationFrom')?.value;

      for (let j = 0; j < productsArray.length; j++) {
        const productGroup = productsArray.at(j) as FormGroup;
        const productId = productGroup.get('product')?.value;
        const requestedQuantity = productGroup.get('quantity')?.value || 0;
        
        if (productId && requestedQuantity > 0) {
          const product = await this.productService.getProductById(productId);
          
          if (product) {
            const currentStock = product.currentStock || 0;
            
            if (requestedQuantity > currentStock) {
              const productName = product.productName || 'Product';
              this.stockValidationErrors[i] = `Insufficient stock for ${productName}. Available: ${currentStock}, Requested: ${requestedQuantity}`;
              isValid = false;
              break;
            }
          }
        }
      }
      
      if (!isValid) break;
    }
    
    return isValid;
  }

  onProductSelect(transferIndex: number, productIndex: number): void {
    const transfer = this.locationTransfers.at(transferIndex);
    const productsArray = this.getProductsArray(transfer);
    const selectedProductId = productsArray.at(productIndex).get('product')?.value;
    const selectedProduct = this.allProducts.find(p => p.id === selectedProductId);
    
    if (selectedProduct) {
      productsArray.at(productIndex).patchValue({
        unitPrice: selectedProduct.defaultPurchasePriceExcTax || 0
      });
      this.calculateSubtotal(transferIndex, productIndex);
    }
  }

  async onSubmit(): Promise<void> {
    if (this.stockForm.invalid) {
      this.markAllAsTouched();
      return;
    }

    // Validate stock quantities before submitting
    const isStockValid = await this.validateStockQuantities();
  if (!isStockValid) {
    return;
  }


  this.isSubmitting = true;
  this.submitError = null;


  const formValue = this.stockForm.getRawValue();
  const transfersData = {
    ...formValue,
    locationTransfers: formValue.locationTransfers.map((transfer: any) => ({
      ...transfer,
      subtotal: this.getTransferSubtotal(formValue.locationTransfers.indexOf(transfer)),
      totalAmount: this.getTransferTotal(formValue.locationTransfers.indexOf(transfer)),
      products: transfer.products.map((product: any) => ({
        ...product,
        subtotal: product.quantity * product.unitPrice
      }))
    })),
    grandTotal: this.grandTotal,
    date: new Date(formValue.date).toISOString()
  };

  this.stockService.addStock(transfersData)
    .then(() => {
      this.router.navigate(['/list-stock']);
    })
    .catch(error => {
      console.error('Error adding stock:', error);
      this.submitError = 'Failed to save stock. Please try again.';
    })
    .finally(() => {
      this.isSubmitting = false;
    });
}

  private markAllAsTouched(): void {
    Object.values(this.stockForm.controls).forEach(control => {
      if (control instanceof FormControl) {
        control.markAsTouched();
      } else if (control instanceof FormArray) {
        control.controls.forEach(group => {
          if (group instanceof FormGroup) {
            Object.values(group.controls).forEach(c => {
              if (c instanceof FormControl) {
                c.markAsTouched();
              } else if (c instanceof FormArray) {
                c.controls.forEach(productGroup => {
                  if (productGroup instanceof FormGroup) {
                    Object.values(productGroup.controls).forEach(pc => pc.markAsTouched());
                  }
                });
              }
            });
          }
        });
      }
    });
  }

  getProductCurrentStock(productId: string): number {
    if (!productId) return 0;
    
    const selectedProduct = this.allProducts.find(p => p.id === productId);
    return selectedProduct ? (selectedProduct.currentStock || 0) : 0;
  }
}