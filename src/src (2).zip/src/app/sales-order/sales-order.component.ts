import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { SaleService } from '../services/sale.service';
import { Observable, BehaviorSubject, combineLatest } from 'rxjs';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LocationService } from '../services/location.service';
import { TypeOfServiceService } from '../services/type-of-service.service';

interface Product {
  name: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  subtotal: number;
  quantityRemaining?: number;
}
interface BusinessLocation {
  id: string;
  name: string;
}
interface SalesOrder {
  id: string;
  customer: string;
  customerPhone: string;

  businessLocation: string;
  location: string;
  billingAddress: string;
    transactionId?: string;
  prescriptions?: Prescription[]; // Add this line


  saleDate: string;
  invoiceNo: string;
  orderNo: string;
  status: string;
  serviceType: string;
  typeOfService: string;
  typeOfServiceName: string;
  shippingStatus: string;
  shippingCharges: number;
  discountType: string;
  discountAmount: number;
  orderTax: number;
  paymentAmount: number;
  paymentMethod: string;
  paidOn: string;
  balance: number;
  changeReturn: number;
  quantityRemaining: number;
  addedBy?: string;
  addedByDisplayName?: string;
  shippingAddress: string;
  sellNote: string;
  paymentNote: string;
  deliveryPerson: string;
  products: Product[];
}


interface Prescription {
  id?: string;
  patientName: string;
  date: string;
  medicines: Medicine[];
  doctorName?: string;

  createdAt?: Date;
  saleId?: string; // Add this to link prescriptions to sales
}

interface Medicine {
  name: string;
  type: string;
  dosage?: string;
  instructions?: string;
  time: string;
  // ... other medicine fields ...
}
// Create a partial type for the raw sale data coming from the service
interface PartialSalesOrder {
  id?: string;
  customer?: string;
  customerPhone?: string;
  businessLocation?: string;
  location?: string;
  saleDate?: string;
  invoiceNo?: string;
  orderNo?: string;
  status?: string;
  serviceType?: string;
  typeOfService?: string;
  typeOfServiceName?: string;
  shippingStatus?: string;
  shippingCharges?: number;
  discountType?: string;
  discountAmount?: number;
  orderTax?: number;
  paymentAmount?: number;
  paymentMethod?: string;
  paidOn?: string;
  balance?: number;
  changeReturn?: number;
  quantityRemaining?: number;
  addedBy?: string;
  addedByDisplayName?: string;
  billingAddress?: string;
  shippingAddress?: string;
  sellNote?: string;
  paymentNote?: string;
  deliveryPerson?: string;
  products?: Array<Partial<Product>>;
  product?: Array<Partial<Product>>;
  transactionId?: string;
  prescriptions?: Prescription[]; // Add this line
}

interface FilterOptions {
  businessLocation: string;
  customer: string;
  status: string;
  shippingStatus: string;
  serviceType: string; // Add this
  dateRange: {
    startDate: string;
    endDate: string;
  };
}
interface BusinessLocation {
  id: string;
  name: string;
}

interface Customer {
  id: string;
  displayName: string;
  contactId?: string;
}

@Component({
  selector: 'app-sales-order',
  templateUrl: './sales-order.component.html',
  styleUrls: ['./sales-order.component.scss']
})
export class SalesOrderComponent implements OnInit {
  
  // Original sales data from service
  private allSalesData$ = new BehaviorSubject<SalesOrder[]>([]);
  private modal: any;
  // Add search control for instant filtering
  searchControl = new FormControl('');
  selectedSale: SalesOrder | null = null;
  viewSaleModal: any;

  viewSale(sale: SalesOrder, event?: Event): void {
    if (event) {
      event.stopPropagation();
      event.preventDefault();
    }
    
    this.selectedSale = sale;
    this.viewSaleModal?.show();
  }

  // Filtered sales that will be displayed
  sales$!: Observable<SalesOrder[]>;
  sortedSales$!: Observable<SalesOrder[]>;
  displayedSales: SalesOrder[] = [];
  businessLocations: BusinessLocation[] = [];


  // Sorting properties
  sortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  columns = [
    { key: 'actions', label: 'Actions', visible: true },
    { key: 'sno', label: 'S.No', visible: true },
    { key: 'customer', label: 'Customer Name', visible: true },
    { key: 'product', label: 'Product', visible: true },
    { key: 'customerPhone', label: 'Contact Number', visible: true },
    { key: 'location', label: 'Location', visible: true },
    { key: 'shippingAddress', label: 'Shipping Address', visible: true },
    { key: 'paymentMethod', label: 'Payment Method', visible: true },
    { key: 'saleDate', label: 'Sale Date', visible: true },
    { key: 'orderNo', label: 'Order No', visible: true },
    { key: 'typeOfService', label: 'Type of Service', visible: true },
    { key: 'status', label: 'Status', visible: true },
    { key: 'shippingStatus', label: 'Shipping Status', visible: true },
    { key: 'addedBy', label: 'Added By', visible: true },
    { key: 'billingAddress', label: 'Billing Address', visible: true },
      { key: 'transactionId', label: 'Transaction ID', visible: true },


  ];
  showFilters = false;
  Math = Math;
  filterOptions: FilterOptions = {
    businessLocation: '',
    customer: '',
    status: '',
    serviceType: '', // Add this

    shippingStatus: '',
    dateRange: {
      startDate: '',
      endDate: ''
    }
    
  };
  
  currentPage = 1;
  pageSize = 25;
  expandedSaleId: string | null = null;
  
  serviceTypes: any[] = [];

  customers: Customer[] = [
    { id: 'CC0001', displayName: 'Walk-In Customer', contactId: 'CC0001' }
  ];

  constructor(private saleService: SaleService, private router: Router,private modalService: NgbModal,  private locationService: LocationService,
    private typeOfServiceService: TypeOfServiceService) {
    
  }

  ngOnInit(): void {
    // Load data first
    this.loadSalesData();
    this.loadBusinessLocations();
    this.loadCustomers();
    this.loadBusinessLocations();
    this.loadServiceTypes();
    
    // Set up the search filter after data is loaded
    this.setupSearchFilter();
  }
  isColumnVisible(columnKey: string): boolean {
    const column = this.columns.find(c => c.key === columnKey);
    return column ? column.visible : true;
  }
  
  toggleColumnVisibility(columnKey: string): void {
    const column = this.columns.find(c => c.key === columnKey);
    if (column) {
      column.visible = !column.visible;
    }
  }
  setupSearchFilter(): void {
    // Create an observable from the search control with debounce
    const search$ = this.searchControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      distinctUntilChanged()
    );
    
    // Combine the search term with the sales data to filter results
    this.sales$ = combineLatest([
      this.allSalesData$,
      search$
    ]).pipe(
      map(([sales, searchTerm]) => {
        if (!searchTerm || typeof searchTerm !== 'string' || searchTerm.trim() === '') {
          return sales;
        }
        
        const term = searchTerm.toLowerCase().trim();
        
        return sales.filter(sale => {
          // Check customer name
          const customerMatch = this.safeIncludes(sale.customer, term);
          
          // Check customer phone
          const phoneMatch = this.safeIncludes(sale.customerPhone, term);
          
          // Check order number
          const orderMatch = this.safeIncludes(sale.orderNo, term);
          
          // Check invoice number
          const invoiceMatch = this.safeIncludes(sale.invoiceNo, term);
          
          // Check location
          const locationMatch = 
            this.safeIncludes(sale.location, term) || 
            this.safeIncludes(sale.businessLocation, term);
          
          // Check status
          const statusMatch = this.safeIncludes(sale.status, term);
          
          // Check shipping status
          const shippingStatusMatch = this.safeIncludes(sale.shippingStatus, term);
          
          // Check service type
          const serviceMatch = 
            this.safeIncludes(sale.typeOfService, term) || 
            this.safeIncludes(sale.typeOfServiceName, term);
          
          // Check added by
          const addedByMatch = 
            this.safeIncludes(sale.addedBy, term) || 
            this.safeIncludes(sale.addedByDisplayName, term);
          
          // Check shipping address
          const shippingAddressMatch = this.safeIncludes(sale.shippingAddress, term);
          
          // Check payment method
          const paymentMethodMatch = this.safeIncludes(sale.paymentMethod, term);
          
          // Check product names
          let productMatch = false;
          if (sale.products && sale.products.length > 0) {
            productMatch = sale.products.some(product => 
              this.safeIncludes(product.name, term)
            );
          }
          
          // Return true if any field matches
          return customerMatch || phoneMatch || orderMatch || invoiceMatch || 
                 locationMatch || statusMatch || shippingStatusMatch || 
                 serviceMatch || addedByMatch || shippingAddressMatch || 
                 paymentMethodMatch || productMatch;
        });
      })
    );

    // Add sorting to the filtered sales
    this.sortedSales$ = this.sales$.pipe(
      map(sales => {
        if (!this.sortColumn) {
          return sales;
        }

        return this.sortSalesData([...sales], this.sortColumn, this.sortDirection);
      })
    );
  }
  loadBusinessLocations(): void {
    this.locationService.getLocations().subscribe({
      next: (locations) => {
        this.businessLocations = locations.map(loc => ({
          id: loc.id,
          name: loc.name || 'Unnamed Location'
        }));
      },
      error: (err) => console.error('Error loading locations:', err)
    });
  }

  // Helper method to safely check if a string includes a search term
  safeIncludes(value: any, searchTerm: string): boolean {
    if (value === null || value === undefined) {
      return false;
    }
    
    // Convert to string if it's not already
    const strValue = String(value).toLowerCase();
    return strValue.includes(searchTerm);
  }
  
  // Toggle filter sidebar
  toggleFilters(): void {
    this.showFilters = !this.showFilters;
  }

  // Sort data when column header is clicked
  sortData(column: string): void {
    if (this.sortColumn === column) {
      // Toggle direction if same column is clicked
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and default to ascending
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    // Re-apply the sort to the observable
    this.sortedSales$ = this.sales$.pipe(
      map(sales => this.sortSalesData([...sales], this.sortColumn, this.sortDirection))
    );
  }

  // Function to sort sales data
  private sortSalesData(sales: SalesOrder[], column: string, direction: 'asc' | 'desc'): SalesOrder[] {
    return sales.sort((a, b) => {
      let valueA: any = a[column as keyof SalesOrder];
      let valueB: any = b[column as keyof SalesOrder];
      
      // Handle special case for date comparisons
      if (column === 'saleDate') {
        valueA = new Date(valueA).getTime();
        valueB = new Date(valueB).getTime();
      } 
      // Handle string comparisons (case-insensitive)
      else if (typeof valueA === 'string' && typeof valueB === 'string') {
        valueA = valueA.toLowerCase();
        valueB = valueB.toLowerCase();
      }

      const filters: any = {};


      if (this.filterOptions.businessLocation) {
        filters.businessLocation = this.filterOptions.businessLocation;
      }
  
      
      // Compare the values
      if (valueA < valueB) {
        return direction === 'asc' ? -1 : 1;
      }
      if (valueA > valueB) {
        return direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }

  loadSalesData(): void {
    // Create filter parameters
    const filters: any = {};
    
    if (this.filterOptions.businessLocation) {
      filters.businessLocation = this.filterOptions.businessLocation;
    }
    
    if (this.filterOptions.customer) {
      filters.customer = this.filterOptions.customer;
    }
    
    if (this.filterOptions.status) {
      filters.status = this.filterOptions.status;
    }
    
    if (this.filterOptions.shippingStatus) {
      filters.shippingStatus = this.filterOptions.shippingStatus;
    }
    
    if (this.filterOptions.serviceType) {
      filters.serviceType = this.filterOptions.serviceType;
    }
    
    if (this.filterOptions.dateRange.startDate && this.filterOptions.dateRange.endDate) {
      filters.startDate = this.filterOptions.dateRange.startDate;
      filters.endDate = this.filterOptions.dateRange.endDate;
    }

    this.saleService.listenForSales(filters).subscribe(
      (salesFromService: PartialSalesOrder[]) => {
        const salesWithProducts = salesFromService.map((sale: PartialSalesOrder) => {
          const productItems = Array.isArray(sale.products) ? sale.products : 
                              Array.isArray(sale.product) ? sale.product : [];
                              
               
                              
          return {

          prescriptions: sale.prescriptions || [], // This is now valid

            id: sale.id || '',
            customer: sale.customer || 'Unknown Customer',
            customerPhone: sale.customerPhone || '',
            
            businessLocation: sale.businessLocation || '',
            location: sale.location || sale.businessLocation || '',
            saleDate: sale.saleDate || new Date().toISOString(),
            invoiceNo: sale.invoiceNo || '',
          transactionId: sale.transactionId || '',

            orderNo: sale.orderNo || `SO-${new Date().getTime().toString().slice(-6)}`,
            status: sale.status || 'Pending',
            serviceType: sale.serviceType || sale.typeOfService || 'Standard',
            typeOfService: sale.typeOfServiceName || sale.typeOfService || '',
            typeOfServiceName: sale.typeOfServiceName || sale.typeOfService || '',
            shippingStatus: sale.shippingStatus || 'Pending',
            shippingCharges: sale.shippingCharges || 0,
            discountType: sale.discountType || 'Percentage',
            discountAmount: sale.discountAmount || 0,
            orderTax: sale.orderTax || 0,
            paymentAmount: sale.paymentAmount || 0,
            paymentMethod: sale.paymentMethod || '',
            paidOn: sale.paidOn || '',
            balance: sale.balance || 0,
            changeReturn: sale.changeReturn || 0,
            quantityRemaining: sale.quantityRemaining || 0,
            addedBy: sale.addedBy || 'System',
            addedByDisplayName: sale.addedByDisplayName || sale.addedBy || 'System',
            billingAddress: sale.billingAddress || '',
            shippingAddress: sale.shippingAddress || '',
            sellNote: sale.sellNote || '',
            paymentNote: sale.paymentNote || '',
            deliveryPerson: sale.deliveryPerson || '',
            products: productItems.map(product => ({
              name: product.name || '',
              quantity: product.quantity || 0,
              unitPrice: product.unitPrice || 0,
              discount: product.discount || 0,
              subtotal: product.subtotal || 0,
              quantityRemaining: product.quantityRemaining || 0
            }))
          };
        });
        
        this.allSalesData$.next(salesWithProducts);
      },
      (error: any) => console.error('Error loading sales data:', error)
    );
  }

    
  loadServiceTypes(): void {
    this.typeOfServiceService.getServicesRealtime().subscribe({
      next: (services) => {
        this.serviceTypes = services.map(service => ({
          id: service.id,
          name: service.name
        }));
      },
      error: (err) => console.error('Error loading service types:', err)
    });
  }
    
  loadCustomers(): void {
    // In a real application, you would fetch this from a service
    // For now, we'll use the static data defined above
  }
      calculateSubtotal(products: any[]): number {
    return products.reduce((sum, product) => sum + (product.unitPrice * product.quantity), 0);
  }

  // Apply filters and reload data
  applyFilters(): void {
    this.currentPage = 1;
    this.loadSalesData();
    this.showFilters = false; // Close sidebar after applying
  }
    
  resetFilters(): void {
    this.filterOptions = {
      businessLocation: '',
      customer: '',
      status: '',
      shippingStatus: '',
      serviceType: '', // Add this
      dateRange: {
        startDate: '',
        endDate: ''
      }
    };
    this.applyFilters();
  }

  changePageSize(size: number): void {
    this.pageSize = size;
    this.currentPage = 1;
  }
    
  nextPage(): void {
    this.currentPage++;
  }
    
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
    
  exportData(format: 'csv' | 'excel' | 'pdf'): void {
    this.saleService.exportSales(format, this.filterOptions)
      .catch(error => console.error('Export failed:', error));
  }
  printData(): void {
    // First close any open filters/sidebar
    this.showFilters = false;
    
    // Wait for the UI to update before printing
    setTimeout(() => {
      // You might want to add specific print styling
      const printStyle = `
        <style>
          @media print {
            body * {
              visibility: hidden;
            }
            .card, .card * {
              visibility: visible;
            }
            .card {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              border: none;
              box-shadow: none;
            }
            .table {
              width: 100% !important;
            }
            .no-print {
              display: none !important;
            }
          }
        </style>
      `;
      
      // Open print window
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Sales Order Report</title>
              ${printStyle}
            </head>
            <body>
              <h3>Sales Order Report</h3>
              ${document.querySelector('.card')?.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        
        // Delay printing to ensure content is loaded
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      } else {
        // Fallback to regular print if popup is blocked
        window.print();
      }
    }, 100);
  }


  editSale(saleId: string): void {
    this.router.navigate(['/sales-order/edit', saleId]);
  }
    
// In your SalesOrderComponent class
deleteSale(id: string, event?: Event): void {
  if (event) {
    event.stopPropagation();
  }
  
  if (confirm('Are you sure you want to delete this sale?')) {
    this.saleService.deleteSale(id)
      .then(() => {
        // Show success message
        console.log('Sale deleted successfully');
        // Optionally reload data or remove from local array
        this.loadSalesData();
      })
      .catch(error => {
        console.error('Delete failed:', error);
        // Show error message to user
        alert('Failed to delete sale: ' + error.message);
      });
  }
}
viewPrescription(sale: SalesOrder, event?: Event): void {
  if (event) {
    event.stopPropagation();
    event.preventDefault();
  }
  
  if (!sale.prescriptions || sale.prescriptions.length === 0) {
    // Try to load prescriptions if not already loaded
    this.saleService.getPrescriptionsBySaleId(sale.id).subscribe({
      next: (prescriptions) => {
        if (prescriptions.length > 0) {
          this.viewPrescriptionDetails(prescriptions[0]);
        } else {
          alert('No prescriptions found for this sale');
        }
      },
      error: (err) => {
        console.error('Error loading prescriptions:', err);
        alert('Error loading prescriptions');
      }
    });
  } else {
    this.viewPrescriptionDetails(sale.prescriptions[0]);
  }
}

private viewPrescriptionDetails(prescription: Prescription): void {
  const printContent = this.generatePrescriptionContent(prescription);
  const viewWindow = window.open('', '_blank');
  if (viewWindow) {
    viewWindow.document.write(printContent);
    viewWindow.document.close();
  }
}



private getMedicineTypeName(type: string): string {
  const typeNames: {[key: string]: string} = {
    'kasayam': 'Kasayam (കഷായം)',
    'buligha': 'Buligha (ഗുളിക)',
    'bhasmam': 'Bhasmam (ഭസ്മം)',
    'krudham': 'Krudham (ഘൃതം)',
    'suranam': 'Suranam (ചൂർണ്ണം)',
    'rasayanam': 'Rasayanam (രസായനം)',
    'lagium': 'Lagium (ലേഹ്യം)'
  };
  return typeNames[type] || 'Medicine';
}



private generatePrescriptionContent(prescription: any): string {
  // Generate HTML content for the prescription
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Prescription</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; }
        .header { text-align: center; margin-bottom: 20px; }
        .patient-info { margin-bottom: 20px; }
        .medicine-item { margin-bottom: 15px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>Prescription</h2>
      </div>
      
      <div class="patient-info">
        <p><strong>Patient:</strong> ${prescription.patientName || 'N/A'}</p>
        <p><strong>Date:</strong> ${prescription.date || 'N/A'}</p>
      </div>
      
      <div class="prescription-items">
        ${prescription.medicines.map((med: any, i: number) => `
          <div class="medicine-item">
            <h4>${i + 1}. ${this.getMedicineTypeName(med.type)}</h4>
            ${this.generateMedicineDetails(med)}
          </div>
        `).join('')}
      </div>
      
      ${prescription.additionalNotes ? `
        <div class="additional-notes">
          <h4>Additional Notes:</h4>
          <p>${prescription.additionalNotes}</p>
        </div>
      ` : ''}
    </body>
    </html>
  `;
}



private generateMedicineDetails(medicine: any): string {
  switch(medicine.type) {
    case 'kasayam':
      return `
        <p>${medicine.name || '______'} കഷായം എടുത്ത് തിളപ്പിച്ചാറ്റിയവെള്ളം ചേർത്ത് ${medicine.instructions || '______'}</p>
        <p>ഗുളിക ${medicine.pills || '______'} പൊടി ചേർത്ത് ${medicine.powder || '______'}</p>
        <p>നേരം: ${medicine.time || 'രാവിലെ / ഉച്ചയ്ക്ക് / രാത്രി'} ഭക്ഷണത്തിനുമുൻപ് / ശേഷം സേവിക്കുക.</p>
      `;
    // ... other medicine types ...
    default:
      return `
        <p>${medicine.name || '______'}</p>
        <p>Dosage: ${medicine.dosage || '______'}</p>
        <p>Time: ${medicine.time || '______'}</p>
      `;
  }
}
  toggleProductDetails(saleId: string): void {
    if (this.expandedSaleId === saleId) {
      this.expandedSaleId = null;
    } else {
      this.expandedSaleId = saleId;
    }
  }

  getProductsDisplayText(products: Product[]): string {
    if (!products || products.length === 0) return 'No products';
    
    if (products.length === 1) {
      return `${products[0].name} (${products[0].quantity})`;
    } else {
      return `${products[0].name} (${products[0].quantity}) and ${products.length - 1} more`;
    }
  }
}