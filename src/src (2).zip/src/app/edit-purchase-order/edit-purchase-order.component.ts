import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { PurchaseOrderService } from '../services/purchase-order.service';
import { SupplierService } from '../services/supplier.service';
import { LocationService } from '../services/location.service';
import { ProductsService } from '../services/products.service';
import { UserService } from '../services/user.service';

interface Supplier {
  id?: string;
  contactId?: string;
  businessName?: string;
  firstName?: string;
  lastName?: string;
  isIndividual?: boolean;
}

interface Product {
  id: string;
  productName: string;
  purchasePrice?: number;
  sellingPrice?: number;
  defaultPurchasePrice?: number;
}

@Component({
  selector: 'app-edit-purchase-order',
  templateUrl: './edit-purchase-order.component.html',
  styleUrls: ['./edit-purchase-order.component.scss']
})
export class EditPurchaseOrderComponent implements OnInit {
  purchaseOrderForm!: FormGroup;
  suppliers: Supplier[] = [];
  businessLocations: any[] = [];
  productsList: Product[] = [];
  users: any[] = [];
  orderId: string = '';
  isLoading: boolean = true;
  totalItems: number = 0;
  netTotalAmount: number = 0;

  constructor(
    private fb: FormBuilder,
    private orderService: PurchaseOrderService,
    private supplierService: SupplierService,
    private locationService: LocationService,
    private productsService: ProductsService,
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadSuppliers();
    this.loadBusinessLocations();
    this.loadProducts();
    this.loadUsers();
    
    // Get the order ID from route params
    this.route.params.subscribe(params => {
      this.orderId = params['id'];
      if (this.orderId) {
        this.loadOrderDetails(this.orderId);
      } else {
        this.isLoading = false;
        this.addProduct(); // Add at least one empty product row
      }
    });
  }

  initForm(): void {
    this.purchaseOrderForm = this.fb.group({
      supplier: ['', Validators.required],
      address: [''],
      referenceNo: [{ value: '', disabled: true }, Validators.required],
      orderDate: ['', Validators.required],
      deliveryDate: [''],
      requiredDate: ['', Validators.required],
      addedBy: ['', Validators.required],
      businessLocation: ['', Validators.required],
      payTerm: [''],
      status: ['Pending'],
      products: this.fb.array([]),
      shippingDetails: this.fb.group({
        shippingAddress: [''],
        shippingCharges: [0],
        shippingStatus: [''],
        deliveredTo: [''],
        shippingDocuments: [null]
      }),
      attachDocument: [null],
      additionalNotes: ['']
    });
  }

  loadUsers(): void {
    this.userService.getUsers().subscribe(users => {
      this.users = users;
    });
  }

  loadProducts(): void {
    this.productsService.getProductsRealTime().subscribe({
      next: (products: any[]) => {
        this.productsList = products.map(product => ({
          ...product,
          // Use purchasePrice if available, otherwise use sellingPrice or set a default
          defaultPurchasePrice: product.purchasePrice || product.sellingPrice || 100 // Default to 100 if no price
        }));
        console.log('Loaded products:', this.productsList); // Debug log
      },
      error: (err) => {
        console.error('Error loading products:', err);
      }
    });
  }

  async loadOrderDetails(orderId: string): Promise<void> {
    this.isLoading = true;
    try {
      const orderData = await this.orderService.getOrderById(orderId);
      
      if (orderData) {
        // Clear existing products
        while (this.productsFormArray.length) {
          this.productsFormArray.removeAt(0);
        }
        
        // Populate the form with order data
        this.purchaseOrderForm.patchValue({
          supplier: orderData.supplier,
          address: orderData.address || '',
          referenceNo: orderData.referenceNo,
          orderDate: this.formatDateForInput(orderData.date),
          // Fix: Change property names to match PurchaseOrder interface
          deliveryDate: orderData.expectedDeliveryDate ? this.formatDateForInput(orderData.expectedDeliveryDate) : '',
          requiredDate: orderData.requiredByDate ? this.formatDateForInput(orderData.requiredByDate) : '',
          addedBy: orderData.addedBy || '',
          businessLocation: orderData.businessLocation,
          payTerm: orderData.payTerm || '',
          status: orderData.status || 'Pending',
          additionalNotes: orderData.additionalNotes || ''
        });
        
        // Populate shipping details if they exist
        if (orderData.shippingDetails) {
          this.purchaseOrderForm.get('shippingDetails')?.patchValue({
            shippingAddress: orderData.shippingDetails.shippingAddress || '',
            shippingCharges: orderData.shippingDetails.shippingCharges || 0,
            shippingStatus: orderData.shippingDetails.shippingStatus || '',
            deliveredTo: orderData.shippingDetails.deliveredTo || ''
          });
        }
        
        // Add products if they exist
        if (orderData.products && orderData.products.length > 0) {
          orderData.products.forEach((product: any) => {
            this.productsFormArray.push(
              this.fb.group({
                productId: [product.productId, Validators.required],
                quantity: [product.quantity, [Validators.required, Validators.min(1)]],
                unitCost: [product.unitCost, [Validators.required, Validators.min(0)]],
                discountPercent: [product.discountPercent || 0, [Validators.min(0), Validators.max(100)]],
                unitCostBeforeTax: [product.unitCostBeforeTax || 0],
                lineTotal: [product.lineTotal || 0],
                profitMargin: [product.profitMargin || 0],
                sellingPrice: [product.sellingPrice || 0],
                lotNumber: [product.lotNumber || '']
              })
            );
          });
          this.updateTotals();
        } else {
          // Add at least one empty product
          this.addProduct();
        }
      } else {
        alert('Purchase order not found!');
        this.router.navigate(['/purchase-order']);
      }
    } catch (error) {
      console.error('Error loading order details:', error);
      alert('Error loading purchase order details');
      this.router.navigate(['/purchase-order']);
    } finally {
      this.isLoading = false;
    }
  }

  formatDateForInput(dateString: string | Date): string {
    if (!dateString) return '';
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toISOString().split('T')[0];
  }

  loadBusinessLocations(): void {
    this.locationService.getLocations().subscribe(
      (locations) => {
        this.businessLocations = locations;
      },
      (error: any) => {
        console.error('Error loading business locations:', error);
      }
    );
  }

  loadSuppliers(): void {
    this.supplierService.getSuppliers().subscribe((suppliers: Supplier[]) => {
      this.suppliers = suppliers;
    });
  }

  getSupplierDisplayName(supplier: Supplier): string {
    if (supplier?.isIndividual) {
      return `${supplier.firstName || ''} ${supplier.lastName || ''}`.trim();
    }
    return supplier?.businessName || '';
  }

  get productsFormArray() {
    return this.purchaseOrderForm.get('products') as FormArray;
  }

  addProduct() {
    this.productsFormArray.push(
      this.fb.group({
        productId: ['', Validators.required],
        quantity: [1, [Validators.required, Validators.min(1)]],
        unitCost: [0, [Validators.required, Validators.min(0)]],
        discountPercent: [0, [Validators.min(0), Validators.max(100)]],
        unitCostBeforeTax: [0],
        lineTotal: [0],
        profitMargin: [0],
        sellingPrice: [0],
        lotNumber: ['']
      })
    );
    this.updateTotals();
  }

  removeProduct(index: number) {
    this.productsFormArray.removeAt(index);
    this.updateTotals();
  }

  onProductSelect(index: number) {
    const productFormGroup = this.productsFormArray.at(index);
    const productId = productFormGroup.get('productId')?.value;
    
    if (productId) {
      const selectedProduct = this.productsList.find(p => p.id === productId);
      if (selectedProduct) {
        console.log('Selected product:', selectedProduct); // Debug log
        
        // Use defaultPurchasePrice which we set in loadProducts()
        const unitPrice = selectedProduct.defaultPurchasePrice || 100; // Fallback to 100 if still 0
        
        productFormGroup.patchValue({
          unitCost: unitPrice,
          profitMargin: 0,
          sellingPrice: 0
        });
        
        this.calculateLineTotal(index);
      }
    }
  }

  calculateLineTotal(index: number) {
    const productFormGroup = this.productsFormArray.at(index);
    const quantity = parseFloat(productFormGroup.get('quantity')?.value) || 0;
    const unitCost = parseFloat(productFormGroup.get('unitCost')?.value) || 0;
    const discountPercent = parseFloat(productFormGroup.get('discountPercent')?.value) || 0;

    // Calculate unitCostBeforeTax (after discount)
    const discountAmount = (unitCost * discountPercent) / 100;
    const unitCostAfterDiscount = unitCost - discountAmount;
    productFormGroup.get('unitCostBeforeTax')?.setValue(unitCostAfterDiscount.toFixed(2));

    // Calculate line total
    const lineTotal = quantity * unitCostAfterDiscount;
    productFormGroup.get('lineTotal')?.setValue(lineTotal.toFixed(2));

    this.calculateSellingPrice(index);
    this.updateTotals();
  }

  calculateSellingPrice(index: number) {
    const productFormGroup = this.productsFormArray.at(index);
    const unitCostBeforeTax = parseFloat(productFormGroup.get('unitCostBeforeTax')?.value) || 0;
    const profitMargin = parseFloat(productFormGroup.get('profitMargin')?.value) || 0;

    const profitAmount = (unitCostBeforeTax * profitMargin) / 100;
    const sellingPrice = unitCostBeforeTax + profitAmount;
    
    productFormGroup.get('sellingPrice')?.setValue(sellingPrice.toFixed(2));
  }

  updateTotals() {
    this.totalItems = this.productsFormArray.length;
    
    this.netTotalAmount = this.productsFormArray.controls.reduce((total, control) => {
      return total + (parseFloat(control.get('lineTotal')?.value) || 0);
    }, 0);
  }

  onFileChange(event: any, fieldName: string) {
    const file = event.target.files[0];
    if (file && file.size <= 5 * 1024 * 1024) {
      const allowedExtensions = ['.pdf', '.csv', '.zip', '.doc', '.docx', '.jpeg', '.jpg', '.png'];
      const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
      
      if (allowedExtensions.includes(fileExtension)) {
        if (fieldName === 'shippingDocuments') {
          this.purchaseOrderForm.get('shippingDetails')?.get('shippingDocuments')?.setValue(file);
        } else {
          this.purchaseOrderForm.get(fieldName)?.setValue(file);
        }
      } else {
        alert('Invalid file type!');
      }
    } else {
      alert('File size exceeds 5MB!');
    }
  }

  async updateOrder() {
    if (this.purchaseOrderForm.valid && this.productsFormArray.length > 0) {
      this.purchaseOrderForm.get('referenceNo')?.enable();
      
      const formData = this.purchaseOrderForm.value;
      
      try {
        // Create a purchase order object with the form data
        const updatedOrder = {
          id: this.orderId,
          supplier: formData.supplier,
          address: formData.address,
          referenceNo: formData.referenceNo,
          date: formData.orderDate,
          // Fix: Map form field names to match PurchaseOrder interface
          expectedDeliveryDate: formData.deliveryDate,
          requiredByDate: formData.requiredDate,
          addedBy: formData.addedBy,
          businessLocation: formData.businessLocation,
          payTerm: formData.payTerm,
          status: formData.status,
          products: formData.products,
          shippingDetails: formData.shippingDetails,
          additionalNotes: formData.additionalNotes,
          attachDocument: formData.attachDocument,
          updatedAt: new Date()
        };
        
        // Now use the updateOrder method from the service
        await this.orderService.updateOrder(this.orderId, updatedOrder);
        
        alert('Purchase Order Updated Successfully!');
        this.router.navigate(['/purchase-order']);
      } catch (error: any) {
        console.error('Error updating order:', error);
        alert('Error updating purchase order: ' + error.message);
      } finally {
        this.purchaseOrderForm.get('referenceNo')?.disable();
      }
    } else {
      alert('Please fill all required fields and add at least one product.');
    }
  }

  cancelEdit() {
    this.router.navigate(['/purchase-order']);
  }
}