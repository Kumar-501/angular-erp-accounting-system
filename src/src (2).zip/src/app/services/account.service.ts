import { Injectable } from '@angular/core';
import { 
  Firestore, 
  collection, 
  doc, 
  getDoc, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  DocumentSnapshot,
  DocumentData,
  getDocs,
  or
} from '@angular/fire/firestore';
import { Observable, from } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  constructor(private firestore: Firestore) {}

  // Income Type Constants
  private readonly INCOME_TYPES = {
    DIRECT: 'Direct Income',
    INDIRECT: 'Indirect Income'
  };

  // Get all income types
  getIncomeTypes(): string[] {
    return Object.values(this.INCOME_TYPES);
  }

  // Get accounts by income type
  getAccountsByIncomeType(incomeType: string, callback: (accounts: any[]) => void): void {
    const accountsRef = collection(this.firestore, 'accounts');
    const q = query(accountsRef, where('incomeType', '==', incomeType));
    
    onSnapshot(q, (snapshot) => {
      const accounts = snapshot.docs.map(doc => {
        return { id: doc.id, ...doc.data() };
      });
      callback(accounts);
    });
  }

  // In account.service.ts
getAccounts(callback: (accounts: any[]) => void): void {
  const accountsRef = collection(this.firestore, 'accounts');
  onSnapshot(accountsRef, (snapshot) => {
    const accounts = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    callback(accounts);
  });
}
  
  // Get a single account by ID (enhanced to return proper Observable)
  getAccountById(id: string): Observable<any> {
    const accountDocRef = doc(this.firestore, 'accounts', id);
    
    return from(getDoc(accountDocRef)).pipe(
      map((docSnap: DocumentSnapshot<DocumentData>) => {
        if (docSnap.exists()) {
          return { id: docSnap.id, ...docSnap.data() };
        } else {
          console.error('Account not found');
          return null;
        }
      })
    );
  }

  // Get transactions for a specific account with realtime updates
  getTransactionsForAccount(accountId: string, callback: (transactions: any[]) => void): void {
    const transactionsRef = collection(this.firestore, 'transactions');
    const q = query(transactionsRef, where('accountId', '==', accountId));
    
    onSnapshot(q, (snapshot) => {
      const transactions = snapshot.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          date: data['date']?.toDate() // Convert Firestore Timestamp to Date
        };
      });
      callback(transactions);
    });
  }

  // Get fund transfers for a specific account (both incoming and outgoing)
  getFundTransfersForAccount(accountId: string, callback: (transfers: any[]) => void): void {
    const transfersRef = collection(this.firestore, 'fundTransfers');
    const q = query(transfersRef, 
      or(
        where('fromAccountId', '==', accountId),
        where('toAccountId', '==', accountId)
      )
    );
    
    onSnapshot(q, (snapshot) => {
      const transfers = snapshot.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          date: data['date']?.toDate() // Convert Firestore Timestamp to Date
        };
      });
      callback(transfers);
    });
  }

  // Get all transactions (including transfers) for an account
  getAllAccountTransactions(accountId: string, callback: (transactions: any[]) => void): void {
    let allTransactions: any[] = [];
    
    // First get regular transactions
    this.getTransactionsForAccount(accountId, (transactions) => {
      allTransactions = [...transactions];
      
      // Then get fund transfers
      this.getFundTransfersForAccount(accountId, (transfers) => {
        // Convert transfers to transaction format
        const transferTransactions = transfers.map(transfer => {
          if (transfer.fromAccountId === accountId) {
            // Outgoing transfer
            return {
              id: transfer.id,
              accountId: accountId,
              date: transfer.date,
              description: `Fund Transfer (To: ${transfer.toAccountName || 'Unknown Account'})`,
              paymentMethod: 'Fund Transfer',
              paymentDetails: '',
              note: transfer.note || '',
              addedBy: transfer.addedBy || 'System',
              debit: transfer.amount || 0,
              credit: 0,
              type: 'transfer_out',
              hasDocument: !!transfer.attachmentUrl,
              attachmentUrl: transfer.attachmentUrl,
              fromAccountId: transfer.fromAccountId,
              toAccountId: transfer.toAccountId
            };
          } else {
            // Incoming transfer
            return {
              id: transfer.id,
              accountId: accountId,
              date: transfer.date,
              description: `Fund Transfer (From: ${transfer.fromAccountName || 'Unknown Account'})`,
              paymentMethod: 'Fund Transfer',
              paymentDetails: '',
              note: transfer.note || '',
              addedBy: transfer.addedBy || 'System',
              debit: 0,
              credit: transfer.amount || 0,
              type: 'transfer_in',
              hasDocument: !!transfer.attachmentUrl,
              attachmentUrl: transfer.attachmentUrl,
              fromAccountId: transfer.fromAccountId,
              toAccountId: transfer.toAccountId
            };
          }
        });
        
        // Combine and sort by date (newest first)
        const combined = [...allTransactions, ...transferTransactions]
          .sort((a, b) => b.date.getTime() - a.date.getTime());
        
        callback(combined);
      });
    });
  }

  // Listen to transactions with filters (maintained for backward compatibility)
  listenToTransactions(
    callback: (transactions: any[]) => void, 
    fromDate?: string,
    toDate?: string,
    transactionType?: string
  ): void {
    const transactionsRef = collection(this.firestore, 'transactions');
    let q = query(transactionsRef);
    
    if (fromDate && toDate) {
      q = query(transactionsRef, 
        where('date', '>=', fromDate),
        where('date', '<=', toDate)
      );
    }
    
    if (transactionType) {
      q = query(q, where('type', '==', transactionType));
    }
    
    onSnapshot(q, (snapshot) => {
      const transactions = snapshot.docs.map(doc => {
        return { id: doc.id, ...doc.data() };
      });
      callback(transactions);
    });
  }

  // Get fund transfers with optional date filtering (maintained for backward compatibility)
  getFundTransfers(
    callback: (transfers: any[]) => void,
    fromDate?: string,
    toDate?: string
  ): void {
    const transfersRef = collection(this.firestore, 'fundTransfers');
    let q = query(transfersRef);
    
    if (fromDate && toDate) {
      q = query(transfersRef, 
        where('date', '>=', fromDate),
        where('date', '<=', toDate)
      );
    }
    
    onSnapshot(q, (snapshot) => {
      const transfers = snapshot.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          date: data['date']
        };
      });
      callback(transfers);
    });
  }

  // Get deposits with optional date filtering (maintained for backward compatibility)
  getDeposits(
    callback: (deposits: any[]) => void,
    fromDate?: string,
    toDate?: string
  ): void {
    const depositsRef = collection(this.firestore, 'deposits');
    let q = query(depositsRef);
    
    if (fromDate && toDate) {
      q = query(depositsRef, 
        where('date', '>=', fromDate),
        where('date', '<=', toDate)
      );
    }
    
    onSnapshot(q, (snapshot) => {
      const deposits = snapshot.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          date: data['date']
        };
      });
      callback(deposits);
    });
  }

  // Add a new account
  addAccount(accountData: any): Promise<any> {
    const accountsRef = collection(this.firestore, 'accounts');
    return addDoc(accountsRef, accountData);
  }

  // Update an existing account
  updateAccount(id: string, accountData: any): Promise<void> {
    const accountDocRef = doc(this.firestore, 'accounts', id);
    return updateDoc(accountDocRef, accountData);
  }

  // Delete an account
  deleteAccount(id: string): Promise<void> {
    const accountDocRef = doc(this.firestore, 'accounts', id);
    return deleteDoc(accountDocRef);
  }

  // Delete a transaction
  deleteTransaction(id: string): Promise<void> {
    const transactionDocRef = doc(this.firestore, 'transactions', id);
    return deleteDoc(transactionDocRef);
  }
  
  // Delete a fund transfer
  deleteFundTransfer(id: string): Promise<void> {
    const fundTransferDocRef = doc(this.firestore, 'fundTransfers', id);
    return deleteDoc(fundTransferDocRef);
  }

  // Add a new transaction
  addTransaction(transactionData: any): Promise<any> {
    const transactionsRef = collection(this.firestore, 'transactions');
    return addDoc(transactionsRef, transactionData);
  }

  // Update a transaction
  updateTransaction(transaction: any): Promise<void> {
    const transactionDocRef = doc(this.firestore, 'transactions', transaction.id);
    
    // Create a copy of the transaction without the id field (Firestore doesn't need it in the update)
    const { id, balance, ...transactionData } = transaction;
    
    return updateDoc(transactionDocRef, {
      date: transaction.date,
      description: transaction.description,
      paymentMethod: transaction.paymentMethod,
      paymentDetails: transaction.paymentDetails,
      note: transaction.note,
      debit: transaction.debit,
      credit: transaction.credit
      // Don't update fields like balance, attachmentUrl, type, etc. that shouldn't change
    });
  }
  
  // Update a fund transfer
  updateFundTransfer(transfer: any): Promise<void> {
    const transferDocRef = doc(this.firestore, 'fundTransfers', transfer.id);
    
    // For fund transfers, we need different fields
    return updateDoc(transferDocRef, {
      date: transfer.date,
      note: transfer.note || '',
      // For transfers, the amount is stored as debit/credit depending on direction
      amount: transfer.type === 'transfer_out' ? Number(transfer.debit) : Number(transfer.credit)
      // We don't update fromAccountId, toAccountId as these shouldn't change
    });
  }

  // Add a new fund transfer
  addFundTransfer(transferData: any): Promise<any> {
    const transfersRef = collection(this.firestore, 'fundTransfers');
    return addDoc(transfersRef, transferData);
  }

  // Get account name by ID (useful for displaying account names in transfers)
  async getAccountNameById(accountId: string): Promise<string> {
    const accountDocRef = doc(this.firestore, 'accounts', accountId);
    const docSnap = await getDoc(accountDocRef);
    
    if (docSnap.exists()) {
      return docSnap.data()['name'] || 'Unknown Account';
    }
    return 'Unknown Account';
  }

  // Add a new deposit
  addDeposit(depositData: any): Promise<any> {
    const depositsRef = collection(this.firestore, 'deposits');
    return addDoc(depositsRef, depositData);
  }

  // Get deposits for a specific account with realtime updates
  getDepositsForAccount(accountId: string, callback: (deposits: any[]) => void): void {
    const depositsRef = collection(this.firestore, 'deposits');
    const q = query(depositsRef, where('accountId', '==', accountId));
    
    onSnapshot(q, (snapshot) => {
      const deposits = snapshot.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          date: data['date']?.toDate() // Convert Firestore Timestamp to Date
        };
      });
      callback(deposits);
    });
  }

  // Get balance sheet data for an account
  getBalanceSheetData(accountId: string, fromDate: Date, toDate: Date, callback: (data: any) => void): void {
    this.getAllAccountTransactions(accountId, (transactions) => {
      // Filter by date range
      const filteredTransactions = transactions.filter(t => {
        const transactionDate = t.date?.toDate ? t.date.toDate() : new Date(t.date);
        return transactionDate >= fromDate && transactionDate <= toDate;
      });
      
      // Calculate totals
      const totalDebit = filteredTransactions.reduce((sum, t) => sum + (t.debit || 0), 0);
      const totalCredit = filteredTransactions.reduce((sum, t) => sum + (t.credit || 0), 0);
      
      // Get account details
      this.getAccountById(accountId).subscribe(account => {
        const openingBalance = account?.openingBalance || 0;
        const closingBalance = openingBalance + totalCredit - totalDebit;
        
        callback({
          accountDetails: account,
          transactions: filteredTransactions,
          totals: {
            debit: totalDebit,
            credit: totalCredit,
            opening: openingBalance,
            closing: closingBalance
          }
        });
      });
    });
  }

  // Get transactions by income type
  getTransactionsByIncomeType(incomeType: string, callback: (transactions: any[]) => void): void {
    // First get accounts with this income type
    this.getAccountsByIncomeType(incomeType, (accounts) => {
      const accountIds = accounts.map(a => a.id);
      
      if (accountIds.length === 0) {
        callback([]);
        return;
      }
      
      // Then get transactions for these accounts
      const transactionsRef = collection(this.firestore, 'transactions');
      const q = query(transactionsRef, where('accountId', 'in', accountIds));
      
      onSnapshot(q, (snapshot) => {
        const transactions = snapshot.docs.map(doc => {
          const data = doc.data();
          return { 
            id: doc.id, 
            ...data,
            date: data['date']?.toDate() // Convert Firestore Timestamp to Date
          };
        });
        callback(transactions);
      });
    });
  }

  // Get income summary by type
  getIncomeSummary(callback: (summary: any) => void): void {
    const incomeTypes = this.getIncomeTypes();
    let summary: any = {};
    
    // Initialize summary
    incomeTypes.forEach(type => {
      summary[type] = {
        total: 0,
        count: 0,
        accounts: []
      };
    });
    
    // Get all accounts and calculate summary
    this.getAccounts((accounts) => {
      accounts.forEach(account => {
        if (account.incomeType && incomeTypes.includes(account.incomeType)) {
          summary[account.incomeType].total += account.openingBalance || 0;
          summary[account.incomeType].count++;
          summary[account.incomeType].accounts.push({
            id: account.id,
            name: account.name,
            balance: account.openingBalance || 0
          });
        }
      });
      
      callback(summary);
    });
  }
}