import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountService } from '../services/account.service';
import { DatePipe } from '@angular/common';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

interface AccountDetails {
  id: string;
  name: string;
  type: string;
  number: string;
  balance: number;
}

interface Transaction {
  id: string;
  date: Date;
  description: string;
  paymentMethod: string;
  paymentDetails: string;
  note: string;
  addedBy: string;
  debit: number;
  credit: number;
  balance: number;
  hasDocument: boolean;
  type?: string;
  attachmentUrl?: string;
  fromAccountId?: string;
  toAccountId?: string;
}

interface EditingTransaction extends Omit<Transaction, 'date'> {
  dateString: string;
  date: Date;
}

@Component({
  selector: 'app-account-book',
  templateUrl: './account-book.component.html',
  styleUrls: ['./account-book.component.scss'],
  providers: [DatePipe]
})
export class AccountBookComponent implements OnInit {
  accountId: string = '';
  accountDetails: AccountDetails = {
    id: '',
    name: '',
    type: '',
    number: '',
    balance: 0
  };
  transactions: Transaction[] = [];
  filteredTransactions: Transaction[] = [];
  pagedTransactions: Transaction[] = [];
  allAccounts: any[] = [];
  accounts: any[] = []; // For fund transfer modal
  Math = Math;
  viewMode: 'table' | 'card' = 'table';
  currentPage: number = 1;
  entriesPerPage: number = 25;
  dateRange = {
    from: new Date(new Date().setDate(new Date().getDate() - 30)),
    to: new Date()
  };
  transactionType: string = 'All';
  searchQuery: string = '';
  totalDebit: number = 0;
  totalCredit: number = 0;
  loading: boolean = false;
  isEmpty: boolean = true;
  
  // Edit transaction properties
  showEditModal: boolean = false;
  editingTransaction: EditingTransaction = this.getEmptyEditingTransaction();
  
  // Fund Transfer properties
  showFundTransferModal: boolean = false;
  fundTransferForm: FormGroup;
  selectedFile: File | null = null;

  constructor(
    private route: ActivatedRoute,
    private accountService: AccountService,
    private datePipe: DatePipe,
    private formBuilder: FormBuilder
  ) {
    this.fundTransferForm = this.formBuilder.group({
      fromAccount: ['', Validators.required],
      toAccount: ['', Validators.required],
      amount: [0, [Validators.required, Validators.min(1)]],
      date: [new Date().toISOString().split('T')[0], Validators.required],
      note: ['']
    });
  }

  ngOnInit(): void {
    this.accountId = this.route.snapshot.paramMap.get('id') || '';
    if (this.accountId) {
      this.loadAllAccounts();
      this.loadAccountDetails();
      this.loadTransactions();
    }
  }

  getEmptyEditingTransaction(): EditingTransaction {
    return {
      id: '',
      date: new Date(),
      dateString: '',
      description: '',
      paymentMethod: '',
      paymentDetails: '',
      note: '',
      addedBy: '',
      debit: 0,
      credit: 0,
      balance: 0,
      hasDocument: false
    };
  }

  loadAllAccounts(): void {
    this.accountService.getAccounts((accounts: any[]) => {
      this.allAccounts = accounts;
      this.accounts = accounts; // For fund transfer modal
    });
  }

  loadAccountDetails(): void {
    this.loading = true;
    this.accountService.getAccountById(this.accountId).subscribe({
      next: (account) => {
        if (account) {
          this.accountDetails = {
            id: account.id || this.accountId,
            name: account.name || '',
            type: account.accountType || '',
            number: account.accountNumber || '',
            balance: account.openingBalance || 0
          };
        }
        this.loading = false;
      },
      error: (error: any) => {
        console.error('Error loading account details:', error);
        this.loading = false;
      }
    });
  }

  loadTransactions(): void {
    this.loading = true;
    this.accountService.getAllAccountTransactions(this.accountId, (transactions: any[]) => {
      this.transactions = transactions.map(t => {
        const transactionDate = t.date?.toDate ? t.date.toDate() : new Date(t.date);
        
        // For transfer transactions
        let description = t.description;
        let paymentMethod = t.paymentMethod || '';
        
        if (t.type === 'transfer' || t.type === 'transfer_in' || t.type === 'transfer_out') {
          if (t.fromAccountId === this.accountId || t.type === 'transfer_out') {
            description = `Transfer to ${this.getAccountName(t.toAccountId)}`;
            paymentMethod = 'Fund Transfer';
          } else if (t.toAccountId === this.accountId || t.type === 'transfer_in') {
            description = `Transfer from ${this.getAccountName(t.fromAccountId)}`;
            paymentMethod = 'Fund Transfer';
          }
        }

        return {
          id: t.id || '',
          date: transactionDate,
          description: description,
          paymentMethod: paymentMethod,
          paymentDetails: t.paymentDetails || '',
          note: t.note || '',
          addedBy: t.addedBy || 'System',
          debit: (t.type === 'transfer' || t.type === 'transfer_out') && (t.fromAccountId === this.accountId) ? 
                  Number(t.amount || t.debit || 0) : Number(t.debit || 0),
          credit: (t.type === 'transfer' || t.type === 'transfer_in') && (t.toAccountId === this.accountId) ? 
                   Number(t.amount || t.credit || 0) : Number(t.credit || 0),
          balance: 0, // Will be calculated
          hasDocument: t.hasDocument || false,
          type: t.type,
          attachmentUrl: t.attachmentUrl,
          fromAccountId: t.fromAccountId,
          toAccountId: t.toAccountId
        };
      });

      // Calculate running balance
      this.calculateRunningBalance();
      
      // Apply filters and update pagination
      this.filterTransactions();
      this.isEmpty = this.transactions.length === 0;
      this.loading = false;
    });
  }

  getAccountName(accountId: string | undefined): string {
    if (!accountId) return 'Unknown Account';
    const account = this.allAccounts.find(a => a.id === accountId);
    return account ? account.name : 'Unknown Account';
  }

  calculateRunningBalance(): void {
    // Sort by date (oldest first)
    const sorted = [...this.transactions].sort((a, b) => a.date.getTime() - b.date.getTime());
    let balance = this.accountDetails.balance;

    sorted.forEach(t => {
      // Ensure debit and credit are numbers
      const debit = Number(t.debit) || 0;
      const credit = Number(t.credit) || 0;
      
      balance = balance + credit - debit;
      t.balance = balance;
    });

    // Reverse to show newest first
    this.transactions = sorted.reverse();
  }

  // Filter transactions based on all criteria
  filterTransactions(): void {
    // Apply date filter
    this.filteredTransactions = this.transactions.filter(t => {
      const transactionDate = t.date;
      return transactionDate >= this.dateRange.from && 
             transactionDate <= this.dateRange.to;
    });
    
    // Apply search filter
    if (this.searchQuery) {
      const query = this.searchQuery.toLowerCase();
      this.filteredTransactions = this.filteredTransactions.filter(t => 
        t.description.toLowerCase().includes(query) ||
        t.paymentMethod.toLowerCase().includes(query) ||
        t.addedBy.toLowerCase().includes(query) ||
        (t.note && t.note.toLowerCase().includes(query))
      );
    }
    
    // Apply transaction type filter
    if (this.transactionType !== 'All') {
      if (this.transactionType === 'Debit') {
        this.filteredTransactions = this.filteredTransactions.filter(t => Number(t.debit) > 0);
      } else if (this.transactionType === 'Credit') {
        this.filteredTransactions = this.filteredTransactions.filter(t => Number(t.credit) > 0);
      } else if (this.transactionType === 'Transfer') {
        this.filteredTransactions = this.filteredTransactions.filter(t => 
          t.type === 'transfer' || 
          t.type === 'transfer_in' || 
          t.type === 'transfer_out'
        );
      }
    }
    
    // Calculate totals from filtered transactions
    this.calculateTotals();
    
    // Update pagination
    this.currentPage = 1;
    this.updatePagedTransactions();
  }

  calculateTotals(): void {
    // Calculate totals based on filtered transactions
    this.totalDebit = this.filteredTransactions.reduce((sum, t) => sum + Number(t.debit || 0), 0);
    this.totalCredit = this.filteredTransactions.reduce((sum, t) => sum + Number(t.credit || 0), 0);
  }

  updatePagedTransactions(): void {
    // Paginate filtered transactions
    const start = (this.currentPage - 1) * this.entriesPerPage;
    this.pagedTransactions = this.filteredTransactions.slice(start, start + this.entriesPerPage);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePagedTransactions();
    }
  }

  nextPage(): void {
    if (this.currentPage * this.entriesPerPage < this.filteredTransactions.length) {
      this.currentPage++;
      this.updatePagedTransactions();
    }
  }

  onDateRangeChange(): void {
    this.filterTransactions();
  }

  onTransactionTypeChange(): void {
    this.filterTransactions();
  }

  onSearchChange(): void {
    this.filterTransactions();
  }

  deleteTransaction(id: string): void {
    if (confirm('Are you sure you want to delete this transaction?')) {
      // Find the transaction type to handle deletion appropriately
      const transaction = this.transactions.find(t => t.id === id);
      
      if (transaction) {
        if (transaction.type === 'transfer' || transaction.type === 'transfer_in' || transaction.type === 'transfer_out') {
          // For transfers, we need to delete from fundTransfers collection
          this.accountService.deleteFundTransfer(id).then(() => {
            console.log('Fund transfer deleted successfully');
            this.loadTransactions();
          }).catch((error) => {
            console.error('Error deleting fund transfer:', error);
            alert('Failed to delete fund transfer');
          });
        } else {
          // For regular transactions
          this.accountService.deleteTransaction(id).then(() => {
            console.log('Transaction deleted successfully');
            this.loadTransactions();
          }).catch((error) => {
            console.error('Error deleting transaction:', error);
            alert('Failed to delete transaction');
          });
        }
      }
    }
  }

  downloadDocument(url: string | undefined): void {
    if (url) {
      window.open(url, '_blank');
    }
  }

  getMinValue(a: number, b: number): number {
    return Math.min(a, b);
  }

  // Methods for Edit functionality
  editTransaction(transaction: Transaction): void {
    // Format date for datetime-local input
    let dateString = this.formatDateForInput(transaction.date);
    
    this.editingTransaction = {
      ...transaction,
      dateString: dateString
    };
    
    this.showEditModal = true;
  }
  
  formatDateForInput(date: Date): string {
    // Format date as YYYY-MM-DDThh:mm
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }
  
  saveTransaction(): void {
    // Convert dateString back to Date object
    const updatedDate = new Date(this.editingTransaction.dateString);
    
    // Create the updated transaction object
    const updatedTransaction = {
      id: this.editingTransaction.id,
      date: updatedDate,
      description: this.editingTransaction.description,
      paymentMethod: this.editingTransaction.paymentMethod,
      paymentDetails: this.editingTransaction.paymentDetails,
      note: this.editingTransaction.note,
      debit: Number(this.editingTransaction.debit) || 0,
      credit: Number(this.editingTransaction.credit) || 0,
      type: this.editingTransaction.type,
      // Include these for transfer types
      fromAccountId: this.editingTransaction.fromAccountId,
      toAccountId: this.editingTransaction.toAccountId
    };
    
    // Handle different transaction types for updates
    if (updatedTransaction.type === 'transfer' || 
        updatedTransaction.type === 'transfer_in' || 
        updatedTransaction.type === 'transfer_out') {
      
      // For fund transfers
      this.accountService.updateFundTransfer(updatedTransaction).then(() => {
        console.log('Fund transfer updated successfully');
        this.showEditModal = false;
        this.loadTransactions(); // Reload to get updated data
      }).catch((error) => {
        console.error('Error updating fund transfer:', error);
        alert('Failed to update fund transfer');
      });
    } else {
      // For regular transactions
      this.accountService.updateTransaction(updatedTransaction).then(() => {
        console.log('Transaction updated successfully');
        this.showEditModal = false;
        this.loadTransactions(); // Reload to get updated data
      }).catch((error) => {
        console.error('Error updating transaction:', error);
        alert('Failed to update transaction');
      });
    }
  }
  
  cancelEdit(): void {
    this.showEditModal = false;
    this.editingTransaction = this.getEmptyEditingTransaction();
  }

  // Fund Transfer Modal Functions
  openFundTransferModal(): void {
    this.showFundTransferModal = true;
    // Pre-select the current account as 'from' account
    this.fundTransferForm.patchValue({
      fromAccount: this.accountId,
      date: new Date().toISOString().split('T')[0]
    });
  }
  
  closeFundTransferForm(): void {
    this.showFundTransferModal = false;
    this.fundTransferForm.reset();
    this.selectedFile = null;
    // Set default date
    this.fundTransferForm.patchValue({
      date: new Date().toISOString().split('T')[0]
    });
  }
  
  onFileSelected(event: any): void {
    const file = event.target.files[0];
    // Validate file size (5MB max)
    if (file && file.size <= 5 * 1024 * 1024) {
      // Validate file type
      const allowedTypes = ['.pdf', '.csv', '.zip', '.doc', '.docx', '.jpeg', '.jpg', '.png'];
      const fileExt = '.' + file.name.split('.').pop().toLowerCase();
      
      if (allowedTypes.includes(fileExt)) {
        this.selectedFile = file;
      } else {
        alert('Invalid file type. Allowed types: PDF, CSV, ZIP, DOC, DOCX, JPEG, JPG, PNG');
        event.target.value = null;
      }
    } else {
      alert('File size should not exceed 5MB');
      event.target.value = null;
    }
  }
  
  submitFundTransfer(): void {
    if (this.fundTransferForm.invalid) {
      Object.keys(this.fundTransferForm.controls).forEach(key => {
        this.fundTransferForm.get(key)?.markAsTouched();
      });
      return;
    }
    
    const formValue = this.fundTransferForm.value;
    
    // Get account names for better descriptions
    const fromAccountName = this.getAccountName(formValue.fromAccount);
    const toAccountName = this.getAccountName(formValue.toAccount);
    
    const transferData = {
      fromAccountId: formValue.fromAccount,
      fromAccountName: fromAccountName,
      toAccountId: formValue.toAccount,
      toAccountName: toAccountName,
      amount: Number(formValue.amount),
      date: new Date(formValue.date),
      note: formValue.note || '',
      addedBy: 'User', // You might want to get this from authentication service
      type: 'transfer',
      hasDocument: !!this.selectedFile
    };
    
    // Handle file upload if needed
    if (this.selectedFile) {
      // Here you would upload the file and get the URL
      // For now, we'll just proceed without the file
      console.log('File would be uploaded here:', this.selectedFile.name);
    }
    
    // Add the fund transfer
    this.accountService.addFundTransfer(transferData).then(() => {
      this.closeFundTransferForm();
      // Reload transactions to show the new transfer
      this.loadTransactions();
    }).catch((error) => {
      console.error('Error adding fund transfer:', error);
      alert('Failed to add fund transfer');
    });
  }

  // New method to download the transaction data
  downloadTransactionData(): void {
    if (this.filteredTransactions.length === 0) {
      alert('No data to download');
      return;
    }

    // Create CSV data
    let csvContent = 'Date,Description,Payment Method,Payment Details,Note,Added By,Debit,Credit,Balance\n';
    
    this.filteredTransactions.forEach(t => {
      const formattedDate = this.datePipe.transform(t.date, 'MM/dd/yyyy HH:mm') || '';
      const description = t.description.replace(/,/g, ' '); // Remove commas to avoid CSV issues
      const paymentMethod = t.paymentMethod.replace(/,/g, ' ');
      const paymentDetails = (t.paymentDetails || '').replace(/,/g, ' ');
      const note = (t.note || '').replace(/,/g, ' ');
      const addedBy = t.addedBy.replace(/,/g, ' ');
      const debit = t.debit || 0;
      const credit = t.credit || 0;
      const balance = t.balance || 0;
      
      csvContent += `${formattedDate},"${description}","${paymentMethod}","${paymentDetails}","${note}","${addedBy}",${debit},${credit},${balance}\n`;
    });
    
    // Add total row
    csvContent += `Total,,,,,,${this.totalDebit},${this.totalCredit},\n`;
    
    // Create a Blob with the CSV data
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    
    // Create a download link
    const link = document.createElement('a');
    
    // Create a URL for the blob
    const url = window.URL.createObjectURL(blob);
    
    // Set link properties
    link.setAttribute('href', url);
    link.setAttribute('download', `${this.accountDetails.name}_transactions.csv`);
    link.style.visibility = 'hidden';
    
    // Append to document, click to download, and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}