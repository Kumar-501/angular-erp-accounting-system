// src/app/models/sales-order.model.ts
export interface SalesOrder {
  id: string;
  customerId: string;
  saleDate: Date | any; // or firebase.firestore.Timestamp if using Firebase
  invoiceNo?: string;
  products?: Array<{
    id?: string;
    name?: string;
    quantity?: number;
    unitPrice?: number;
    subtotal?: number;
  }>;
  status?: string;
  shippingStatus?: string;
  paymentAmount?: number;
  total?: number;        // Make sure this matches your data
  subtotal?: number;
  tax?: number;
  shippingCost?: number;
  balance?: number;
  totalPayable?: number; // Add this if your data has it
  // Include any other properties your sales objects might have
}