// src/app/shared/models/product.model.ts
export interface Product {
    id?: string;
    productName: string;
    sku: string;
    barcodeType?: string;
    unit: string;
    brand?: string;
    category?: string;
    subCategory?: string;
    manageStock?: boolean;
    alertQuantity?: number | null;
    productDescription?: string;
    productImage?: any;
    productBrochure?: any;
    enableProductDescription?: boolean;
    notForSelling?: boolean;
    weight?: number | null;
    preparationTime?: number | null;
    applicableTax?: string | any;
    taxPercentage?: number;
    sellingPriceTaxType?: string;
    productType?: string;
    defaultPurchasePriceExcTax?: number | null;
    defaultPurchasePriceIncTax?: number | null;
    marginPercentage?: number;
    defaultSellingPriceExcTax?: number | null;
    defaultSellingPriceIncTax?: number | null;
    createdAt?: Date | any;
    updatedAt?: Date | any;
    currentStock?: number;
  }
  
  export interface StockReportItem {
    id: string;
    productName: string;
    sku: string;
    category: string;
    brand: string;
    unit: string;
    currentStock: number;
    alertQuantity: number;
    purchasePrice: number;
    sellingPrice: number;
    margin: number;
    taxPercentage: number;
    lastUpdated: Date;
  }