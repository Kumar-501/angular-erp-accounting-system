export interface StockData {
    id?: string;
    productName: string;
    quantity: number;
    unit: string;
    unitCost: number;
    lotNumber: string;
    date: string;
    note: string;
    location: string;
    locationCode: string;
    subtotal: number;
    timestamp?: Date;
  }