import { Component } from '@angular/core';

@Component({
  selector: 'app-expense-data',
  templateUrl: './expense-data.component.html',
  styleUrl: './expense-data.component.scss'
})
export class ExpenseDataComponent {

}
